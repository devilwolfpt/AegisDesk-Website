// interface.h
// Interface gráfica (Dear ImGui). Esta parte só desenha e reage a cliques:
// toda a lógica está no GestorPedidos e no AssistenteIA.
#pragma once

#include <string>
#include <vector>

#include "assistente_ia.h"
#include "gestor.h"
#include "texturas.h"

// Aviso flutuante (toast) mostrado por cima da interface.
struct Aviso {
    std::string titulo;
    std::string texto;
    int tipo = 0;              // 0 = informação, 1 = sucesso, 2 = erro, 3 = atenção
    double inicio = 0.0;       // instante em que apareceu (ImGui::GetTime)
    double duracao = 4.5;      // segundos visível
};

// Tudo o que a janela precisa de "lembrar" entre frames.
struct EstadoUI {
    GestorPedidos gestor;
    AssistenteIA ia;
    Texturas texturas;             // logótipo, ícones e fotografias

    // seleção e filtros da lista
    int idSelecionado = -1;
    std::string filtroTexto;
    int filtroEstado = 0;        // 0 = todos; 1.. = Estado + 1
    int criterioOrdem = 0;
    float fracaoLista = 0.55f;   // largura do painel esquerdo (divisor arrastável)
    bool focarPesquisa = false;

    // formulário "novo pedido"
    bool abrirNovoPedido = false;
    std::string novoCliente, novoContacto, novoEquipamento, novaAvaria;
    std::string novoVendedor, novoTecnico;
    int novaPrioridade = 1;
    std::string erroNovoPedido;

    // formulário "nova intervenção"
    std::string intDescricao, intPeca;
    float intCusto = 0.0f, intHoras = 0.0f;
    std::string erroIntervencao;

    // ficheiros e modelo
    std::string caminhoDados = "assistencia_dados.dat";
    std::string caminhoModelo;
    int temaInterface = 0;
    int nThreads = 4;
    int indiceContexto = 1;      // 0=1024, 1=2048, 2=4096
    int maxTokens = 350;
    int tipoIA = 0;              // 0 = diagnóstico, 1 = mensagem ao cliente
    int idPedidoIA = -1;         // pedido para o qual o texto da IA foi gerado

    // mensagem temporária na barra inferior e avisos flutuantes
    std::string mensagemEstado;
    double mensagemAte = 0.0;
    std::vector<Aviso> avisos;

    // paleta de comandos (Ctrl+K)
    bool paletaAberta = false;
    bool paletaFocar = false;
    std::string paletaTexto;
    int paletaIndice = 0;

    // preferências visuais
    bool modoCompacto = false;
    int metricaVendedor = 0;     // 0 = pedidos, 1 = faturação

    bool abrirAtalhos = false;
    int forcarSeparador = 0;     // 0=Detalhe 1=Estatísticas 2=IA 3=Personalização (força a aba na abertura)
    bool sair = false;
};

extern bool fonteSuportaEuro;          // ver interface.cpp
extern ImFont* fonteTitulo;            // tipo de letra semibold para títulos

void iniciarEstado(EstadoUI& ui);     // lê configuração e dados (ou demo)
void terminarEstado(EstadoUI& ui);    // grava configuração e dados
void desenharInterface(EstadoUI& ui); // chamado uma vez por frame
void aplicarEstilo(float escala);
void definirTemaInterface(int tema);
void definirModoCompacto(bool compacto);
