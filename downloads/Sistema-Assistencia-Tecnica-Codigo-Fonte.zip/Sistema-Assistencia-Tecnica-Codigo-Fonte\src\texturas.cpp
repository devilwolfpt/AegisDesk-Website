// texturas.cpp
// Lê os ficheiros de imagem da pasta "recursos/" (e o logótipo na raiz do
// projeto) e cria uma textura OpenGL por imagem. Os ícones vêm pretos do
// Material Design Icons, por isso são convertidos para branco aqui, para
// ficarem legíveis sobre o fundo escuro da aplicação.
#include "texturas.h"

#include <cstdint>
#include <fstream>
#include <initializer_list>
#include <string>

// Implementação da leitura de PNG/JPEG (apenas uma vez, neste ficheiro).
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// Só DECLARAÇÕES das funções OpenGL: a implementação vive no backend do ImGui
// (imgui_impl_opengl3.cpp), por aqui usamos as mesmas funções já carregadas.
#include "imgui_impl_opengl3_loader.h"

// GL_CLAMP_TO_EDGE não existe no OpenGL 1.1; se o carregador não o definir,
// usamos o valor oficial do enum.
#ifndef GL_CLAMP_TO_EDGE
#define GL_CLAMP_TO_EDGE 0x812F
#endif

// ====================================================================
//  Procura de ficheiros
// ====================================================================

static bool ficheiroExiste(const std::string& caminho) {
    std::ifstream f(caminho, std::ios::binary);
    return f.good();
}

// A aplicação pode ser executada a partir da raiz do projeto, da pasta
// build/Release ou de outra pasta próxima, por isso tentamos vários caminhos.
static std::string procurarFicheiro(std::initializer_list<const char*> candidatos) {
    static const char* RAIZES[] = {"", "../", "../../", "../../../"};
    for (const char* nome : candidatos) {
        for (const char* raiz : RAIZES) {
            std::string caminho = std::string(raiz) + nome;
            if (ficheiroExiste(caminho)) return caminho;
        }
    }
    return "";
}

// ====================================================================
//  Criação e libertação de texturas OpenGL
// ====================================================================

static ImTextureID criarTextura(const std::string& caminho, bool branca) {
    if (caminho.empty()) return ImTextureID_Invalid;

    int largura = 0, altura = 0, canais = 0;
    // 4 canais = RGBA, mesmo quando o ficheiro tem menos (ícones P&B).
    unsigned char* dados = stbi_load(caminho.c_str(), &largura, &altura, &canais, 4);
    if (dados == nullptr) return ImTextureID_Invalid;   // ficheiro corrompido?

    if (branca) {
        // Ícone preto: passamos o desenho a branco e mantemos o alfa
        // (as bordas continuam suaves, ficando translúcidas).
        for (int i = 0; i < largura * altura; i++) {
            dados[i * 4 + 0] = 255;
            dados[i * 4 + 1] = 255;
            dados[i * 4 + 2] = 255;
        }
    }

    GLuint id = 0;
    glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, largura, altura, 0, GL_RGBA, GL_UNSIGNED_BYTE, dados);
    stbi_image_free(dados);
    return static_cast<ImTextureID>(static_cast<intptr_t>(id));
}

static void apagarTextura(ImTextureID& t) {
    if (!texturaValida(t)) return;
    GLuint id = static_cast<GLuint>(static_cast<intptr_t>(t));
    glDeleteTextures(1, &id);
    t = ImTextureID_Invalid;
}

// ====================================================================
//  Carregamento de todos os recursos
// ====================================================================

// Por ordem do enum Icone.
static const char* NOMES_ICONE[] = {
    "add", "search", "save", "reload", "dados", "sair", "ajuda", "sobre",
    "detalhe", "stats", "ia", "remover", "adicionar", "contacto", "vendedor",
    "tecnico", "gerar", "verificar", "copiar", "configuracoes", "estado",
    "prioridade", "data", "euro", "cliente", "equipamento", "fechar",
    "historico", "loja",
};
static_assert(sizeof(NOMES_ICONE) / sizeof(NOMES_ICONE[0]) == static_cast<int>(Icone::Contagem),
              "Falta um nome de ícone em NOMES_ICONE.");

void carregarTexturas(Texturas& t) {
    if (t.carregado) return;    // já carregadas (ou tentadas) uma vez
    t.carregado = true;

    // Logótipo da Neuria (o utilizador coloca-o na raiz do projeto).
    t.logo = criarTextura(procurarFicheiro({"Neuria Logo.png", "recursos/Neuria Logo.png"}), false);

    // Fotografias decorativas (descarregadas da Internet, ver recursos/CREDITOS.txt).
    t.banner = criarTextura(procurarFicheiro({"recursos/imagens/banner_sobre.jpg", "imagens/banner_sobre.jpg"}), false);
    t.semPedido = criarTextura(procurarFicheiro({"recursos/imagens/sem_pedido.jpg", "imagens/sem_pedido.jpg"}), false);

    // Ícones (Material Design Icons, convertidos para branco).
    for (int i = 0; i < static_cast<int>(Icone::Contagem); i++) {
        std::string emRecursos = std::string("recursos/icones/") + NOMES_ICONE[i] + ".png";
        std::string direto = std::string("icones/") + NOMES_ICONE[i] + ".png";
        t.icones[i] = criarTextura(procurarFicheiro({emRecursos.c_str(), direto.c_str()}), true);
    }
}

void libertarTexturas(Texturas& t) {
    apagarTextura(t.logo);
    apagarTextura(t.banner);
    apagarTextura(t.semPedido);
    for (int i = 0; i < static_cast<int>(Icone::Contagem); i++) apagarTextura(t.icones[i]);
    t.carregado = false;
}

ImTextureID icone(const Texturas& t, Icone i) {
    int indice = static_cast<int>(i);
    if (indice < 0 || indice >= static_cast<int>(Icone::Contagem)) return ImTextureID_Invalid;
    return t.icones[indice];
}
