// modelos.h
// Estruturas de dados do Sistema de Assistência Técnica.
// Aqui definimos "o que é" um pedido de reparação e uma intervenção.
#pragma once

#include <ctime>
#include <string>

// ---------- Enumerações ----------
// Usei enum class para não misturar valores de enums diferentes por engano.
enum class Prioridade { Baixa = 0, Normal, Alta, Urgente };
enum class Estado { Aberto = 0, EmDiagnostico, AguardaPecas, EmReparacao, Concluido, Entregue };

const int NUM_PRIORIDADES = 4;
const int NUM_ESTADOS = 6;

// ---------- Intervenção ----------
// Uma intervenção é uma ação feita na reparação (ex.: "Troca de ecrã").
// Pode ter uma peça associada e um número de horas de mão de obra.
struct Intervencao {
    std::string descricao;
    std::string peca;      // vazio se não foi usada nenhuma peça
    float custoPeca = 0.0f;  // em euros
    float horas = 0.0f;      // horas de mão de obra
};

// ---------- Pedido de assistência ----------
// Cada pedido tem uma lista DINÂMICA de intervenções: não sabemos à partida
// quantas vão ser precisas, por isso usamos um array alocado com new[]
// que cresce quando enche (ver adicionarIntervencao em gestor.cpp).
struct Pedido {
    int id = 0;
    std::string cliente;       // nomes fictícios!
    std::string contacto;      // telefone ou email do cliente (fictício)
    std::string equipamento;   // ex.: "Portátil Acer Aspire 5"
    std::string avaria;        // o que o cliente reportou
    std::string diagnostico;   // preenchido pelo técnico (ou sugerido pela IA)
    std::string vendedor;      // colaborador que recebeu/vendeu o serviço
    std::string tecnico;       // técnico responsável pela reparação
    Prioridade prioridade = Prioridade::Normal;
    Estado estado = Estado::Aberto;
    std::time_t dataAbertura = 0;
    std::time_t dataFecho = 0;   // 0 enquanto não estiver concluído

    Intervencao* intervencoes = nullptr;  // array dinâmico (new[] / delete[])
    int nIntervencoes = 0;                // quantas estão em uso
    int capIntervencoes = 0;              // quantas cabem no array
};

// ---------- Funções auxiliares sobre os enums ----------
const char* nomePrioridade(Prioridade p);
const char* nomeEstado(Estado e);
