// assistente_ia.cpp
#include "assistente_ia.h"

#include <atomic>
#include <cstdio>
#include <mutex>
#include <sstream>
#include <thread>
#include <vector>

#ifdef USE_LLAMA
#include "llama.h"
#endif

// ====================================================================
//  Prompts (o que dizemos ao modelo)
// ====================================================================

std::string instrucaoSistema(TipoPedidoIA tipo) {
    if (tipo == TipoPedidoIA::DiagnosticoSugerido) {
        return "És um técnico de assistência informática experiente. Responde sempre em português "
               "de Portugal, de forma clara e curta. Com base no pedido, indica: 1) até três causas "
               "prováveis, 2) testes de diagnóstico a fazer por ordem, 3) peças que podem ser "
               "necessárias. Não inventes informação que não esteja no pedido. É apenas uma "
               "sugestão que o técnico irá confirmar.";
    }
    return "És o atendimento ao cliente de uma loja de assistência técnica. Escreve em português "
           "de Portugal uma mensagem curta, simpática e profissional a informar o cliente sobre o "
           "estado da reparação. Não inventes preços nem prazos que não estejam nos dados.";
}

std::string montarPergunta(TipoPedidoIA tipo, const Pedido& p, float custoAtual) {
    std::ostringstream s;
    s << "Equipamento: " << p.equipamento << "\n";
    s << "Avaria reportada: " << p.avaria << "\n";
    s << "Prioridade: " << nomePrioridade(p.prioridade) << "\n";
    s << "Estado atual: " << nomeEstado(p.estado) << "\n";
    if (!p.diagnostico.empty()) s << "Diagnóstico do técnico: " << p.diagnostico << "\n";

    if (p.nIntervencoes > 0) {
        s << "Intervenções já feitas:\n";
        for (int i = 0; i < p.nIntervencoes; i++) {
            s << "- " << p.intervencoes[i].descricao;
            if (!p.intervencoes[i].peca.empty()) s << " (peça: " << p.intervencoes[i].peca << ")";
            s << "\n";
        }
    }

    if (tipo == TipoPedidoIA::MensagemParaCliente) {
        s << "Nome do cliente: " << p.cliente << "\n";
        char buf[64];
        std::snprintf(buf, sizeof(buf), "Custo acumulado: %.2f euros\n", custoAtual);
        s << buf;
        s << "\nEscreve a mensagem para o cliente.";
    } else {
        s << "\nSugere o diagnóstico.";
    }
    return s.str();
}

// ====================================================================
//  Implementação
// ====================================================================

struct AssistenteIA::Impl {
    std::atomic<int> estado{static_cast<int>(EstadoIA::SemModelo)};
    std::atomic<bool> cancelar{false};
    mutable std::mutex mtx;           // protege os textos abaixo
    std::string mensagem = "Nenhum modelo carregado.";
    std::string texto;
    std::string nome;
    std::thread trabalhador;

#ifdef USE_LLAMA
    llama_model* modelo = nullptr;
    llama_context* contexto = nullptr;
    int tamanhoContexto = 2048;
#endif

    void definirEstado(EstadoIA e, const std::string& msg) {
        std::lock_guard<std::mutex> lock(mtx);
        mensagem = msg;
        estado = static_cast<int>(e);
    }
    void esperarThread() {
        if (trabalhador.joinable()) trabalhador.join();
    }
};

AssistenteIA::AssistenteIA() : impl(new Impl()) {}

AssistenteIA::~AssistenteIA() {
    impl->cancelar = true;
    impl->esperarThread();
#ifdef USE_LLAMA
    if (impl->contexto) llama_free(impl->contexto);
    if (impl->modelo) llama_model_free(impl->modelo);
#endif
    delete impl;
}

bool AssistenteIA::compiladoComSuporte() {
#ifdef USE_LLAMA
    return true;
#else
    return false;
#endif
}

EstadoIA AssistenteIA::estado() const { return static_cast<EstadoIA>(impl->estado.load()); }

std::string AssistenteIA::mensagem() const {
    std::lock_guard<std::mutex> lock(impl->mtx);
    return impl->mensagem;
}

std::string AssistenteIA::textoGerado() const {
    std::lock_guard<std::mutex> lock(impl->mtx);
    return impl->texto;
}

std::string AssistenteIA::nomeModelo() const {
    std::lock_guard<std::mutex> lock(impl->mtx);
    return impl->nome;
}

void AssistenteIA::parar() { impl->cancelar = true; }

#ifndef USE_LLAMA
// ---------- Versão sem llama.cpp: a aplicação continua a funcionar ----------
void AssistenteIA::carregarModelo(const std::string&, int, int) {
    impl->definirEstado(EstadoIA::Erro,
                        "Esta compilação não inclui suporte a GGUF (USE_LLAMA=OFF).");
}
void AssistenteIA::descarregarModelo() {}
void AssistenteIA::gerar(const std::string&, const std::string&, int) {
    impl->definirEstado(EstadoIA::Erro, "Esta compilação não inclui suporte a GGUF.");
}

#else
// ---------- Versão com llama.cpp ----------

// Quando o texto chega token a token, um caractere UTF-8 (ex.: "ã") pode vir
// partido em dois tokens. Esta função diz quantos bytes do início formam
// caracteres completos, para só mostrarmos esses.
static size_t bytesUtf8Completos(const std::string& s) {
    size_t n = s.size();
    for (size_t k = 1; k <= 3 && k <= n; k++) {
        unsigned char c = static_cast<unsigned char>(s[n - k]);
        if ((c & 0xC0) == 0x80) continue;          // byte de continuação, recua
        size_t esperado = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : (c >= 0xC0) ? 2 : 1;
        return (k < esperado) ? n - k : n;          // sequência incompleta?
    }
    return n;
}

static void silenciarLogs(enum ggml_log_level nivel, const char* texto, void*) {
    if (nivel >= GGML_LOG_LEVEL_ERROR) std::fputs(texto, stderr);   // só erros
}

void AssistenteIA::descarregarModelo() {
    if (estado() == EstadoIA::ACarregar || estado() == EstadoIA::AGerar) return;
    impl->esperarThread();
    if (impl->contexto) { llama_free(impl->contexto); impl->contexto = nullptr; }
    if (impl->modelo) { llama_model_free(impl->modelo); impl->modelo = nullptr; }
    {
        std::lock_guard<std::mutex> lock(impl->mtx);
        impl->nome.clear();
        impl->texto.clear();
    }
    impl->definirEstado(EstadoIA::SemModelo, "Nenhum modelo carregado.");
}

void AssistenteIA::carregarModelo(const std::string& caminho, int nThreads, int tamanhoContexto) {
    if (estado() == EstadoIA::ACarregar || estado() == EstadoIA::AGerar) return;
    impl->esperarThread();
    if (impl->contexto) { llama_free(impl->contexto); impl->contexto = nullptr; }
    if (impl->modelo) { llama_model_free(impl->modelo); impl->modelo = nullptr; }
    if (caminho.empty()) { impl->definirEstado(EstadoIA::Erro, "Indique o caminho do ficheiro .gguf."); return; }

    impl->definirEstado(EstadoIA::ACarregar, "A carregar o modelo...");
    Impl* d = impl;
    d->trabalhador = std::thread([d, caminho, nThreads, tamanhoContexto]() {
        static bool iniciado = false;           // llama_backend_init só uma vez
        if (!iniciado) { llama_log_set(silenciarLogs, nullptr); llama_backend_init(); iniciado = true; }

        llama_model_params mp = llama_model_default_params();
        mp.n_gpu_layers = 0;                    // só CPU: funciona em qualquer PC
        llama_model* modelo = llama_model_load_from_file(caminho.c_str(), mp);
        if (modelo == nullptr) {
            d->definirEstado(EstadoIA::Erro, "Não foi possível carregar o ficheiro. Confirme que é um .gguf válido: " + caminho);
            return;
        }

        llama_context_params cp = llama_context_default_params();
        cp.n_ctx = static_cast<uint32_t>(tamanhoContexto);
        cp.n_batch = static_cast<uint32_t>(tamanhoContexto);
        cp.n_threads = nThreads;
        cp.n_threads_batch = nThreads;
        llama_context* ctx = llama_init_from_model(modelo, cp);
        if (ctx == nullptr) {
            llama_model_free(modelo);
            d->definirEstado(EstadoIA::Erro, "Não foi possível criar o contexto (pouca memória? reduza o contexto).");
            return;
        }

        d->modelo = modelo;
        d->contexto = ctx;
        d->tamanhoContexto = tamanhoContexto;
        std::string nome = caminho;
        size_t pos = nome.find_last_of("/\\");
        if (pos != std::string::npos) nome = nome.substr(pos + 1);
        {
            std::lock_guard<std::mutex> lock(d->mtx);
            d->nome = nome;
        }
        d->definirEstado(EstadoIA::Pronto, "Modelo pronto: " + nome);
    });
}

void AssistenteIA::gerar(const std::string& sistema, const std::string& pergunta, int maxTokens) {
    if (estado() != EstadoIA::Pronto) return;   // só se houver modelo e estiver livre
    impl->esperarThread();
    {
        std::lock_guard<std::mutex> lock(impl->mtx);
        impl->texto.clear();
    }
    impl->cancelar = false;
    impl->definirEstado(EstadoIA::AGerar, "A gerar...");

    Impl* d = impl;
    d->trabalhador = std::thread([d, sistema, pergunta, maxTokens]() {
        const llama_vocab* vocab = llama_model_get_vocab(d->modelo);

        // 1) Aplicar o "chat template" do próprio modelo (cada modelo tem o seu formato)
        llama_chat_message msgs[2] = {{"system", sistema.c_str()}, {"user", pergunta.c_str()}};
        const char* tmpl = llama_model_chat_template(d->modelo, nullptr);
        if (tmpl == nullptr) tmpl = "chatml";
        std::vector<char> buf(sistema.size() + pergunta.size() + 512);
        int n = llama_chat_apply_template(tmpl, msgs, 2, true, buf.data(), static_cast<int32_t>(buf.size()));
        if (n > static_cast<int>(buf.size())) {
            buf.resize(n);
            n = llama_chat_apply_template(tmpl, msgs, 2, true, buf.data(), static_cast<int32_t>(buf.size()));
        }
        if (n < 0) { d->definirEstado(EstadoIA::Pronto, "Erro: o modelo tem um formato de conversa não suportado."); return; }
        std::string prompt(buf.data(), n);

        // 2) Converter o texto em tokens (números que o modelo percebe)
        int nTokens = -llama_tokenize(vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()), nullptr, 0, true, true);
        std::vector<llama_token> tokens(nTokens);
        if (nTokens <= 0 || llama_tokenize(vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()),
                                           tokens.data(), nTokens, true, true) < 0) {
            d->definirEstado(EstadoIA::Pronto, "Erro ao converter o texto em tokens.");
            return;
        }
        if (nTokens + maxTokens > d->tamanhoContexto) {
            d->definirEstado(EstadoIA::Pronto, "Pedido demasiado longo para o contexto do modelo.");
            return;
        }

        // 3) Limpar a memória da conversa anterior e preparar o "sampler"
        llama_memory_clear(llama_get_memory(d->contexto), true);
        llama_sampler* sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
        llama_sampler_chain_add(sampler, llama_sampler_init_min_p(0.05f, 1));
        llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.4f));   // baixo = respostas mais estáveis
        llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

        // 4) Ciclo principal: avaliar -> escolher próximo token -> repetir
        llama_batch batch = llama_batch_get_one(tokens.data(), static_cast<int32_t>(tokens.size()));
        std::string pendente;     // bytes recebidos ainda não publicados
        std::string erro;
        int gerados = 0;
        llama_token token = 0;   // fora do ciclo: o batch aponta para ele na volta seguinte
        while (gerados < maxTokens) {
            if (d->cancelar) break;
            if (llama_decode(d->contexto, batch) != 0) { erro = "Erro durante a geração."; break; }

            token = llama_sampler_sample(sampler, d->contexto, -1);
            if (llama_vocab_is_eog(vocab, token)) break;      // fim da resposta

            char peca[256];
            int len = llama_token_to_piece(vocab, token, peca, sizeof(peca), 0, true);
            if (len < 0) { erro = "Erro ao converter token em texto."; break; }
            pendente.append(peca, len);

            size_t ok = bytesUtf8Completos(pendente);
            if (ok > 0) {
                std::lock_guard<std::mutex> lock(d->mtx);
                d->texto.append(pendente, 0, ok);
                pendente.erase(0, ok);
            }
            batch = llama_batch_get_one(&token, 1);
            gerados++;
        }

        llama_sampler_free(sampler);   // libertar o que foi criado
        if (!erro.empty()) d->definirEstado(EstadoIA::Pronto, erro);
        else if (d->cancelar) d->definirEstado(EstadoIA::Pronto, "Geração interrompida.");
        else d->definirEstado(EstadoIA::Pronto, "Concluído (" + std::to_string(gerados) + " tokens).");
    });
}
#endif
