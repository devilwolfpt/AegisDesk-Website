﻿// main.cpp
// Cria a janela (GLFW), inicia o Dear ImGui e corre o ciclo principal.
#include <cstdio>
#include <fstream>
#include <vector>

#include "GLFW/glfw3.h"
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_opengl3_loader.h"
#include "stb_image.h"
#include "interface.h"

static void erroGLFW(int codigo, const char* descricao) {
    std::fprintf(stderr, "Erro GLFW %d: %s\n", codigo, descricao);
}

static bool ficheiroExiste(const char* caminho) {
    std::ifstream f(caminho);
    return f.good();
}

// Usa o logótipo da Neuria como ícone da janela (barra de tarefas).
static void definirIconeJanela(GLFWwindow* janela) {
    const char* candidatos[] = {"Neuria Logo.png", "../Neuria Logo.png", "../../Neuria Logo.png"};
    unsigned char* dados = nullptr;
    int largura = 0, altura = 0, canais = 0;
    for (const char* caminho : candidatos) {
        dados = stbi_load(caminho, &largura, &altura, &canais, 4);
        if (dados != nullptr) break;
    }
    if (dados == nullptr) return;

    // Reduz para 64x64 (amostragem simples) para o ícone não ocupar demasiada memória.
    const int alvo = 64;
    std::vector<unsigned char> pixels(alvo * alvo * 4);
    for (int y = 0; y < alvo; y++) {
        for (int x = 0; x < alvo; x++) {
            int sx = x * largura / alvo;
            int sy = y * altura / alvo;
            const unsigned char* origem = dados + (sy * largura + sx) * 4;
            unsigned char* destino = pixels.data() + (y * alvo + x) * 4;
            destino[0] = origem[0];
            destino[1] = origem[1];
            destino[2] = origem[2];
            destino[3] = origem[3];
        }
    }
    GLFWimage icone{alvo, alvo, pixels.data()};
    glfwSetWindowIcon(janela, 1, &icone);
    stbi_image_free(dados);
}

int main() {
    glfwSetErrorCallback(erroGLFW);
    if (!glfwInit()) return 1;

#if defined(__APPLE__)
    const char* glsl = "#version 150";
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
#else
    const char* glsl = "#version 130";
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
#endif

    float escala = ImGui_ImplGlfw_GetContentScaleForMonitor(glfwGetPrimaryMonitor());
    GLFWwindow* janela = glfwCreateWindow(static_cast<int>(1280 * escala), static_cast<int>(780 * escala),
                                          "Neuria - Sistema de Assistência Técnica", nullptr, nullptr);
    if (janela == nullptr) { glfwTerminate(); return 1; }
    glfwMakeContextCurrent(janela);
    glfwSwapInterval(1);   // sincroniza com o monitor (evita gastar CPU)
    definirIconeJanela(janela);
    glfwSetWindowSizeLimits(janela, static_cast<int>(1100 * escala), static_cast<int>(680 * escala),
                            GLFW_DONT_CARE, GLFW_DONT_CARE);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;   // não criar imgui.ini

    // Tipo de letra: tenta um tipo de letra do sistema (têm acentos e o símbolo €);
    // se não houver nenhum, usa o tipo de letra incluído no ImGui.
    const char* candidatas[] = {
        "C:\\Windows\\Fonts\\segoeui.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/Library/Fonts/Arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/TTF/DejaVuSans.ttf",
    };
    bool fonteCarregada = false;
    ImFont* fonteCorpo = nullptr;
    for (const char* caminho : candidatas) {
        fonteCorpo = io.Fonts->AddFontFromFileTTF(caminho, 18.0f * escala);
        if (fonteCorpo != nullptr) {
            fonteCarregada = true;
            break;
        }
    }
    if (!fonteCarregada) {
        ImFontConfig cfg;
        cfg.SizePixels = 17.0f * escala;
        fonteCorpo = io.Fonts->AddFontDefault(&cfg);
    }
    fonteSuportaEuro = fonteCarregada;

    // Tipo de letra semibold para títulos (cria contraste com o texto normal).
    // Se não existir no sistema, os títulos usam o mesmo tipo de letra.
    fonteTitulo = fonteCorpo;
    const char* candidatasTitulo[] = {
        "C:\\Windows\\Fonts\\seguisb.ttf",       // Segoe UI Semibold
        "C:\\Windows\\Fonts\\segoeuib.ttf",      // Segoe UI Bold
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
    };
    for (const char* caminho : candidatasTitulo) {
        if (!ficheiroExiste(caminho)) continue;
        ImFont* fonte = io.Fonts->AddFontFromFileTTF(caminho, 18.0f * escala);
        if (fonte != nullptr) {
            fonteTitulo = fonte;
            break;
        }
    }

    aplicarEstilo(escala > 1.0f ? escala : 1.0f);
    ImGui_ImplGlfw_InitForOpenGL(janela, true);
    ImGui_ImplOpenGL3_Init(glsl);

    EstadoUI* ui = new EstadoUI();   // memória dinâmica: o estado vive enquanto a janela existir
    iniciarEstado(*ui);

    while (!glfwWindowShouldClose(janela) && !ui->sair) {
        glfwPollEvents();
        if (glfwGetWindowAttrib(janela, GLFW_ICONIFIED) != 0) { glfwWaitEventsTimeout(0.1); continue; }

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();
        desenharInterface(*ui);
        ImGui::Render();

        int w, h;
        glfwGetFramebufferSize(janela, &w, &h);
        glViewport(0, 0, w, h);
        glClearColor(0.027f, 0.043f, 0.086f, 1.0f);   // mesmo tom do fundo do tema
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(janela);
    }

    terminarEstado(*ui);   // grava dados e configuração
    delete ui;             // destrói o gestor (liberta a memória) e a IA (pára a thread)

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(janela);
    glfwTerminate();
    return 0;
}
