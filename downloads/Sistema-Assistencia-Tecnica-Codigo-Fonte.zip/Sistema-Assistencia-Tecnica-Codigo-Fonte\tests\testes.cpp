// testes.cpp
// Testes automáticos da lógica (sem interface). Corresponde ao plano de testes
// T01..T10 da ficha. Compilar e executar:  ctest   ou   ./testes
#include <cmath>
#include <cstdio>
#include <string>

#include "gestor.h"

static int falhas = 0;
static int total = 0;

static void verificar(bool condicao, const char* nome) {
    total++;
    if (condicao) {
        std::printf("  [OK]    %s\n", nome);
    } else {
        std::printf("  [FALHA] %s\n", nome);
        falhas++;
    }
}

static bool quaseIgual(float a, float b) { return std::fabs(a - b) < 0.01f; }

int main() {
    const std::time_t DIA = 86400;
    const std::time_t t0 = 1700000000;   // data fixa para testes reprodutíveis

    std::printf("T01 – Operação normal (adicionar e listar)\n");
    {
        GestorPedidos g;
        int id1 = g.adicionarPedido("Cliente Um", "Portátil X", "Não liga", Prioridade::Alta, t0);
        int id2 = g.adicionarPedido("Cliente Dois", "Telemóvel Y", "Ecrã partido", Prioridade::Baixa, t0);
        verificar(id1 == 1 && id2 == 2, "ids sequenciais 1 e 2");
        verificar(g.quantidade() == 2, "quantidade = 2");
        verificar(g.pedidoNaPosicao(0)->cliente == "Cliente Um", "primeiro pedido correto");
    }

    std::printf("T02/T03 – Pesquisa existente e inexistente\n");
    {
        GestorPedidos g;
        g.carregarDadosDemo();
        verificar(g.pesquisar("acer", -1).size() == 1, "pesquisa 'acer' (minúsculas) encontra 1");
        verificar(g.pesquisar("zzzzzz", -1).empty(), "pesquisa inexistente devolve vazio");
        verificar(g.pesquisar("sofia ramos", -1).size() == 4, "pesquisa por vendedor encontra os 4 pedidos dela");
        verificar(g.procurarPorId(1)->vendedor == "Sofia Ramos", "dados demo têm vendedor");
        verificar(g.procurarPorId(1)->tecnico == "Diogo Martins", "dados demo têm técnico");
        verificar(g.procurarPorId(1)->contacto == "912 345 678", "dados demo têm contacto");
        verificar(g.procurarPorId(9999) == nullptr, "id inexistente devolve nullptr");
        verificar(g.pesquisar("", static_cast<int>(Estado::Aberto)).size() == 2, "filtro por estado Aberto = 2");
    }

    std::printf("T04 – Entradas inválidas\n");
    {
        GestorPedidos g;
        verificar(g.adicionarPedido("", "PC", "avaria", Prioridade::Normal) == -1, "cliente vazio rejeitado");
        verificar(g.adicionarPedido("   ", "PC", "avaria", Prioridade::Normal) == -1, "cliente só com espaços rejeitado");
        verificar(g.adicionarPedido("Ana", "PC", "", Prioridade::Normal) == -1, "avaria vazia rejeitada");
        verificar(g.adicionarPedido(std::string(200, 'x'), "PC", "a", Prioridade::Normal) == -1, "nome demasiado longo rejeitado");
        verificar(g.adicionarPedido("Ana", "PC", "a", Prioridade::Normal, "", std::string(80, 'v'), "", t0) == -1, "vendedor demasiado longo rejeitado");
        verificar(g.adicionarPedido("Ana", "PC", "a", Prioridade::Normal, "911 222 333", "Zé", "Técnico", t0) == 1, "pedido com vendedor e técnico aceite");
        verificar(g.procurarPorId(1)->vendedor == "Zé" && g.procurarPorId(1)->contacto == "911 222 333", "campos novos guardados no pedido");
        g.limparTudo();
        verificar(g.quantidade() == 0, "nenhum pedido inválido foi guardado");
        int id = g.adicionarPedido("Ana", "PC", "avaria", Prioridade::Normal, t0);
        Pedido* p = g.procurarPorId(id);
        verificar(!g.adicionarIntervencao(p, "", "", 0, 1), "intervenção sem descrição rejeitada");
        verificar(!g.adicionarIntervencao(p, "x", "", -5, 1), "custo negativo rejeitado");
        verificar(!g.adicionarIntervencao(p, "x", "", 1, -1), "horas negativas rejeitadas");
        verificar(!g.adicionarIntervencao(nullptr, "x", "", 1, 1), "apontador nulo rejeitado (sem crash)");
        verificar(!g.mudarEstado(nullptr, Estado::Concluido), "mudarEstado(nullptr) rejeitado");
    }

    std::printf("T05 – Lista vazia\n");
    {
        GestorPedidos g;
        Estatisticas e = g.calcularEstatisticas();
        verificar(e.total == 0 && e.tempoMedioDias == 0.0f && e.custoMedio == 0.0f, "estatísticas de lista vazia sem divisão por zero");
        verificar(g.pedidoNaPosicao(0) == nullptr, "posição 0 numa lista vazia = nullptr");
        verificar(!g.removerPedido(1), "remover numa lista vazia devolve false");
        g.ordenar(compararPorPrioridade);
        verificar(g.quantidade() == 0, "ordenar lista vazia não faz nada");
    }

    std::printf("T06 – Limites (crescimento do array, último elemento, índices)\n");
    {
        GestorPedidos g;
        for (int i = 0; i < 100; i++) {
            g.adicionarPedido("Cliente " + std::to_string(i), "Equip", "avaria", Prioridade::Normal, t0);
        }
        verificar(g.quantidade() == 100, "100 pedidos (array cresceu várias vezes)");
        verificar(g.pedidoNaPosicao(99) != nullptr && g.pedidoNaPosicao(99)->id == 100, "último elemento acessível");
        verificar(g.pedidoNaPosicao(100) == nullptr, "índice 100 (fora do limite) = nullptr");
        verificar(g.pedidoNaPosicao(-1) == nullptr, "índice -1 = nullptr");

        Pedido* p = g.procurarPorId(1);
        for (int i = 0; i < 50; i++) g.adicionarIntervencao(p, "passo " + std::to_string(i), "", 1.0f, 0.1f);
        verificar(p->nIntervencoes == 50, "50 intervenções (array de intervenções cresceu)");
        verificar(p->intervencoes[49].descricao == "passo 49", "última intervenção correta após crescimentos");
    }

    std::printf("T07 – Alteração e remoção\n");
    {
        GestorPedidos g;
        int a = g.adicionarPedido("A", "E", "x", Prioridade::Normal, t0);
        int b = g.adicionarPedido("B", "E", "x", Prioridade::Normal, t0);
        int c = g.adicionarPedido("C", "E", "x", Prioridade::Normal, t0);
        g.adicionarIntervencao(g.procurarPorId(b), "arranjo", "peça", 10, 1);
        verificar(g.removerPedido(b), "remover pedido do meio");
        verificar(g.quantidade() == 2 && g.procurarPorId(b) == nullptr, "pedido removido deixa de existir");
        verificar(g.procurarPorId(a) != nullptr && g.procurarPorId(c) != nullptr, "restantes mantêm-se");
        verificar(g.pedidoNaPosicao(1)->id == c, "elementos deslocados corretamente");
        verificar(!g.removerPedido(b), "remover duas vezes falha");

        Pedido* p = g.procurarPorId(a);
        g.mudarEstado(p, Estado::Concluido, t0 + 3 * DIA);
        verificar(p->estado == Estado::Concluido && p->dataFecho == t0 + 3 * DIA, "concluir regista data de fecho");
        g.mudarEstado(p, Estado::EmReparacao);
        verificar(p->dataFecho == 0, "reabrir limpa data de fecho");

        g.adicionarIntervencao(p, "um", "", 0, 1);
        g.adicionarIntervencao(p, "dois", "", 0, 1);
        verificar(g.removerIntervencao(p, 0) && p->nIntervencoes == 1 && p->intervencoes[0].descricao == "dois", "remover intervenção");
        verificar(!g.removerIntervencao(p, 5), "remover intervenção fora do limite falha");
    }

    std::printf("T08 – Cálculos e relatórios\n");
    {
        GestorPedidos g;
        g.taxaHoraria = 20.0f;
        int id = g.adicionarPedido("A", "E", "x", Prioridade::Urgente, t0);
        Pedido* p = g.procurarPorId(id);
        g.adicionarIntervencao(p, "i1", "peça 1", 30.0f, 1.5f);
        g.adicionarIntervencao(p, "i2", "peça 2", 20.0f, 0.5f);
        verificar(quaseIgual(g.custoPecas(*p), 50.0f), "custo de peças = 50");
        verificar(quaseIgual(g.horasTotais(*p), 2.0f), "horas = 2");
        verificar(quaseIgual(g.custoPedido(*p), 90.0f), "custo total = 50 + 2*20 = 90");

        int id2 = g.adicionarPedido("B", "E", "x", Prioridade::Normal, t0);
        g.mudarEstado(g.procurarPorId(id), Estado::Concluido, t0 + 4 * DIA);
        g.mudarEstado(g.procurarPorId(id2), Estado::Entregue, t0 + 2 * DIA);
        Estatisticas e = g.calcularEstatisticas();
        verificar(e.total == 2 && e.urgentesPendentes == 0, "totais e urgentes pendentes");
        verificar(quaseIgual(e.tempoMedioDias, 3.0f), "tempo médio = (4+2)/2 = 3 dias");
        verificar(quaseIgual(e.faturacaoTotal, 90.0f), "faturação = 90");

        GestorPedidos demo;
        demo.carregarDadosDemo();
        Estatisticas ed = demo.calcularEstatisticas();
        verificar(ed.total == 12 && ed.urgentesPendentes == 2, "dados demo: 12 pedidos, 2 urgentes pendentes");
    }

    std::printf("T09 – Memória e apontadores\n");
    {
        GestorPedidos g;
        g.carregarDadosDemo();
        Pedido* antes = g.procurarPorId(1);
        verificar(antes != nullptr && antes->intervencoes != nullptr, "pedido 1 tem array dinâmico de intervenções");
        g.limparTudo();
        verificar(g.quantidade() == 0, "limparTudo esvazia o gestor");
        g.carregarDadosDemo();   // reutilizável depois de limpar
        verificar(g.quantidade() == 12, "gestor reutilizável após limpar");

        // Ordenação com apontador para função
        g.ordenar(compararPorPrioridade);
        verificar(g.pedidoNaPosicao(0)->prioridade == Prioridade::Urgente, "ordenar por prioridade: urgente primeiro");
        g.ordenar(compararPorId);
        verificar(g.pedidoNaPosicao(0)->id == 1 && g.pedidoNaPosicao(11)->id == 12, "ordenar por id");
        verificar(g.procurarPorId(6)->nIntervencoes == 2, "intervenções acompanham o pedido após ordenar");
        g.ordenar(compararPorVendedor);
        verificar(g.pedidoNaPosicao(0)->vendedor == "Bruno Lima" && g.pedidoNaPosicao(11)->vendedor == "Sofia Ramos",
                  "ordenar por vendedor (apontador para função)");
    }

    std::printf("T10 – Ficheiros (guardar/carregar, ficheiros corrompidos)\n");
    {
        GestorPedidos g;
        g.carregarDadosDemo();
        g.taxaHoraria = 31.5f;
        g.procurarPorId(3)->diagnostico = "linha 1\nlinha 2 com | barra e \\ contra-barra";
        g.procurarPorId(2)->vendedor = "Lima | Neto";   // caractere especial nos campos novos
        std::string erro;
        const char* ficheiro = "teste_assistencia.dat";
        verificar(g.guardar(ficheiro, erro), "guardar com sucesso");

        GestorPedidos h;
        verificar(h.carregar(ficheiro, erro), "carregar com sucesso");
        verificar(h.quantidade() == 12, "mesmo número de pedidos");
        verificar(quaseIgual(h.taxaHoraria, 31.5f), "taxa horária preservada");
        verificar(h.procurarPorId(3)->diagnostico == g.procurarPorId(3)->diagnostico, "texto com caracteres especiais preservado");
        verificar(h.procurarPorId(6)->nIntervencoes == 2, "intervenções preservadas");
        verificar(h.procurarPorId(1)->vendedor == "Sofia Ramos" && h.procurarPorId(1)->tecnico == "Diogo Martins" &&
                  h.procurarPorId(1)->contacto == "912 345 678", "vendedor, técnico e contacto preservados");
        verificar(h.procurarPorId(2)->vendedor == "Lima | Neto", "vendedor com carácter especial preservado");
        verificar(h.pesquisar("sofia ramos", -1).size() == 4, "pesquisa por vendedor funciona após carregar");
        verificar(quaseIgual(h.custoPedido(*h.procurarPorId(6)), g.custoPedido(*g.procurarPorId(6))), "custos iguais");
        int novo = h.adicionarPedido("Novo", "E", "x", Prioridade::Normal);
        verificar(novo == 13, "próximo id continua depois de carregar");

        verificar(!h.carregar("nao_existe.dat", erro), "ficheiro inexistente falha");
        verificar(h.quantidade() == 13, "dados mantidos após carregar falhado");

        FILE* f = std::fopen("corrompido.dat", "w");
        std::fputs("ASSISTENCIA_TECNICA|1\nP|abc|x|y|z|w|9|9|0|0\n", f);
        std::fclose(f);
        verificar(!h.carregar("corrompido.dat", erro), "ficheiro corrompido rejeitado");
        verificar(h.quantidade() == 13, "dados mantidos após ficheiro corrompido");

        // Ficheiro escrito por uma versão antiga (sem vendedor/técnico/contacto)
        FILE* fa = std::fopen("antigo.dat", "w");
        std::fputs("ASSISTENCIA_TECNICA|1\nCONFIG|25|2\nP|1|Cliente|Equip|Avaria|Diag|1|0|1700000000|0\n", fa);
        std::fclose(fa);
        GestorPedidos antigo;
        verificar(antigo.carregar("antigo.dat", erro), "ficheiro no formato antigo ainda é lido");
        verificar(antigo.quantidade() == 1 && antigo.procurarPorId(1)->vendedor.empty(),
                  "campos novos ficam vazios ao ler ficheiro antigo");

        std::remove(ficheiro);
        std::remove("corrompido.dat");
        std::remove("antigo.dat");
    }

    std::printf("\n%d testes, %d falhas.\n", total, falhas);
    return falhas == 0 ? 0 : 1;
}
