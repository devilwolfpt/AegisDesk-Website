# Documentação técnica – Sistema de Assistência Técnica

Complemento à ficha de projeto (UFCD 0810). **Antes de entregar, confirme cada afirmação abaixo no
código** (os números de linha mudam quando edita os ficheiros) e preencha os campos pessoais.

## 1. Proposta (Grupo I)

- **Título:** Sistema de Assistência Técnica
- **Problema:** uma oficina de reparação precisa de controlar pedidos, prioridades, diagnósticos, peças e estados.
- **Utilizador:** técnico/rececionista de uma loja de assistência informática.
- **Funcionalidades essenciais:** (1) abrir e gerir pedidos com prioridade e estado; (2) registar diagnóstico e
  intervenções com peças/horas e calcular o custo; (3) pesquisar/filtrar/ordenar a lista de pedidos.
- **Extensões:** (E1) assistente de IA local (GGUF) para sugerir diagnóstico e mensagem ao cliente;
  (E2) guardar/carregar em ficheiro com validação + painel de estatísticas.

## 2. Estruturas de dados (R2)

| Campo | Tipo | Porquê |
|---|---|---|
| `Pedido::id` | `int` | identificador único, sequencial |
| `cliente`, `equipamento`, `avaria`, `diagnostico` | `std::string` | texto de tamanho variável |
| `contacto`, `vendedor`, `tecnico` | `std::string` | quem comprou o serviço, quem o vendeu e quem repara (opcionais; guardados no ficheiro) |
| `prioridade` / `estado` | `enum class` | valores fechados; evita números "mágicos" |
| `dataAbertura` / `dataFecho` | `std::time_t` | permite calcular dias em aberto; `0` = ainda não fechado |
| `intervencoes`, `nIntervencoes`, `capIntervencoes` | `Intervencao*`, `int`, `int` | array dinâmico: apontador + usados + capacidade |
| `Intervencao::descricao`, `peca` | `std::string` | texto |
| `Intervencao::custoPeca`, `horas` | `float` | valores com casas decimais (euros e horas) |

## 3. Conteúdos da UFCD 0810 aplicados (Grupo II)

| Conteúdo | Onde | Utilidade concreta |
|---|---|---|
| Apontadores: declaração e uso | `GestorPedidos::procurarPorId`, `adicionarIntervencao(Pedido* p, ...)` | devolver/receber o pedido a alterar sem o copiar |
| Operadores `&` e `*` | `pedidoNaPosicao` (`return &pedidos[indice]`); `desenharDetalhe` (`*p`) | obter o endereço de um elemento; desreferenciar para ler custos |
| Aritmética de apontadores / arrays | `procurarPorId` e `horasTotais` (`for (p = pedidos; p != pedidos + n; ++p)`) | percorrer o array sem índices |
| Passagem por referência | `libertarPedido(Pedido&)`, `guardar(..., std::string& erro)`, `const Pedido&` nos cálculos | alterar o original / devolver mensagem de erro / evitar cópias |
| `struct` e acesso a membros | `Pedido`, `Intervencao`, `Estatisticas` (`modelos.h`, `gestor.h`) | agrupar os dados do domínio |
| Apontador para struct e `->` | `p->nIntervencoes`, `p->intervencoes[i]` em `adicionarIntervencao` | aceder aos membros através do apontador |
| Memória dinâmica `new` | `garantirCapacidade` (`new Pedido[]`), `adicionarIntervencao` (`new Intervencao[]`), `main` (`new EstadoUI`), `AssistenteIA` (`new Impl`) | arrays que crescem; número de pedidos desconhecido à partida |
| Libertação `delete`/`delete[]` | `libertarPedido`, `limparTudo`, `~GestorPedidos`, fim de `main`, `~AssistenteIA` | evitar fugas de memória (verificado com AddressSanitizer) |
| Apontadores nulos | `procurarPorId` devolve `nullptr`; todas as funções fazem `if (p == nullptr)` | evitar aceder a pedidos inexistentes |
| Apontadores para funções | `GestorPedidos::Comparador` em `ordenar()`; `comparadorEscolhido` em `interface.cpp` | escolher o critério de ordenação em tempo de execução |
| Outro (a validar com o professor) | `std::thread`/`mutex` em `AssistenteIA`; ficheiros (`ifstream`/`ofstream`) | IA sem bloquear a janela; persistência |

Cópia do `GestorPedidos` está **proibida** (`= delete`) porque tem memória dinâmica: duas cópias
libertariam o mesmo array (*double free*).

## 4. Mapa de funções principais (R4)

| Função | Objetivo | Parâmetros → retorno | Chamada em |
|---|---|---|---|
| `adicionarPedido` | cria um pedido validado (2 versões: só texto, ou com contacto/vendedor/técnico) | textos, prioridade → id ou -1 | `desenharNovoPedido` |
| `erroNovoPedido` | valida os textos | 3 strings → mensagem ou "" | `desenharNovoPedido`, `adicionarPedido` |
| `removerPedido` | remove e liberta intervenções | id → bool | `desenharDetalhe` |
| `procurarPorId` | encontra um pedido | id → `Pedido*` / `nullptr` | interface, testes |
| `pesquisar` | filtra por texto e estado | texto, estado → `vector<int>` | `desenharLista` |
| `ordenar` | ordenação por inserção com comparador | `Comparador` → void | `desenharLista` |
| `adicionarIntervencao` / `removerIntervencao` | gere o array de intervenções | `Pedido*`, dados → bool | `desenharDetalhe` |
| `mudarEstado` | altera estado e data de fecho | `Pedido*`, estado → bool | `desenharDetalhe` |
| `custoPedido`, `custoPecas`, `horasTotais` | cálculos de custo | `const Pedido&` → float | `desenharDetalhe`, estatísticas |
| `calcularEstatisticas` | indicadores globais | – → `Estatisticas` | `desenharEstatisticas` |
| `definirTemaInterface` / `definirModoCompacto` | aplicam as preferências visuais e recalculam o estilo | índice / bool → void | `desenharPersonalizacao`, `iniciarEstado` |
| `guardar` / `carregar` | persistência em texto | caminho, `string& erro` → bool | menu Ficheiro, `iniciarEstado` |
| `AssistenteIA::carregarModelo` / `gerar` / `parar` | IA GGUF em thread | caminho / prompts → void (assíncrono) | `desenharAssistenteIA` |
| `montarPergunta`, `instrucaoSistema` | constroem os prompts | tipo, pedido → string | `desenharAssistenteIA` |

Navegação: **janela única** → lista (esquerda) + separadores *Detalhe / Estatísticas / Assistente IA / Personalização* (direita);
*Novo pedido* e *Confirmar remoção* são janelas modais; menu *Ficheiro* (guardar, recarregar, demo, sair).

Elementos visuais e de interação acrescentados: fundo decorativo animado (gradiente, orbes e grelha de
pontos), cartões com sombra e indicadores KPI, donut de estados, gráfico das entradas dos últimos 14 dias,
cronologia do ciclo do pedido, divisor arrastável entre os dois painéis, barra de separadores fixa com
scroll independente em cada aba, paleta de comandos (`Ctrl+K`),
avisos flutuantes (toasts), exportação CSV, duplicação de pedidos, cópia do resumo para a área de
transferência e um **separador de Personalização dedicado**, com cartões de tema (quatro paletas, com
pré-visualização e indicação do tema ativo), escolha da densidade e reposição das predefinições. As
preferências visuais são guardadas em `assistencia.cfg`.

## 5. Pesquisa e cálculos (R9)

- **Pesquisa:** por cliente, equipamento, avaria ou nº do pedido (sem distinguir maiúsculas), combinável com filtro de estado.
- **Cálculos:** custo do pedido = peças + horas × taxa horária; tempo médio de resolução (dias); faturação total;
  custo médio por reparação; contagens por estado/prioridade; urgentes por resolver.

## 6. Plano de testes (R10) – resultados reais

`tests/testes.cpp` automatiza T01–T10 (74 verificações; resultado: **74 OK / 0 falhas**, também com AddressSanitizer + UBSan, sem fugas).

| ID | Condição | Entrada | Esperado | Resultado |
|---|---|---|---|---|
| T01 | Operação normal | 2 pedidos válidos | ids 1 e 2, quantidade 2 | OK |
| T02 | Pesquisa existente | `"acer"` (minúsculas) | 1 resultado | OK |
| T03 | Pesquisa inexistente | `"zzzzzz"`; id 9999 | vazio; `nullptr` | OK |
| T04 | Entrada inválida | cliente vazio/só espaços, nome com 200 chars, custo negativo, `nullptr` | rejeitado, nada guardado, sem crash | OK |
| T05 | Lista vazia | estatísticas/remover/ordenar sem dados | sem divisão por zero, sem crash | OK |
| T06 | Limites | 100 pedidos; 50 intervenções; índices -1 e 100 | arrays crescem; fora do limite → `nullptr` | OK |
| T07 | Alterar/remover | remover pedido do meio; concluir; reabrir | restantes mantêm-se; data de fecho correta | OK |
| T08 | Cálculos | taxa 20 €/h, peças 50 €, 2 h | custo 90 €; tempo médio 3 dias | OK |
| T09 | Memória/apontadores | `limparTudo` e reutilizar; ordenar com ponteiro para função | sem fugas; intervenções acompanham o pedido | OK |
| T10 | Ficheiros | guardar/carregar; ficheiro inexistente; ficheiro corrompido; ficheiro no formato antigo | dados preservados (incl. vendedor/técnico/contacto); falha não altera dados atuais | OK |

Testes do assistente GGUF (feitos com um modelo minúsculo gerado só para teste do fluxo — o texto é
aleatório de propósito): ficheiro inexistente → erro; ficheiro que não é GGUF → erro; gerar sem modelo → ignorado;
geração normal; **Parar** a meio; pedido maior que o contexto → mensagem; descarregar e recarregar; fechar a
janela durante a geração. **Faça também este teste com o seu modelo real** e registe o resultado.

## 7. Limitações conhecidas

- Não há seletor de ficheiros: o caminho do modelo escreve-se à mão.
- A IA corre só em CPU (`n_gpu_layers = 0`); modelos grandes são lentos.
- A qualidade das sugestões depende do modelo; modelos pequenos erram. Por isso nunca são aplicadas automaticamente.
- O formato `.dat` é próprio desta aplicação (texto com `|` como separador).
- Não há desfazer; a remoção pede confirmação.

## 8. Registo de utilização de IA (Grupo IV) – **a preencher por si**

A ficha exige declarar as ferramentas de IA usadas, o que foi aproveitado/alterado/rejeitado e como validou.
Este código foi gerado com apoio de IA (Claude): registe isso, guarde os seus pedidos e **leia e experimente
cada parte até a conseguir explicar sem ajuda**, porque a defesa é individual. Fontes externas a citar:
Dear ImGui (MIT), GLFW (zlib), llama.cpp (MIT) e o modelo GGUF que usar (verifique a licença).

Sugestão de exercícios de preparação: (a) mudar a taxa horária por defeito; (b) acrescentar um campo
`telefone` à struct e guardá-lo no ficheiro; (c) explicar o que acontece se se tirar o `delete[]` de `libertarPedido`;
(d) explicar porque `Pedido` tem `intervencoes` como apontador e não como `std::vector`.
