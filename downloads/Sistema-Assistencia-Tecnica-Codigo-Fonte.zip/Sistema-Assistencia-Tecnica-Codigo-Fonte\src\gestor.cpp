// gestor.cpp
#include "gestor.h"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <utility>

// ====================================================================
//  Funções auxiliares (nomes, datas, texto)
// ====================================================================

const char* nomePrioridade(Prioridade p) {
    switch (p) {
        case Prioridade::Baixa:   return "Baixa";
        case Prioridade::Normal:  return "Normal";
        case Prioridade::Alta:    return "Alta";
        case Prioridade::Urgente: return "Urgente";
    }
    return "?";
}

const char* nomeEstado(Estado e) {
    switch (e) {
        case Estado::Aberto:        return "Aberto";
        case Estado::EmDiagnostico: return "Em diagnóstico";
        case Estado::AguardaPecas:  return "Aguarda peças";
        case Estado::EmReparacao:   return "Em reparação";
        case Estado::Concluido:     return "Concluído";
        case Estado::Entregue:      return "Entregue";
    }
    return "?";
}

std::string formatarData(std::time_t t) {
    if (t == 0) return "-";
    std::tm tmLocal{};
#ifdef _WIN32
    localtime_s(&tmLocal, &t);
#else
    localtime_r(&t, &tmLocal);
#endif
    char buf[32];
    std::strftime(buf, sizeof(buf), "%d/%m/%Y", &tmLocal);
    return buf;
}

int diasEntre(std::time_t inicio, std::time_t fim) {
    if (fim <= inicio) return 0;
    return static_cast<int>((fim - inicio) / (60 * 60 * 24));
}

// Passa para minúsculas (só ASCII, chega para pesquisar nomes simples).
static std::string minusculas(std::string s) {
    for (char& c : s) {                       // c é uma REFERÊNCIA ao caractere
        if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');
    }
    return s;
}

static bool contem(const std::string& texto, const std::string& pedaco) {
    if (pedaco.empty()) return true;
    return minusculas(texto).find(minusculas(pedaco)) != std::string::npos;
}

static std::string aparar(const std::string& s) {
    size_t ini = s.find_first_not_of(" \t\r\n");
    if (ini == std::string::npos) return "";
    size_t fim = s.find_last_not_of(" \t\r\n");
    return s.substr(ini, fim - ini + 1);
}

// ====================================================================
//  Comparadores (usados com apontadores para funções)
// ====================================================================

bool compararPorId(const Pedido& a, const Pedido& b) { return a.id < b.id; }

bool compararPorPrioridade(const Pedido& a, const Pedido& b) {
    // enum class guarda números: Urgente (3) é o maior, queremos esse primeiro
    return static_cast<int>(a.prioridade) > static_cast<int>(b.prioridade);
}

bool compararPorData(const Pedido& a, const Pedido& b) {
    return a.dataAbertura < b.dataAbertura;
}

bool compararPorCliente(const Pedido& a, const Pedido& b) {
    return minusculas(a.cliente) < minusculas(b.cliente);
}

bool compararPorVendedor(const Pedido& a, const Pedido& b) {
    return minusculas(a.vendedor) < minusculas(b.vendedor);
}

// ====================================================================
//  Construtor / destrutor / memória
// ====================================================================

GestorPedidos::GestorPedidos() {
    // começa vazio; o array só é criado quando for preciso
}

GestorPedidos::~GestorPedidos() {
    limparTudo();
}

// Liberta as intervenções de UM pedido. Tem de ser chamada antes de
// deixar de usar o pedido, senão há fuga de memória.
void GestorPedidos::libertarPedido(Pedido& p) {
    delete[] p.intervencoes;      // delete[] porque foi criado com new[]
    p.intervencoes = nullptr;     // evita apontador "pendurado" (dangling)
    p.nIntervencoes = 0;
    p.capIntervencoes = 0;
}

void GestorPedidos::limparTudo() {
    for (int i = 0; i < nPedidos; i++) {
        libertarPedido(pedidos[i]);
    }
    delete[] pedidos;
    pedidos = nullptr;
    nPedidos = 0;
    capPedidos = 0;
    proximoId = 1;
}

void GestorPedidos::garantirCapacidade() {
    if (nPedidos < capPedidos) return;   // ainda há espaço

    int novaCap = (capPedidos == 0) ? 8 : capPedidos * 2;
    Pedido* novo = new Pedido[novaCap];
    for (int i = 0; i < nPedidos; i++) {
        novo[i] = std::move(pedidos[i]);   // o apontador "intervencoes" é copiado
    }
    delete[] pedidos;    // só apaga o array antigo; as intervenções já são do novo
    pedidos = novo;
    capPedidos = novaCap;
}

void GestorPedidos::trocar(GestorPedidos& outro) {
    std::swap(pedidos, outro.pedidos);
    std::swap(nPedidos, outro.nPedidos);
    std::swap(capPedidos, outro.capPedidos);
    std::swap(proximoId, outro.proximoId);
    std::swap(taxaHoraria, outro.taxaHoraria);
}

// ====================================================================
//  Pedidos
// ====================================================================

std::string GestorPedidos::erroNovoPedido(const std::string& cliente,
                                          const std::string& equipamento,
                                          const std::string& avaria) {
    if (aparar(cliente).empty())     return "O nome do cliente é obrigatório.";
    if (aparar(equipamento).empty()) return "O equipamento é obrigatório.";
    if (aparar(avaria).empty())      return "Descreva a avaria reportada.";
    if (cliente.size() > 80)         return "O nome do cliente é demasiado longo (máx. 80).";
    if (equipamento.size() > 100)    return "O equipamento é demasiado longo (máx. 100).";
    if (avaria.size() > 600)         return "A descrição da avaria é demasiado longa (máx. 600).";
    return "";
}

// Versão simples: sem contacto, vendedor nem técnico (fica tudo encaminhado
// para a versão completa, que faz todo o trabalho).
int GestorPedidos::adicionarPedido(const std::string& cliente, const std::string& equipamento,
                                   const std::string& avaria, Prioridade prioridade,
                                   std::time_t quando) {
    return adicionarPedido(cliente, equipamento, avaria, prioridade, "", "", "", quando);
}

int GestorPedidos::adicionarPedido(const std::string& cliente, const std::string& equipamento,
                                   const std::string& avaria, Prioridade prioridade,
                                   const std::string& contacto, const std::string& vendedor,
                                   const std::string& tecnico, std::time_t quando) {
    if (!erroNovoPedido(cliente, equipamento, avaria).empty()) return -1;
    // Os campos novos são opcionais, mas não podem ser gigantes.
    if (contacto.size() > 60 || vendedor.size() > 60 || tecnico.size() > 60) return -1;

    garantirCapacidade();
    Pedido& novo = pedidos[nPedidos];   // referência ao próximo espaço livre
    novo = Pedido();                    // garante valores iniciais limpos
    novo.id = proximoId++;
    novo.cliente = aparar(cliente);
    novo.contacto = aparar(contacto);
    novo.equipamento = aparar(equipamento);
    novo.avaria = aparar(avaria);
    novo.vendedor = aparar(vendedor);
    novo.tecnico = aparar(tecnico);
    novo.prioridade = prioridade;
    novo.estado = Estado::Aberto;
    novo.dataAbertura = (quando != 0) ? quando : std::time(nullptr);
    nPedidos++;
    return novo.id;
}

bool GestorPedidos::removerPedido(int id) {
    int pos = -1;
    for (int i = 0; i < nPedidos; i++) {
        if (pedidos[i].id == id) { pos = i; break; }
    }
    if (pos < 0) return false;

    libertarPedido(pedidos[pos]);               // 1.º libertar as intervenções
    for (int i = pos; i < nPedidos - 1; i++) {  // 2.º fechar o buraco
        pedidos[i] = std::move(pedidos[i + 1]);
    }
    pedidos[nPedidos - 1] = Pedido();           // o último passa a estar vazio
    nPedidos--;
    return true;
}

Pedido* GestorPedidos::procurarPorId(int id) {
    for (Pedido* p = pedidos; p != pedidos + nPedidos; ++p) {   // aritmética de apontadores
        if (p->id == id) return p;
    }
    return nullptr;
}

const Pedido* GestorPedidos::procurarPorId(int id) const {
    for (const Pedido* p = pedidos; p != pedidos + nPedidos; ++p) {
        if (p->id == id) return p;
    }
    return nullptr;
}

Pedido* GestorPedidos::pedidoNaPosicao(int indice) {
    if (indice < 0 || indice >= nPedidos) return nullptr;   // controlo de limites
    return &pedidos[indice];                                // & = endereço do elemento
}

const Pedido* GestorPedidos::pedidoNaPosicao(int indice) const {
    if (indice < 0 || indice >= nPedidos) return nullptr;
    return &pedidos[indice];
}

// ====================================================================
//  Intervenções
// ====================================================================

bool GestorPedidos::adicionarIntervencao(Pedido* p, const std::string& descricao,
                                         const std::string& peca, float custoPeca, float horas) {
    if (p == nullptr) return false;                  // nunca usar apontador nulo
    if (aparar(descricao).empty()) return false;
    if (custoPeca < 0.0f || custoPeca > 100000.0f) return false;
    if (horas < 0.0f || horas > 1000.0f) return false;

    if (p->nIntervencoes == p->capIntervencoes) {    // array cheio: cresce
        int novaCap = (p->capIntervencoes == 0) ? 4 : p->capIntervencoes * 2;
        Intervencao* novo = new Intervencao[novaCap];
        for (int i = 0; i < p->nIntervencoes; i++) {
            novo[i] = p->intervencoes[i];
        }
        delete[] p->intervencoes;
        p->intervencoes = novo;
        p->capIntervencoes = novaCap;
    }

    Intervencao& nova = p->intervencoes[p->nIntervencoes];
    nova.descricao = aparar(descricao);
    nova.peca = aparar(peca);
    nova.custoPeca = custoPeca;
    nova.horas = horas;
    p->nIntervencoes++;
    return true;
}

bool GestorPedidos::removerIntervencao(Pedido* p, int indice) {
    if (p == nullptr) return false;
    if (indice < 0 || indice >= p->nIntervencoes) return false;
    for (int i = indice; i < p->nIntervencoes - 1; i++) {
        p->intervencoes[i] = p->intervencoes[i + 1];
    }
    p->nIntervencoes--;
    return true;
}

bool GestorPedidos::mudarEstado(Pedido* p, Estado novo, std::time_t quando) {
    if (p == nullptr) return false;
    if (quando == 0) quando = std::time(nullptr);
    p->estado = novo;
    if (novo == Estado::Concluido || novo == Estado::Entregue) {
        if (p->dataFecho == 0) p->dataFecho = quando;
    } else {
        p->dataFecho = 0;   // foi reaberto
    }
    return true;
}

// ====================================================================
//  Pesquisa e ordenação
// ====================================================================

std::vector<int> GestorPedidos::pesquisar(const std::string& texto, int estadoFiltro) const {
    std::vector<int> resultado;
    for (int i = 0; i < nPedidos; i++) {
        const Pedido& p = pedidos[i];
        if (estadoFiltro >= 0 && static_cast<int>(p.estado) != estadoFiltro) continue;

        bool ok = contem(p.cliente, texto) || contem(p.equipamento, texto) ||
                  contem(p.avaria, texto) || contem(std::to_string(p.id), texto) ||
                  contem(p.contacto, texto) || contem(p.vendedor, texto) ||
                  contem(p.tecnico, texto);
        if (ok) resultado.push_back(i);
    }
    return resultado;
}

// Ordenação por inserção (estável). O critério vem de fora, por apontador
// para função: assim a mesma função serve para ordenar de várias maneiras.
void GestorPedidos::ordenar(Comparador cmp) {
    if (cmp == nullptr) return;
    for (int i = 1; i < nPedidos; i++) {
        int j = i;
        while (j > 0 && cmp(pedidos[j], pedidos[j - 1])) {
            std::swap(pedidos[j], pedidos[j - 1]);
            j--;
        }
    }
}

// ====================================================================
//  Cálculos
// ====================================================================

float GestorPedidos::custoPecas(const Pedido& p) const {
    float soma = 0.0f;
    for (int i = 0; i < p.nIntervencoes; i++) soma += p.intervencoes[i].custoPeca;
    return soma;
}

float GestorPedidos::horasTotais(const Pedido& p) const {
    float soma = 0.0f;
    for (const Intervencao* it = p.intervencoes; it != p.intervencoes + p.nIntervencoes; ++it) {
        soma += it->horas;
    }
    return soma;
}

float GestorPedidos::custoPedido(const Pedido& p) const {
    return custoPecas(p) + horasTotais(p) * taxaHoraria;
}

Estatisticas GestorPedidos::calcularEstatisticas() const {
    Estatisticas e;
    e.total = nPedidos;
    int fechados = 0;
    long somaDias = 0;

    for (int i = 0; i < nPedidos; i++) {
        const Pedido& p = pedidos[i];
        e.porEstado[static_cast<int>(p.estado)]++;
        e.porPrioridade[static_cast<int>(p.prioridade)]++;

        bool terminado = (p.estado == Estado::Concluido || p.estado == Estado::Entregue);
        if (!terminado && p.prioridade == Prioridade::Urgente) e.urgentesPendentes++;
        if (terminado) {
            fechados++;
            e.faturacaoTotal += custoPedido(p);
            somaDias += diasEntre(p.dataAbertura, p.dataFecho);
        }
    }
    if (fechados > 0) {   // evita divisão por zero
        e.tempoMedioDias = static_cast<float>(somaDias) / fechados;
        e.custoMedio = e.faturacaoTotal / fechados;
    }
    return e;
}

// ====================================================================
//  Ficheiros (formato de texto simples, campos separados por '|')
// ====================================================================

// Para guardar texto livre numa linha, "escapamos" os caracteres especiais.
static std::string escapar(const std::string& s) {
    std::string r;
    for (char c : s) {
        if (c == '\\')      r += "\\\\";
        else if (c == '|')  r += "\\p";
        else if (c == '\n') r += "\\n";
        else if (c == '\r') { /* ignora */ }
        else                r += c;
    }
    return r;
}

static std::string desescapar(const std::string& s) {
    std::string r;
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] == '\\' && i + 1 < s.size()) {
            char n = s[++i];
            if (n == 'p') r += '|';
            else if (n == 'n') r += '\n';
            else r += n;
        } else {
            r += s[i];
        }
    }
    return r;
}

static std::vector<std::string> dividir(const std::string& linha) {
    std::vector<std::string> partes;
    std::string atual;
    for (char c : linha) {
        if (c == '|') { partes.push_back(atual); atual.clear(); }
        else atual += c;
    }
    partes.push_back(atual);
    return partes;
}

// Conversões com validação (strtol/strtof dizem onde pararam).
static bool paraInt(const std::string& s, long& out) {
    if (s.empty()) return false;
    char* fim = nullptr;
    out = std::strtol(s.c_str(), &fim, 10);
    return *fim == '\0';
}

static bool paraFloat(const std::string& s, float& out) {
    if (s.empty()) return false;
    char* fim = nullptr;
    out = std::strtof(s.c_str(), &fim);
    return *fim == '\0';
}

bool GestorPedidos::guardar(const std::string& caminho, std::string& erro) const {
    std::ofstream f(caminho);
    if (!f) { erro = "Não foi possível abrir o ficheiro para escrita: " + caminho; return false; }

    f << "ASSISTENCIA_TECNICA|1\n";
    f << "CONFIG|" << taxaHoraria << "|" << proximoId << "\n";
    for (int i = 0; i < nPedidos; i++) {
        const Pedido& p = pedidos[i];
        f << "P|" << p.id << "|" << escapar(p.cliente) << "|" << escapar(p.equipamento) << "|"
          << escapar(p.avaria) << "|" << escapar(p.diagnostico) << "|"
          << static_cast<int>(p.prioridade) << "|" << static_cast<int>(p.estado) << "|"
          << static_cast<long long>(p.dataAbertura) << "|" << static_cast<long long>(p.dataFecho) << "|"
          << escapar(p.contacto) << "|" << escapar(p.vendedor) << "|" << escapar(p.tecnico) << "\n";
        for (int k = 0; k < p.nIntervencoes; k++) {
            const Intervencao& it = p.intervencoes[k];
            f << "I|" << escapar(it.descricao) << "|" << escapar(it.peca) << "|"
              << it.custoPeca << "|" << it.horas << "\n";
        }
    }
    f.flush();
    if (!f) { erro = "Erro ao escrever no ficheiro."; return false; }
    return true;
}

bool GestorPedidos::carregar(const std::string& caminho, std::string& erro) {
    std::ifstream f(caminho);
    if (!f) { erro = "Ficheiro não encontrado: " + caminho; return false; }

    // Leio para um gestor temporário. Se algo correr mal, os dados atuais
    // ficam intactos; se correr bem, troco os conteúdos no fim.
    GestorPedidos temp;
    std::string linha;
    int nLinha = 0;
    bool cabecalho = false;
    Pedido* atual = nullptr;
    long idMax = 0;

    while (std::getline(f, linha)) {
        nLinha++;
        if (!linha.empty() && linha.back() == '\r') linha.pop_back();
        if (linha.empty()) continue;
        std::vector<std::string> c = dividir(linha);
        std::string onde = "Linha " + std::to_string(nLinha) + ": ";

        if (c[0] == "ASSISTENCIA_TECNICA") {
            cabecalho = true;
        } else if (!cabecalho) {
            erro = "O ficheiro não é um ficheiro desta aplicação.";
            return false;
        } else if (c[0] == "CONFIG" && c.size() >= 3) {
            float taxa; long prox;
            if (!paraFloat(c[1], taxa) || taxa < 0 || !paraInt(c[2], prox) || prox < 1) {
                erro = onde + "configuração inválida."; return false;
            }
            temp.taxaHoraria = taxa;
            temp.proximoId = static_cast<int>(prox);
        } else if (c[0] == "P" && c.size() >= 10) {
            long id, prio, est, aber, fecho;
            if (!paraInt(c[1], id) || id < 1 || !paraInt(c[6], prio) || !paraInt(c[7], est) ||
                !paraInt(c[8], aber) || !paraInt(c[9], fecho)) {
                erro = onde + "pedido com números inválidos."; return false;
            }
            if (prio < 0 || prio >= NUM_PRIORIDADES || est < 0 || est >= NUM_ESTADOS) {
                erro = onde + "prioridade ou estado fora dos limites."; return false;
            }
            if (temp.procurarPorId(static_cast<int>(id)) != nullptr) {
                erro = onde + "id de pedido repetido."; return false;
            }
            temp.garantirCapacidade();
            Pedido& novo = temp.pedidos[temp.nPedidos++];
            novo = Pedido();
            novo.id = static_cast<int>(id);
            novo.cliente = desescapar(c[2]);
            novo.equipamento = desescapar(c[3]);
            novo.avaria = desescapar(c[4]);
            novo.diagnostico = desescapar(c[5]);
            novo.prioridade = static_cast<Prioridade>(prio);
            novo.estado = static_cast<Estado>(est);
            novo.dataAbertura = static_cast<std::time_t>(aber);
            novo.dataFecho = static_cast<std::time_t>(fecho);
            if (c.size() >= 13) {   // ficheiros com os campos novos (contacto/vendedor/técnico)
                novo.contacto = desescapar(c[10]);
                novo.vendedor = desescapar(c[11]);
                novo.tecnico = desescapar(c[12]);
            }
            atual = &novo;
            if (id > idMax) idMax = id;
        } else if (c[0] == "I" && c.size() >= 5) {
            float custo, horas;
            if (atual == nullptr) { erro = onde + "intervenção sem pedido."; return false; }
            if (!paraFloat(c[3], custo) || !paraFloat(c[4], horas) ||
                !temp.adicionarIntervencao(atual, desescapar(c[1]), desescapar(c[2]), custo, horas)) {
                erro = onde + "intervenção inválida."; return false;
            }
        } else {
            erro = onde + "linha não reconhecida."; return false;
        }
    }
    if (!cabecalho) { erro = "Ficheiro vazio ou inválido."; return false; }
    if (temp.proximoId <= idMax) temp.proximoId = static_cast<int>(idMax) + 1;

    trocar(temp);   // temp fica com os dados antigos e liberta-os ao sair
    return true;
}

// ====================================================================
//  Dados de demonstração (todos fictícios)
// ====================================================================

void GestorPedidos::carregarDadosDemo() {
    limparTudo();
    const std::time_t agora = std::time(nullptr);
    const std::time_t DIA = 60 * 60 * 24;

    struct Demo {
        const char* cliente; const char* contacto; const char* equip; const char* avaria;
        const char* vendedor; const char* tecnico;
        Prioridade prio; Estado estado; int diasAtras; int diasFecho;
    };
    // Array de structs inicializado de uma só vez.
    static const Demo demo[] = {
        {"Ana Ferreira",  "912 345 678", "Portátil Acer Aspire 5",      "Não liga. Luz de carga acende mas o ecrã fica preto.", "Sofia Ramos",  "Diogo Martins", Prioridade::Alta,    Estado::EmReparacao,   6, 0},
        {"Rui Matos",     "933 210 098", "Telemóvel Samsung Galaxy A52", "Ecrã estalado depois de uma queda.",                  "Bruno Lima",   "Rita Fonseca",  Prioridade::Normal,  Estado::Concluido,    12, 9},
        {"Marta Sousa",   "962 774 512", "PC de secretária (torre)",    "Reinicia sozinho quando abre jogos pesados.",         "Carla Nunes",  "Miguel Torres", Prioridade::Normal,  Estado::EmDiagnostico, 3, 0},
        {"Tiago Pinto",   "918 004 320", "Impressora HP LaserJet 1018",  "Prende o papel e faz barulho.",                       "Sofia Ramos",  "Diogo Martins", Prioridade::Baixa,   Estado::AguardaPecas, 9, 0},
        {"Inês Carvalho", "926 118 745", "MacBook Air 2017",             "Bateria dura menos de uma hora.",                     "Bruno Lima",   "Rita Fonseca",  Prioridade::Normal,  Estado::Entregue,    20, 16},
        {"Pedro Lopes",   "914 620 137", "Servidor NAS Synology",        "Discos em alerta, volume degradado.",                 "Carla Nunes",  "Miguel Torres", Prioridade::Urgente, Estado::EmReparacao,   2, 0},
        {"Sofia Marques", "939 850 461", "Tablet Lenovo Tab M10",        "Não carrega, o cabo parece solto.",                   "Sofia Ramos",  "Diogo Martins", Prioridade::Baixa,   Estado::Aberto,        1, 0},
        {"João Rocha",    "917 302 984", "Consola PlayStation 4",        "Sobreaquece e desliga ao fim de 10 minutos.",         "Bruno Lima",   "Rita Fonseca",  Prioridade::Alta,    Estado::Aberto,        1, 0},
        {"Carla Dias",    "968 441 205", "Portátil Dell Latitude",       "Teclado com teclas que não respondem.",               "Carla Nunes",  "Miguel Torres", Prioridade::Normal,  Estado::Concluido,    8, 5},
        {"Nuno Gomes",    "911 563 072", "Router TP-Link Archer",        "Perde ligação Wi-Fi várias vezes por dia.",           "Sofia Ramos",  "Diogo Martins", Prioridade::Alta,    Estado::EmDiagnostico, 4, 0},
        {"Helena Costa",  "934 019 856", "Monitor Dell 24 polegadas",    "Imagem com listas verticais.",                        "Bruno Lima",   "Rita Fonseca",  Prioridade::Baixa,   Estado::Entregue,    25, 21},
        {"Bruno Alves",   "927 730 119", "Portátil Lenovo ThinkPad",     "Derramou café no teclado. Não arranca.",              "Carla Nunes",  "Miguel Torres", Prioridade::Urgente, Estado::AguardaPecas, 5, 0},
    };

    for (const Demo& d : demo) {
        int id = adicionarPedido(d.cliente, d.equip, d.avaria, d.prio, d.contacto, d.vendedor,
                                 d.tecnico, agora - d.diasAtras * DIA);
        Pedido* p = procurarPorId(id);
        if (p == nullptr) continue;
        p->estado = d.estado;
        if (d.diasFecho > 0) p->dataFecho = agora - d.diasFecho * DIA;
    }

    // Diagnósticos e intervenções para alguns pedidos
    Pedido* p = procurarPorId(1);
    adicionarIntervencao(p, "Teste com outro carregador e memória RAM", "", 0.0f, 0.5f);
    adicionarIntervencao(p, "Substituição do conector DC", "Conector DC", 12.5f, 1.0f);
    p->diagnostico = "Conector de carga danificado; a bateria deixou de receber energia.";

    p = procurarPorId(2);
    adicionarIntervencao(p, "Substituição do ecrã", "Ecrã AMOLED A52", 58.0f, 0.75f);
    p->diagnostico = "Painel partido, touch e imagem a funcionar de forma intermitente.";

    p = procurarPorId(4);
    adicionarIntervencao(p, "Limpeza dos rolos de papel", "", 0.0f, 0.5f);
    adicionarIntervencao(p, "Troca do rolo de tração", "Rolo de tração HP", 18.9f, 1.0f);

    p = procurarPorId(5);
    adicionarIntervencao(p, "Substituição da bateria", "Bateria A1713", 49.0f, 0.5f);

    p = procurarPorId(6);
    adicionarIntervencao(p, "Leitura SMART e backup de segurança", "", 0.0f, 2.0f);
    adicionarIntervencao(p, "Substituição de disco com falhas", "Disco 4 TB NAS", 112.0f, 1.0f);

    p = procurarPorId(9);
    adicionarIntervencao(p, "Limpeza do teclado e troca de membrana", "Teclado PT Latitude", 29.0f, 1.0f);

    p = procurarPorId(11);
    adicionarIntervencao(p, "Troca do cabo interno de vídeo (LVDS)", "Cabo LVDS", 9.0f, 0.5f);

    p = procurarPorId(12);
    adicionarIntervencao(p, "Limpeza de líquidos e inspeção da motherboard", "", 0.0f, 2.5f);
    p->diagnostico = "Corrosão em dois condensadores; a aguardar componentes.";
}
