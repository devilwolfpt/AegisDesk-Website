// texturas.h
// Carrega o logótipo, os ícones e as imagens da pasta "recursos/" e cria as
// texturas OpenGL, para poderem ser desenhadas com o Dear ImGui.
// A aplicação continua a funcionar se a pasta "recursos/" não existir:
// simplesmente desenha a interface sem imagens.
#pragma once

#include "imgui.h"

// Todos os ícones usados na interface. A ordem tem de coincidir com a lista
// NOMES_ICONE em texturas.cpp.
enum class Icone {
    NovoPedido = 0,
    Pesquisa,
    Guardar,
    Recarregar,
    Pasta,
    Sair,
    Ajuda,
    Sobre,
    Detalhe,
    Estatisticas,
    IA,
    Remover,
    Adicionar,
    Contacto,
    Vendedor,
    Tecnico,
    Gerar,
    Verificar,
    Copiar,
    Configuracoes,
    Estado,
    Prioridade,
    Data,
    Euro,
    Cliente,
    Equipamento,
    Fechar,
    Historico,
    Loja,
    Contagem          // último: quantos ícones existem
};

// Tudo o que a interface desenha com textura (logótipo, fotos e ícones).
struct Texturas {
    ImTextureID logo = ImTextureID_Invalid;        // logótipo da Neuria
    ImTextureID banner = ImTextureID_Invalid;      // fotografia do diálogo "Sobre"
    ImTextureID semPedido = ImTextureID_Invalid;   // fotografia do painel vazio
    ImTextureID icones[static_cast<int>(Icone::Contagem)] = {};
    bool carregado = false;
};

// Cria as texturas OpenGL. Tem de ser chamada DEPOIS de criar a janela e de
// ImGui_ImplOpenGL3_Init (usa as funções OpenGL carregadas por esse backend).
void carregarTexturas(Texturas& t);

// Apaga as texturas da memória gráfica. Chamar antes de destruir a janela.
void libertarTexturas(Texturas& t);

// Devolve a textura do ícone; ImTextureID_Invalid se não foi carregada.
ImTextureID icone(const Texturas& t, Icone i);

// true se a textura pode ser desenhada.
inline bool texturaValida(ImTextureID t) { return t != ImTextureID_Invalid; }
