# Sistema de Assistência Técnica (UFCD 0810 – Projeto 03)

Aplicação em C++17 com **interface gráfica** (Dear ImGui + GLFW) para gerir pedidos de reparação
de equipamentos: abrir pedidos, definir prioridade, registar diagnóstico, intervenções e peças,
acompanhar o estado e ver estatísticas. Inclui um **assistente de IA local** que usa um modelo no
formato **GGUF** (via llama.cpp) para sugerir diagnósticos e redigir mensagens ao cliente.
A IA é opcional: sem modelo, a aplicação funciona na mesma (e sem Internet).

> Todos os dados são fictícios.

## Como compilar

Precisa de: **CMake ≥ 3.16**, um compilador C++17 e **Git**. As bibliotecas (GLFW, Dear ImGui e
llama.cpp) são descarregadas automaticamente pelo CMake na primeira compilação, por isso a primeira
vez precisa de Internet e demora alguns minutos (o llama.cpp é grande).

**Windows (Visual Studio 2022 ou Build Tools)** – numa "Developer PowerShell":

```powershell
cmake -S . -B build
cmake --build build --config Release
.\build\Release\assistencia.exe
```

Na compilação, a pasta `recursos/` (logótipo, ícones e fotografias) e o ficheiro
`Neuria Logo.png` são copiados automaticamente para a pasta do executável.

**Linux (Ubuntu/Debian)** – instalar primeiro as dependências do GLFW:

```bash
sudo apt install build-essential cmake git xorg-dev libgl1-mesa-dev
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
./build/assistencia
```

**macOS**: `cmake -S . -B build && cmake --build build -j && ./build/assistencia`

Para compilar **sem IA** (mais rápido): `cmake -S . -B build -DUSE_LLAMA=OFF`

Testes automáticos da lógica: `ctest --test-dir build -C Release --output-on-failure`
(ou executar `testes`). A aplicação deve ser executada a partir da pasta onde quer guardar os dados.

## Como usar

1. Ao abrir pela primeira vez são carregados **12 pedidos de demonstração**. Os dados são gravados
   em `assistencia_dados.dat` ao sair (e em *Ficheiro → Guardar dados*).
2. **Lista (esquerda):** pesquise (por cliente, equipamento, vendedor, técnico ou nº), filtre por
   estado, ordene (usa apontadores para função: nº, prioridade, data, cliente ou **vendedor**) e
   clique numa linha. **+ Novo pedido** abre o formulário (com validação).
3. **Detalhe:** altere estado/prioridade, edite o **contacto do cliente**, o **vendedor** e o
   **técnico responsável**, edite o diagnóstico, adicione/remova intervenções e veja o custo.
4. **Estatísticas:** totais, urgentes por resolver, faturação, custo médio, tempo médio de resolução,
   pedidos/faturação **por vendedor** (com alternância entre as duas métricas), gráfico de entradas dos
   últimos 14 dias, distribuição por estado (donut) e a taxa horária (editável).
5. **Personalização (separador próprio):** escolha visual entre quatro temas (Neuria azul, Aurora
   violeta, Bosque verde e Grafite âmbar) e entre densidade confortável ou compacta; inclui botões para
   consultar os atalhos de teclado e para repor as predefinições. As preferências ficam guardadas em
   `assistencia.cfg`.
6. **Assistente IA:** veja abaixo.
7. **Produtividade:** arraste o divisor entre a lista e o detalhe; `Ctrl+K` abre a paleta de comandos;
   `Ctrl+F` foca a pesquisa; `Ctrl+S` guarda; `Ctrl+E` exporta CSV; `Ctrl+D` duplica o pedido
   selecionado; `Ctrl+Shift+C` copia um resumo; `F1` mostra todos os atalhos. As ações são confirmadas
   por avisos flutuantes (toasts) no canto superior direito.

## Recursos gráficos (logótipo, ícones e imagens)

| Pasta/ficheiro | Conteúdo |
|---|---|
| `Neuria Logo.png` | logótipo da Neuria (mostrado no menu e no diálogo *Ajuda → Sobre*) |
| `recursos/icones/*.png` | 31 ícones dos botões e menus (Material Design Icons, Google – Apache 2.0), convertidos para branco ao serem carregados |
| `recursos/imagens/*.jpg` | fotografias decorativas (diálogo *Sobre* e painel vazio) |
| `recursos/CREDITOS.txt` | origem e licença de todos os recursos |
| `terceiros/stb_image.h` | biblioteca usada para ler PNG/JPEG (domínio público) |

São carregados em `src/texturas.cpp`. Se a pasta `recursos/` não existir, a aplicação funciona na
mesma, apenas sem imagens. Para trocar um ícone, basta substituir o PNG com o mesmo nome
(o ficheiro tem de ser um PNG; o tamanho natural é 48×48 e é desenhado a ~18 px).

## Assistente de IA (modelo GGUF)

1. Descarregue um modelo **instruct** pequeno em GGUF (de preferência quantizado `Q4_K_M`), por exemplo
   do Hugging Face: *Qwen2.5-1.5B-Instruct-GGUF*, *Llama-3.2-1B-Instruct-GGUF* ou
   *gemma-3-1b-it-GGUF*. Modelos de 1–3 mil milhões de parâmetros correm bem só com CPU
   e 8 GB de RAM. Guarde o ficheiro `.gguf` no PC (não é preciso Internet depois disso).
2. No separador **Assistente IA** escreva o caminho do ficheiro e clique **Carregar modelo**.
3. Escolha um pedido na lista, escolha *Diagnóstico sugerido* ou *Mensagem para o cliente* e clique **Gerar**.
   O texto aparece à medida que é gerado; pode **Parar** a qualquer momento.
4. **Usar como diagnóstico** copia a sugestão para o pedido. A IA só sugere — o técnico confirma.

O modelo corre numa thread própria, por isso a janela não bloqueia.
O caminho do modelo fica guardado em `assistencia.cfg`.

## Estrutura do projeto

| Ficheiro | Conteúdo |
|---|---|
| `src/modelos.h` | `struct Pedido`, `struct Intervencao`, enums de estado e prioridade |
| `src/gestor.h/.cpp` | `GestorPedidos`: array dinâmico, CRUD, pesquisa, ordenação, cálculos, ficheiros |
| `src/assistente_ia.h/.cpp` | `AssistenteIA`: carregar GGUF, gerar texto em thread, prompts |
| `src/interface.h/.cpp` | Todas as janelas e botões (Dear ImGui) |
| `src/texturas.h/.cpp` | Carrega o logótipo, os ícones e as fotografias (PNG/JPEG) e cria as texturas |
| `recursos/`, `terceiros/` | ícones, fotografias, créditos e a biblioteca stb_image |
| `src/main.cpp` | Abre a janela e corre o ciclo principal |
| `tests/testes.cpp` | 74 verificações automáticas (plano de testes T01–T10) |
| `DOCUMENTACAO.md` | Mapas pedidos na ficha: funções, conteúdos UFCD, testes, extensões |
