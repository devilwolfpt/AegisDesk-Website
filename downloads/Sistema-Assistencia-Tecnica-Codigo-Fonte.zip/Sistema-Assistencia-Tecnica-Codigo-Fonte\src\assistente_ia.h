// assistente_ia.h
// Assistente de IA local: carrega um modelo no formato GGUF com a biblioteca
// llama.cpp e gera texto SEM precisar de Internet.
//
// O carregamento do modelo e a geração de texto demoram segundos, por isso
// correm numa thread separada; assim a janela não "congela". A interface
// só pergunta o estado e vai buscar o texto que já foi gerado.
#pragma once

#include <string>

#include "modelos.h"

enum class EstadoIA { SemModelo, ACarregar, Pronto, AGerar, Erro };

enum class TipoPedidoIA {
    DiagnosticoSugerido,   // causas prováveis e testes a fazer
    MensagemParaCliente    // texto educado a informar o cliente do estado
};

class AssistenteIA {
public:
    AssistenteIA();
    ~AssistenteIA();
    AssistenteIA(const AssistenteIA&) = delete;
    AssistenteIA& operator=(const AssistenteIA&) = delete;

    // true se o programa foi compilado com llama.cpp (USE_LLAMA=ON)
    static bool compiladoComSuporte();

    // Todas estas funções devolvem logo (trabalho feito em segundo plano).
    void carregarModelo(const std::string& caminhoGguf, int nThreads, int tamanhoContexto);
    void descarregarModelo();
    void gerar(const std::string& instrucaoSistema, const std::string& pergunta, int maxTokens);
    void parar();   // pede para interromper a geração em curso

    EstadoIA estado() const;
    std::string mensagem() const;       // estado em texto / mensagem de erro
    std::string textoGerado() const;    // cópia do texto produzido até agora
    std::string nomeModelo() const;     // nome do ficheiro carregado

private:
    struct Impl;      // detalhes escondidos (inclui o llama.h só no .cpp)
    Impl* impl;       // apontador para a implementação (new no construtor, delete no destrutor)
};

// Monta as instruções e a pergunta para cada tipo de pedido à IA.
std::string instrucaoSistema(TipoPedidoIA tipo);
std::string montarPergunta(TipoPedidoIA tipo, const Pedido& p, float custoAtual);
