// interface.cpp
#define IMGUI_DEFINE_MATH_OPERATORS
#include "interface.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <map>
#include <thread>
#include <vector>

#include "imgui.h"
#include "misc/cpp/imgui_stdlib.h"

// Verdadeiro se o tipo de letra carregado tem o símbolo € (definido no main.cpp).
bool fonteSuportaEuro = false;

// Tipo de letra semibold usado nos títulos (definido no main.cpp).
ImFont *fonteTitulo = nullptr;

// ====================================================================
//  Utilitários
// ====================================================================

static const char *NOMES_ORDEM[] = {"Nº do pedido", "Prioridade (urgentes primeiro)", "Data (mais antigos primeiro)",
                                    "Cliente (A-Z)", "Vendedor (A-Z)"};
static const int N_ORDEMS = static_cast<int>(sizeof(NOMES_ORDEM) / sizeof(NOMES_ORDEM[0]));
static const int TAMANHOS_CONTEXTO[] = {1024, 2048, 4096};

static ImVec4 corPrioridade(Prioridade p)
{
    switch (p)
    {
    case Prioridade::Baixa:
        return ImVec4(0.560f, 0.639f, 0.776f, 1.0f); // azul-acinzentado
    case Prioridade::Normal:
        return ImVec4(0.847f, 0.894f, 0.965f, 1.0f);
    case Prioridade::Alta:
        return ImVec4(1.000f, 0.722f, 0.302f, 1.0f); // âmbar
    case Prioridade::Urgente:
        return ImVec4(1.000f, 0.420f, 0.471f, 1.0f); // vermelho suave
    }
    return ImVec4(1, 1, 1, 1);
}

static ImVec4 corEstado(Estado e)
{
    switch (e)
    {
    case Estado::Aberto:
        return ImVec4(0.349f, 0.655f, 1.000f, 1.0f); // azul
    case Estado::EmDiagnostico:
        return ImVec4(0.706f, 0.608f, 1.000f, 1.0f); // lilás
    case Estado::AguardaPecas:
        return ImVec4(1.000f, 0.784f, 0.341f, 1.0f); // âmbar
    case Estado::EmReparacao:
        return ImVec4(0.263f, 0.851f, 0.776f, 1.0f); // turquesa
    case Estado::Concluido:
        return ImVec4(0.341f, 0.851f, 0.545f, 1.0f); // verde
    case Estado::Entregue:
        return ImVec4(0.576f, 0.643f, 0.769f, 1.0f); // cinzento-azul
    }
    return ImVec4(1, 1, 1, 1);
}

static void notificar(EstadoUI &ui, const std::string &texto, int tipo = 0,
                      const char *titulo = nullptr)
{
    if (texto.empty())
        return;
    const double agora = ImGui::GetTime();

    // Se a última notificação for igual, basta reiniciá-la (evita duplicados
    // quando o utilizador mexe rapidamente nos mesmos controlos).
    if (!ui.avisos.empty() && ui.avisos.back().texto == texto)
    {
        ui.avisos.back().inicio = agora;
        ui.avisos.back().tipo = tipo;
        return;
    }

    static const char *TITULOS[] = {"Informação", "Concluído", "Erro", "Atenção"};
    Aviso a;
    a.titulo = (titulo != nullptr) ? titulo : TITULOS[std::clamp(tipo, 0, 3)];
    a.texto = texto;
    a.tipo = std::clamp(tipo, 0, 3);
    a.inicio = agora;
    ui.avisos.push_back(a);
    if (ui.avisos.size() > 3)
        ui.avisos.erase(ui.avisos.begin());
}

static void mostrarMensagem(EstadoUI &ui, const std::string &texto, int tipo = 0)
{
    ui.mensagemEstado = texto;
    ui.mensagemAte = ImGui::GetTime() + 4.0;
    notificar(ui, texto, tipo);
}

static std::string euros(float v)
{
    char buf[32];
    // O tipo de letra por defeito do ImGui não tem o símbolo €; nesse caso escrevemos "EUR".
    std::snprintf(buf, sizeof(buf), fonteSuportaEuro ? "%.2f €" : "%.2f EUR", v);
    return buf;
}

// Combo box simples para os enums (devolve true se o valor mudou).
static bool comboNomes(const char *rotulo, int &indice, int quantos, const char *(*nome)(int))
{
    bool mudou = false;
    if (ImGui::BeginCombo(rotulo, nome(indice)))
    {
        for (int i = 0; i < quantos; i++)
        {
            if (ImGui::Selectable(nome(i), i == indice))
            {
                if (i != indice)
                    mudou = true;
                indice = i;
            }
        }
        ImGui::EndCombo();
    }
    return mudou;
}

static const char *nomeEstadoInt(int i) { return nomeEstado(static_cast<Estado>(i)); }
static const char *nomePrioridadeInt(int i) { return nomePrioridade(static_cast<Prioridade>(i)); }

// ====================================================================
//  Ícones e imagens (texturas carregadas em texturas.cpp)
// ====================================================================

// Tamanho dos ícones nos botões e no menu.
static const float TAM_ICONE = 18.0f;

// Aplica o "esbatimento" do ImGui a uma cor desenhada manualmente.
static ImU32 corPossivelmenteDesativada(ImU32 cor, bool itemAtivo)
{
    if (itemAtivo)
        return cor;
    float alfa = ((cor >> 24) & 0xFF) / 255.0f;
    alfa *= ImGui::GetStyle().DisabledAlpha;
    return (cor & 0x00FFFFFFu) | ((static_cast<ImU32>(alfa * 255.0f + 0.5f)) << 24);
}

// Largura que um botãoComIcone vai ocupar (para o colocar à direita, etc.).
static float larguraBotao(const char *rotulo, bool temIcone)
{
    const ImGuiStyle &e = ImGui::GetStyle();
    float larguraIcone = temIcone ? TAM_ICONE + e.ItemSpacing.x : 0.0f;
    return larguraIcone + ImGui::CalcTextSize(rotulo).x + e.FramePadding.x * 2;
}

// Botão com um ícone PNG à esquerda. Desenhamos nós próprios o botão (fundo,
// ícone e texto) para poder juntar a imagem ao rótulo.
static bool botaoComIcone(const Texturas &tex, Icone ic, const char *rotulo)
{
    ImTextureID id = icone(tex, ic);
    const ImGuiStyle &e = ImGui::GetStyle();
    ImVec2 tamanho(larguraBotao(rotulo, texturaValida(id)), ImGui::GetFrameHeight());

    ImGui::PushID(rotulo);
    bool premido = ImGui::InvisibleButton("##botao", tamanho);
    bool ativo = (ImGui::GetItemFlags() & ImGuiItemFlags_Disabled) == 0; // desativado por BeginDisabled?
    bool sobre = ImGui::IsItemHovered();
    bool premidoAgora = ImGui::IsItemActive();
    ImVec2 a = ImGui::GetItemRectMin(), b = ImGui::GetItemRectMax();

    ImGuiCol qualCor = !ativo         ? ImGuiCol_Button
                       : premidoAgora ? ImGuiCol_ButtonActive
                       : sobre        ? ImGuiCol_ButtonHovered
                                      : ImGuiCol_Button;
    ImDrawList *dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(a, b, corPossivelmenteDesativada(ImGui::GetColorU32(qualCor), ativo), e.FrameRounding);

    float x = a.x + e.FramePadding.x;
    if (texturaValida(id))
    {
        float yIcone = a.y + (tamanho.y - TAM_ICONE) * 0.5f;
        dl->AddImage(id, ImVec2(x, yIcone), ImVec2(x + TAM_ICONE, yIcone + TAM_ICONE));
        x += TAM_ICONE + e.ItemSpacing.x;
    }
    ImVec2 tamTexto = ImGui::CalcTextSize(rotulo);
    dl->AddText(ImVec2(x, a.y + (tamanho.y - tamTexto.y) * 0.5f),
                corPossivelmenteDesativada(ImGui::GetColorU32(ImGuiCol_Text), ativo), rotulo);
    ImGui::PopID();
    return premido;
}

// Item de menu com um ícone à esquerda.
static bool menuItemComIcone(const Texturas &tex, Icone ic, const char *rotulo,
                             bool selecionado = false, bool ativo = true)
{
    ImTextureID id = icone(tex, ic);
    if (texturaValida(id))
    {
        float tam = ImGui::GetTextLineHeight();
        ImGui::Image(id, ImVec2(tam, tam));
        ImGui::SameLine();
    }
    return ImGui::MenuItem(rotulo, nullptr, selecionado, ativo);
}

// --------------------------------------------------------------------
//  Elementos visuais reutilizáveis (tema Neuria)
// --------------------------------------------------------------------

static ImVec4 COR_AZUL(0.176f, 0.435f, 1.000f, 1.0f);   // #2D6FFF
static ImVec4 COR_CIANO(0.373f, 0.816f, 0.961f, 1.0f);  // #5FD0F5
static const ImVec4 COR_VERDE(0.341f, 0.851f, 0.545f, 1.0f);
static const ImVec4 COR_VERMELHO(0.949f, 0.353f, 0.400f, 1.0f);
static const ImVec4 COR_AMBAR(1.000f, 0.722f, 0.302f, 1.0f);
static const ImVec4 COR_CARTAO(0.071f, 0.106f, 0.184f, 1.0f);  // cartões sobre os painéis
static const char *NOMES_TEMA[] = {"Neuria - Azul", "Aurora - Violeta", "Bosque - Verde", "Grafite - Âmbar"};
static int temaAtual = 0;
static float escalaEstiloAtual = 1.0f;
static bool modoCompactoAtual = false;
static constexpr float PI = 3.14159265358979323846f;

// Paleta de cada tema. Centralizada aqui para que o seletor visual de temas
// use exatamente as mesmas cores que aplicarEstilo().
struct PaletaTema
{
    ImVec4 azul, azulHover, azulAtivo, ciano;
};

static PaletaTema paletaDoTema(int indice)
{
    switch (indice)
    {
    case 1:
        return {ImVec4(0.565f, 0.357f, 0.941f, 1.00f), ImVec4(0.655f, 0.475f, 1.000f, 1.00f),
                ImVec4(0.459f, 0.267f, 0.827f, 1.00f), ImVec4(0.800f, 0.659f, 1.000f, 1.00f)};
    case 2:
        return {ImVec4(0.176f, 0.639f, 0.435f, 1.00f), ImVec4(0.267f, 0.749f, 0.529f, 1.00f),
                ImVec4(0.122f, 0.529f, 0.345f, 1.00f), ImVec4(0.455f, 0.886f, 0.667f, 1.00f)};
    case 3:
        return {ImVec4(1.000f, 0.631f, 0.180f, 1.00f), ImVec4(1.000f, 0.733f, 0.310f, 1.00f),
                ImVec4(0.851f, 0.486f, 0.098f, 1.00f), ImVec4(1.000f, 0.831f, 0.478f, 1.00f)};
    default:
        return {ImVec4(0.176f, 0.435f, 1.000f, 1.00f), ImVec4(0.267f, 0.529f, 1.000f, 1.00f),
                ImVec4(0.122f, 0.345f, 0.878f, 1.00f), ImVec4(0.373f, 0.816f, 0.961f, 1.00f)};
    }
}

static ImU32 corComAlfa(const ImVec4 &cor, float alfa)
{
    return ImGui::GetColorU32(ImVec4(cor.x, cor.y, cor.z, alfa));
}

static ImFont *fonteDosTitulos()
{
    return fonteTitulo != nullptr ? fonteTitulo : ImGui::GetFont();
}

static void pushFonteTitulo(float fator = 1.0f)
{
    ImGui::PushFont(fonteDosTitulos(), ImGui::GetStyle().FontSizeBase * fator);
}

static void textoDesenhado(ImDrawList *dl, ImVec2 pos, float tamanho, const ImVec4 &cor, const char *texto,
                           ImFont *fonte = nullptr)
{
    dl->AddText(fonte != nullptr ? fonte : ImGui::GetFont(), tamanho, pos, ImGui::GetColorU32(cor), texto);
}

static ImVec2 medidaTexto(const char *texto, float tamanho, ImFont *fonte = nullptr)
{
    return (fonte != nullptr ? fonte : ImGui::GetFont())->CalcTextSizeA(tamanho, FLT_MAX, 0.0f, texto);
}

// Desenha texto com quebra de linha (usado nos avisos, onde não há widgets).
// Devolve a altura total ocupada.
static float desenharTextoQuebrado(ImDrawList *dl, ImFont *fonte, float tamanho,
                                   ImVec2 pos, const ImVec4 &cor, const std::string &texto,
                                   float largura)
{
    if (texto.empty())
        return 0.0f;
    ImU32 cor32 = ImGui::GetColorU32(cor);
    const char *inicio = texto.c_str();
    const char *fimTexto = inicio + texto.size();
    float y = pos.y;
    float alturaLinha = fonte->CalcTextSizeA(tamanho, FLT_MAX, 0.0f, "Ag").y * 1.12f;
    while (inicio < fimTexto)
    {
        const char *fim = fonte->CalcWordWrapPosition(tamanho, inicio, fimTexto, largura);
        if (fim == inicio)
            fim = inicio + 1;
        dl->AddText(fonte, tamanho, ImVec2(pos.x, y), cor32, inicio, fim);
        y += alturaLinha;
        inicio = fim;
        while (inicio < fimTexto && (*inicio == ' ' || *inicio == '\n'))
            ++inicio;
    }
    return y - pos.y;
}

// "Pílula" colorida usada para estados e prioridades.
static void pilula(const char *texto, const ImVec4 &cor)
{
    float tamanhoTexto = ImGui::GetFontSize() * 0.76f;
    ImVec2 medida = medidaTexto(texto, tamanhoTexto);
    ImVec2 margem(8.0f, 3.5f);
    ImVec2 tamanho(medida.x + margem.x * 2, medida.y + margem.y * 2);
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::Dummy(tamanho);

    ImDrawList *dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(pos, pos + tamanho, corComAlfa(cor, 0.16f), tamanho.y * 0.5f);
    dl->AddRect(pos, pos + tamanho, corComAlfa(cor, 0.42f), tamanho.y * 0.5f);
    textoDesenhado(dl, ImVec2(pos.x + margem.x, pos.y + margem.y - 1), tamanhoTexto, cor, texto);
}

static void pilulaEstado(Estado e) { pilula(nomeEstado(e), corEstado(e)); }
static void pilulaPrioridade(Prioridade p) { pilula(nomePrioridade(p), corPrioridade(p)); }

// Título de secção com uma barra ciano à esquerda.
static void inicioSeccao(const char *titulo)
{
    ImGui::Spacing();
    float tamanho = ImGui::GetFontSize() * 1.02f;
    ImVec2 medida = medidaTexto(titulo, tamanho);
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(0, medida.y));

    ImDrawList *dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(pos + ImVec2(0, 3), pos + ImVec2(3, medida.y - 2), corComAlfa(COR_CIANO, 0.9f), 2.0f);
    textoDesenhado(dl, pos + ImVec2(12, 0), tamanho, ImGui::GetStyleColorVec4(ImGuiCol_Text), titulo, fonteDosTitulos());
    ImGui::Separator();
}

static void textoCentrado(const char *texto, const ImVec4 &cor, float fator = 1.0f, bool forte = false)
{
    float tamanho = ImGui::GetFontSize() * fator;
    ImFont *fonte = forte ? fonteDosTitulos() : nullptr;
    ImVec2 medida = medidaTexto(texto, tamanho, fonte);
    float disponivel = ImGui::GetContentRegionAvail().x;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(0, medida.y));
    textoDesenhado(ImGui::GetWindowDrawList(),
                   ImVec2(pos.x + (disponivel - medida.x) * 0.5f, pos.y), tamanho, cor, texto, fonte);
}

// Fundo de "cartão" arredondado.
static void fundoCartao(ImVec2 pos, ImVec2 tamanho, const ImVec4 &corBorda, float raio = 10.0f)
{
    ImDrawList *dl = ImGui::GetWindowDrawList();
    // Sombra suave + corpo do cartão.
    dl->AddRectFilled(pos + ImVec2(0, 4), pos + tamanho + ImVec2(0, 4), IM_COL32(0, 0, 0, 52), raio);
    dl->AddRectFilled(pos, pos + tamanho, ImGui::GetColorU32(COR_CARTAO), raio);

    // Brilho discreto no topo (dá profundidade sem distrair).
    ImVec2 brilhoA(pos.x + raio, pos.y + 1);
    ImVec2 brilhoB(pos.x + tamanho.x - raio, pos.y + tamanho.y * 0.58f);
    if (brilhoB.x > brilhoA.x && brilhoB.y > brilhoA.y)
        dl->AddRectFilledMultiColor(brilhoA, brilhoB, corComAlfa(COR_AZUL, 0.11f),
                                    corComAlfa(COR_CIANO, 0.045f), IM_COL32(0, 0, 0, 0),
                                    IM_COL32(0, 0, 0, 0));

    dl->AddRectFilled(ImVec2(pos.x + raio, pos.y + 1), ImVec2(pos.x + tamanho.x - raio, pos.y + 1.6f),
                      corComAlfa(corBorda, 0.62f), 1.0f);
    dl->AddRect(pos, pos + tamanho, corComAlfa(corBorda, 0.38f), raio);
}

// Cartão de indicador (estatísticas): valor grande, rótulo e ícone.
static void cartaoKPI(const Texturas &tex, Icone ic, const char *valor, const char *rotulo,
                      const ImVec4 &cor, float largura, const char *dica = nullptr,
                      const char *nota = nullptr)
{
    float fs = ImGui::GetFontSize();
    float altura = fs * 6.0f;
    ImVec2 base = ImGui::GetCursorScreenPos();

    ImGui::PushID(rotulo);
    ImGui::InvisibleButton("##kpi", ImVec2(largura, altura));
    bool sobre = ImGui::IsItemHovered();
    ImGui::PopID();
    if (sobre && dica != nullptr && dica[0] != '\0')
        ImGui::SetTooltip("%s", dica);

    float dy = sobre ? -fs * 0.12f : 0.0f;
    ImVec2 pos = base + ImVec2(0, dy);
    ImVec2 canto = pos + ImVec2(largura, altura);
    ImDrawList *dl = ImGui::GetWindowDrawList();

    // Sombra + corpo. Ao passar o rato o cartão "levanta" ligeiramente.
    dl->AddRectFilled(pos + ImVec2(0, sobre ? 6.0f : 4.0f),
                      canto + ImVec2(0, sobre ? 6.0f : 4.0f),
                      IM_COL32(0, 0, 0, sobre ? 78 : 46), 11.0f);
    dl->AddRectFilled(pos, canto, ImGui::GetColorU32(sobre ? ImGui::GetStyleColorVec4(ImGuiCol_FrameBg) : COR_CARTAO), 11.0f);

    // Brilho no canto superior direito, recortado para não sair do cartão.
    dl->PushClipRect(pos + ImVec2(9, 9), canto - ImVec2(9, 9), true);
    dl->AddCircleFilled(ImVec2(canto.x - fs * 0.5f, pos.y + fs * 0.5f), altura * 0.92f,
                        corComAlfa(cor, sobre ? 0.10f : 0.055f), 40);
    dl->PopClipRect();

    dl->AddRect(pos, canto, corComAlfa(cor, sobre ? 0.72f : 0.32f), 11.0f);
    dl->AddRectFilled(pos + ImVec2(0, fs * 0.65f), pos + ImVec2(3, altura - fs * 0.65f),
                      corComAlfa(cor, 0.95f), 2.0f);

    float margem = fs * 0.75f;
    float xTexto = pos.x + margem + 4;

    // Ícone no canto superior esquerdo, dentro de um pequeno "azulejo".
    float ladoIcone = fs * 1.80f;
    ImVec2 pIcone(xTexto, pos.y + margem);
    dl->AddRectFilled(pIcone, pIcone + ImVec2(ladoIcone, ladoIcone), corComAlfa(cor, 0.16f), 8.0f);
    dl->AddRect(pIcone, pIcone + ImVec2(ladoIcone, ladoIcone), corComAlfa(cor, 0.25f), 8.0f);
    ImTextureID id = icone(tex, ic);
    if (texturaValida(id))
    {
        float dentro = ladoIcone * 0.24f;
        dl->AddImage(id, pIcone + ImVec2(dentro, dentro),
                     pIcone + ImVec2(ladoIcone - dentro, ladoIcone - dentro));
    }

    float tamValor = fs * 1.40f;
    float baseValor = pIcone.y + ladoIcone + fs * 0.30f;
    textoDesenhado(dl, ImVec2(xTexto, baseValor), tamValor, cor, valor, fonteDosTitulos());

    float tamRotulo = fs * 0.76f;
    textoDesenhado(dl, ImVec2(xTexto, pos.y + altura - margem - tamRotulo * 1.15f),
                   tamRotulo, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), rotulo);

    if (nota != nullptr && nota[0] != '\0')
    {
        float tamNota = fs * 0.66f;
        ImVec2 medida = medidaTexto(nota, tamNota);
        textoDesenhado(dl, ImVec2(canto.x - margem - medida.x, pos.y + margem), tamNota,
                       ImVec4(cor.x, cor.y, cor.z, 0.82f), nota);
    }

    // Linha inferior muito discreta (dá o "acabamento" de cartão).
    dl->AddRectFilled(ImVec2(pos.x + 11, canto.y - 3), ImVec2(canto.x - 11, canto.y - 2),
                      corComAlfa(cor, 0.22f), 1.0f);
}

// Cores dos botões (o botaoComIcone usa as cores ImGuiCol_Button).
static void pushCorBotao(const ImVec4 &cor)
{
    auto subir = [](float v) { return v + 0.10f > 1.0f ? 1.0f : v + 0.10f; };
    auto baixar = [](float v) { return v * 0.78f; };
    ImGui::PushStyleColor(ImGuiCol_Button, cor);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(subir(cor.x), subir(cor.y), subir(cor.z), 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(baixar(cor.x), baixar(cor.y), baixar(cor.z), 1.0f));
}

static void popCorBotao() { ImGui::PopStyleColor(3); }

// Faixa de identidade no topo: logótipo, nome da aplicação e totais.
static void desenharCabecalho(EstadoUI &ui)
{
    float fs = ImGui::GetFontSize();
    float largura = ImGui::GetContentRegionAvail().x;
    float altura = fs * 4.25f;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(largura, altura));

    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 canto = pos + ImVec2(largura, altura);

    // Sombra, corpo e metade superior mais clara (dá profundidade à faixa).
    dl->AddRectFilled(pos + ImVec2(0, 5), canto + ImVec2(0, 5), IM_COL32(0, 0, 0, 80), 12.0f);
    dl->AddRectFilled(pos, canto, ImGui::GetColorU32(ImVec4(0.043f, 0.094f, 0.204f, 1.0f)), 12.0f);
    dl->AddRectFilled(pos, pos + ImVec2(largura, altura * 0.52f),
                      ImGui::GetColorU32(ImVec4(0.055f, 0.125f, 0.271f, 1.0f)), 12.0f,
                      ImDrawFlags_RoundCornersTop);

    // Brilhos decorativos e um reflexo que percorre a faixa lentamente.
    dl->PushClipRect(pos + ImVec2(12, 2), canto - ImVec2(12, 2), true);
    dl->AddCircleFilled(ImVec2(canto.x - largura * 0.16f, pos.y + altura * 0.10f), altura * 0.9f,
                        corComAlfa(COR_AZUL, 0.12f), 48);
    dl->AddCircleFilled(ImVec2(canto.x - largura * 0.05f, pos.y + altura * 0.85f), altura * 0.7f,
                        corComAlfa(COR_CIANO, 0.045f), 48);
    float xBrilho = pos.x - largura * 0.35f +
                    std::fmod(static_cast<float>(ImGui::GetTime()) * 80.0f, largura * 1.65f);
    dl->AddQuadFilled(ImVec2(xBrilho, pos.y), ImVec2(xBrilho + fs * 3.0f, pos.y),
                      ImVec2(xBrilho + fs * 1.2f, canto.y), ImVec2(xBrilho - fs * 1.8f, canto.y),
                      IM_COL32(255, 255, 255, 7));
    dl->PopClipRect();

    dl->AddRect(pos, canto, corComAlfa(COR_AZUL, 0.42f), 12.0f);
    dl->AddRectFilled(ImVec2(pos.x + 18, canto.y - 2), ImVec2(canto.x - 18, canto.y),
                      corComAlfa(COR_CIANO, 0.62f), 1.0f);

    float margem = fs * 0.85f;
    float lado = altura - margem * 2;
    ImVec2 pLogo = pos + ImVec2(margem, margem);

    // Halo suave por trás do logótipo.
    dl->AddCircleFilled(pLogo + ImVec2(lado * 0.5f, lado * 0.5f), lado * 0.72f,
                        corComAlfa(COR_CIANO, 0.09f), 40);
    if (texturaValida(ui.texturas.logo))
    {
        dl->AddImage(ui.texturas.logo, pLogo, pLogo + ImVec2(lado, lado));
    }
    else
    {
        dl->AddRectFilled(pLogo, pLogo + ImVec2(lado, lado), corComAlfa(COR_AZUL, 0.35f), 10.0f);
        textoDesenhado(dl, pLogo + ImVec2(lado * 0.28f, lado * 0.16f), lado * 0.7f, COR_CIANO, "N", fonteDosTitulos());
    }

    float x = pLogo.x + lado + fs * 0.95f;
    float tamTitulo = fs * 1.72f;
    ImVec2 medidaTitulo = medidaTexto("Neuria", tamTitulo);
    float yTitulo = pos.y + margem * 0.28f;
    textoDesenhado(dl, ImVec2(x, yTitulo), tamTitulo, ImGui::GetStyleColorVec4(ImGuiCol_Text), "Neuria", fonteDosTitulos());

    // Pequena etiqueta ao lado do nome.
    float xEtiqueta = x + medidaTitulo.x + fs * 0.55f;
    float yEtiqueta = yTitulo + medidaTitulo.y * 0.22f;
    float tamEtiqueta = fs * 0.60f;
    ImVec2 medidaEtiqueta = medidaTexto("DESKTOP", tamEtiqueta);
    ImVec2 tamEtiquetaCaixa(medidaEtiqueta.x + fs * 0.7f, medidaEtiqueta.y + fs * 0.28f);
    dl->AddRectFilled(ImVec2(xEtiqueta, yEtiqueta), ImVec2(xEtiqueta, yEtiqueta) + tamEtiquetaCaixa,
                      corComAlfa(COR_CIANO, 0.12f), 5.0f);
    dl->AddRect(ImVec2(xEtiqueta, yEtiqueta), ImVec2(xEtiqueta, yEtiqueta) + tamEtiquetaCaixa,
                corComAlfa(COR_CIANO, 0.35f), 5.0f);
    textoDesenhado(dl, ImVec2(xEtiqueta + fs * 0.35f, yEtiqueta + fs * 0.14f), tamEtiqueta,
                   ImVec4(COR_CIANO.x, COR_CIANO.y, COR_CIANO.z, 0.92f), "DESKTOP");

    textoDesenhado(dl, ImVec2(x + 1, yTitulo + medidaTitulo.y + 1), fs * 0.82f,
                   ImVec4(0.690f, 0.800f, 0.941f, 0.92f), "Sistema de Assistência Técnica");

    // Indicadores à direita (só se houver espaço suficiente).
    if (largura > fs * 27.0f)
    {
        Estatisticas e = ui.gestor.calcularEstatisticas();
        char total[64], urgentes[64];
        std::snprintf(total, sizeof(total), "%d pedidos", e.total);
        std::snprintf(urgentes, sizeof(urgentes), "%d urgentes", e.urgentesPendentes);

        // Hora e data atuais (a interface parece "viva").
        std::time_t agora = std::time(nullptr);
        std::tm tmLocal{};
#ifdef _WIN32
        localtime_s(&tmLocal, &agora);
#else
        localtime_r(&agora, &tmLocal);
#endif
        char relogio[32];
        std::strftime(relogio, sizeof(relogio), "%H:%M · %d/%m", &tmLocal);

        float xDireita = canto.x - margem;
        auto chip = [&](const char *texto, const ImVec4 &cor, bool comPonto)
        {
            float tam = fs * 0.78f;
            ImVec2 medida = medidaTexto(texto, tam);
            ImVec2 tamanho(medida.x + fs * (comPonto ? 1.55f : 1.15f), fs * 1.85f);
            ImVec2 a(xDireita - tamanho.x, pos.y + (altura - tamanho.y) * 0.5f);
            dl->AddRectFilled(a, a + tamanho, corComAlfa(cor, 0.15f), tamanho.y * 0.5f);
            dl->AddRect(a, a + tamanho, corComAlfa(cor, 0.40f), tamanho.y * 0.5f);
            float xTexto = a.x + fs * 0.58f;
            if (comPonto)
            {
                float pulso = 0.65f + 0.35f * std::sin(static_cast<float>(ImGui::GetTime()) * 3.1f);
                dl->AddCircleFilled(ImVec2(a.x + fs * 0.60f, tamanho.y * 0.5f + a.y),
                                    fs * 0.30f, corComAlfa(cor, 0.16f * pulso), 20);
                dl->AddCircleFilled(ImVec2(a.x + fs * 0.60f, tamanho.y * 0.5f + a.y),
                                    fs * 0.18f, ImGui::GetColorU32(cor), 16);
                xTexto = a.x + fs * 1.05f;
            }
            textoDesenhado(dl, ImVec2(xTexto, a.y + (tamanho.y - medida.y) * 0.5f), tam, cor, texto);
            xDireita -= tamanho.x + fs * 0.55f;
        };
        chip(relogio, COR_AZUL, false);
        chip(urgentes, e.urgentesPendentes > 0 ? COR_VERMELHO : COR_VERDE, true);
        chip(total, COR_CIANO, true);
    }
}

// Fotografia centrada na largura disponível (usada no painel vazio).
static void imagemCentrada(ImTextureID id, float larguraMaxima, float proporcao)
{
    if (!texturaValida(id))
        return;
    float disponivel = ImGui::GetContentRegionAvail().x;
    float largura = (disponivel < larguraMaxima) ? disponivel : larguraMaxima;
    float altura = largura * proporcao;
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + (disponivel - largura) * 0.5f);
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(largura, altura));

    ImDrawList *dl = ImGui::GetWindowDrawList();
    dl->AddImageRounded(id, pos, pos + ImVec2(largura, altura), ImVec2(0, 0), ImVec2(1, 1),
                        IM_COL32_WHITE, 12.0f);
    dl->AddRect(pos, pos + ImVec2(largura, altura), ImGui::GetColorU32(ImGuiCol_Border), 12.0f);
}

// ====================================================================
//  Decoração de fundo, avisos flutuantes e barra de estado
// ====================================================================

// Fundo do ecrã: gradiente, orbes de luz muito suaves e grelha de pontos.
static void desenharFundoDecorativo()
{
    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetWindowPos();
    ImVec2 tam = ImGui::GetWindowSize();
    ImVec2 canto = p + tam;

    dl->AddRectFilledMultiColor(p, canto, IM_COL32(11, 17, 34, 255), IM_COL32(9, 14, 29, 255),
                                IM_COL32(5, 9, 20, 255), IM_COL32(6, 10, 22, 255));

    float t = static_cast<float>(ImGui::GetTime());
    struct Orbe
    {
        float fx, fy, raio, fase;
    };
    static const Orbe ORBES[] = {
        {0.16f, 0.08f, 0.30f, 0.0f},
        {0.86f, 0.28f, 0.24f, 1.9f},
        {0.58f, 1.02f, 0.32f, 3.6f},
    };

    dl->PushClipRect(p, canto, true);
    for (const Orbe &o : ORBES)
    {
        ImVec2 centro(p.x + tam.x * o.fx + std::sin(t * 0.11f + o.fase) * tam.x * 0.035f,
                      p.y + tam.y * o.fy + std::cos(t * 0.09f + o.fase) * tam.y * 0.030f);
        float raio = std::max(tam.x, tam.y) * o.raio;
        dl->AddCircleFilled(centro, raio, corComAlfa(COR_AZUL, 0.020f), 48);
        dl->AddCircleFilled(centro, raio * 0.62f, corComAlfa(COR_AZUL, 0.024f), 48);
        dl->AddCircleFilled(centro, raio * 0.32f, corComAlfa(COR_CIANO, 0.020f), 40);
    }

    const float passo = 38.0f;
    for (float y = p.y + 18.0f; y < canto.y; y += passo)
        for (float x = p.x + 18.0f; x < canto.x; x += passo)
            dl->AddCircleFilled(ImVec2(x, y), 1.0f, IM_COL32(130, 170, 235, 13), 4);
    dl->PopClipRect();
}

static ImVec4 corDoAviso(int tipo)
{
    switch (tipo)
    {
    case 1:
        return COR_VERDE;
    case 2:
        return COR_VERMELHO;
    case 3:
        return COR_AMBAR;
    default:
        return COR_CIANO;
    }
}

static Icone iconeDoAviso(int tipo)
{
    switch (tipo)
    {
    case 1:
        return Icone::Verificar;
    case 2:
        return Icone::Fechar;
    case 3:
        return Icone::Prioridade;
    default:
        return Icone::Detalhe;
    }
}

// Avisos flutuantes no canto superior direito (entram a deslizar e desvanecem).
static void desenharAvisos(EstadoUI &ui)
{
    const double agora = ImGui::GetTime();

    // Remove os que já expiraram.
    for (int i = static_cast<int>(ui.avisos.size()) - 1; i >= 0; --i)
    {
        if (agora > ui.avisos[i].inicio + ui.avisos[i].duracao + 0.20)
            ui.avisos.erase(ui.avisos.begin() + i);
    }
    if (ui.avisos.empty())
        return;

    const ImGuiViewport *vp = ImGui::GetMainViewport();
    float fs = ImGui::GetFontSize();
    float largura = fs * 21.0f;
    if (largura > vp->WorkSize.x * 0.46f)
        largura = vp->WorkSize.x * 0.46f;
    float altura = fs * 5.10f;
    float xBase = vp->WorkPos.x + vp->WorkSize.x - largura - fs * 0.9f;
    float y = vp->WorkPos.y + fs * 1.8f;
    ImDrawList *dl = ImGui::GetForegroundDrawList();

    for (const Aviso &a : ui.avisos)
    {
        double idade = agora - a.inicio;
        float entrada = static_cast<float>(std::clamp(idade / 0.24, 0.0, 1.0));
        entrada = 1.0f - (1.0f - entrada) * (1.0f - entrada) * (1.0f - entrada);
        float saida = static_cast<float>(std::clamp(
            (a.inicio + a.duracao - agora) / 0.45, 0.0, 1.0));
        float alfa = std::min(entrada, saida);
        if (alfa <= 0.01f)
            continue;

        ImVec4 cor = corDoAviso(a.tipo);
        ImVec2 pos(xBase + (1.0f - entrada) * fs * 3.0f, y);
        ImVec2 canto = pos + ImVec2(largura, altura);

        dl->AddRectFilled(pos + ImVec2(0, 5), canto + ImVec2(0, 5),
                          IM_COL32(0, 0, 0, static_cast<int>(95 * alfa)), 12.0f);
        dl->AddRectFilled(pos, canto, ImGui::GetColorU32(ImVec4(0.043f, 0.067f, 0.125f, 0.98f * alfa)), 12.0f);
        dl->AddRectFilledMultiColor(pos, ImVec2(canto.x, pos.y + altura * 0.55f),
                                    corComAlfa(cor, 0.10f * alfa), corComAlfa(cor, 0.05f * alfa),
                                    IM_COL32(0, 0, 0, 0), IM_COL32(0, 0, 0, 0));
        dl->AddRect(pos, canto, corComAlfa(cor, 0.55f * alfa), 12.0f);
        dl->AddRectFilled(pos + ImVec2(0, 11), pos + ImVec2(4, altura - 11),
                          corComAlfa(cor, 0.95f * alfa), 2.0f);

        float margem = fs * 0.75f;
        float ladoIcone = fs * 2.0f;
        ImVec2 pIcone = pos + ImVec2(margem, margem);
        dl->AddRectFilled(pIcone, pIcone + ImVec2(ladoIcone, ladoIcone), corComAlfa(cor, 0.16f * alfa), 8.0f);
        dl->AddRect(pIcone, pIcone + ImVec2(ladoIcone, ladoIcone), corComAlfa(cor, 0.30f * alfa), 8.0f);
        ImTextureID id = icone(ui.texturas, iconeDoAviso(a.tipo));
        if (texturaValida(id))
        {
            float dentro = ladoIcone * 0.24f;
            dl->AddImage(id, pIcone + ImVec2(dentro, dentro), pIcone + ImVec2(ladoIcone - dentro, ladoIcone - dentro),
                         ImVec2(0, 0), ImVec2(1, 1),
                         IM_COL32(255, 255, 255, static_cast<int>(255 * alfa)));
        }

        float xTexto = pIcone.x + ladoIcone + fs * 0.75f;
        float larguraTexto = canto.x - margem - xTexto;
        textoDesenhado(dl, ImVec2(xTexto, pos.y + margem), fs * 0.88f,
                       ImVec4(cor.x, cor.y, cor.z, 0.98f * alfa), a.titulo.c_str(), fonteDosTitulos());
        desenharTextoQuebrado(dl, ImGui::GetFont(), fs * 0.76f,
                              ImVec2(xTexto, pos.y + margem + fs * 1.20f),
                              ImVec4(0.780f, 0.835f, 0.910f, alfa), a.texto, larguraTexto);

        // Barra de tempo restante.
        float restante = static_cast<float>(std::clamp(
            (a.inicio + a.duracao - agora) / a.duracao, 0.0, 1.0));
        float larguraBarra = (largura - margem * 2.0f) * restante;
        dl->AddRectFilled(ImVec2(pos.x + margem, canto.y - 6), ImVec2(canto.x - margem, canto.y - 4),
                          corComAlfa(cor, 0.16f * alfa), 1.0f);
        if (larguraBarra > 1.0f)
            dl->AddRectFilled(ImVec2(pos.x + margem, canto.y - 6),
                              ImVec2(pos.x + margem + larguraBarra, canto.y - 4),
                              corComAlfa(cor, 0.75f * alfa), 1.0f);

        y += altura + fs * 0.50f;
    }
}

// Barra inferior desenhada à mão (ponto pulsante, mensagem e atalhos).
static void desenharBarraEstado(EstadoUI &ui)
{
    float fs = ImGui::GetFontSize();
    float largura = ImGui::GetContentRegionAvail().x;
    float altura = fs * 2.20f;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(largura, altura));

    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 canto = pos + ImVec2(largura, altura);
    dl->AddRectFilled(pos, canto, ImGui::GetColorU32(ImVec4(0.035f, 0.055f, 0.104f, 1.0f)), 9.0f);
    dl->AddRect(pos, canto, corComAlfa(ImGui::GetStyleColorVec4(ImGuiCol_Border), 0.85f), 9.0f);
    dl->AddRectFilled(pos + ImVec2(10, 0), ImVec2(pos.x + largura * 0.22f, pos.y + 1.5f),
                      corComAlfa(COR_CIANO, 0.35f), 1.0f);

    float pulso = 0.60f + 0.40f * std::sin(static_cast<float>(ImGui::GetTime()) * 3.0f);
    ImVec2 pPonto(pos.x + fs * 0.95f, pos.y + altura * 0.5f);
    dl->AddCircleFilled(pPonto, fs * 0.62f, corComAlfa(COR_CIANO, 0.10f * pulso), 24);
    dl->AddCircleFilled(pPonto, fs * 0.17f, corComAlfa(COR_CIANO, 0.95f), 16);

    bool temMensagem = (ImGui::GetTime() < ui.mensagemAte);
    const char *texto = temMensagem ? ui.mensagemEstado.c_str() : "Pronto.";
    ImVec4 corTexto = temMensagem ? ImGui::GetStyleColorVec4(ImGuiCol_Text)
                                  : ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled);

    const char *dica = "Ctrl+K  comandos   ·   Ctrl+S  guardar";
    bool mostrarDica = largura > fs * 38.0f;
    float xDica = canto.x - fs * 0.95f;
    if (mostrarDica)
    {
        float larguraDica = medidaTexto(dica, fs * 0.72f).x;
        xDica -= larguraDica;
        textoDesenhado(dl, ImVec2(xDica, pos.y + (altura - fs * 0.72f) * 0.5f),
                       fs * 0.72f, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), dica);
        float xSep = xDica - fs * 1.1f;
        dl->AddLine(ImVec2(xSep, pos.y + fs * 0.6f), ImVec2(xSep, canto.y - fs * 0.6f),
                    corComAlfa(ImGui::GetStyleColorVec4(ImGuiCol_Border), 0.9f));
        xDica = xSep - fs * 0.4f;
    }

    ImVec2 medida = medidaTexto(texto, fs * 0.82f);
    dl->PushClipRect(ImVec2(pPonto.x + fs * 0.9f, pos.y),
                     ImVec2(xDica, canto.y), true);
    textoDesenhado(dl, ImVec2(pPonto.x + fs * 0.9f, pos.y + (altura - medida.y) * 0.5f),
                   fs * 0.82f, corTexto, texto);
    dl->PopClipRect();

    // Contagem discreta do lado direito quando não há mensagem ativa.
    if (!temMensagem && largura > fs * 48.0f)
    {
        char info[96];
        std::snprintf(info, sizeof(info), "%d pedidos  ·  %s", ui.gestor.quantidade(),
                      NOMES_ORDEM[ui.criterioOrdem]);
        float larguraInfo = medidaTexto(info, fs * 0.72f).x;
        textoDesenhado(dl, ImVec2(xDica - fs * 1.0f - larguraInfo,
                                  pos.y + (altura - fs * 0.72f) * 0.5f),
                       fs * 0.72f, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), info);
    }
}


// ====================================================================
//  Configuração (ficheiro chave=valor)
// ====================================================================

static const char *FICHEIRO_CFG = "assistencia.cfg";

static void lerConfiguracao(EstadoUI &ui)
{
    std::ifstream f(FICHEIRO_CFG);
    std::string linha;
    while (std::getline(f, linha))
    {
        size_t igual = linha.find('=');
        if (igual == std::string::npos)
            continue;
        std::string chave = linha.substr(0, igual), valor = linha.substr(igual + 1);
        if (chave == "modelo")
            ui.caminhoModelo = valor;
        else if (chave == "dados" && !valor.empty())
            ui.caminhoDados = valor;
        else if (chave == "threads")
        {
            int n = std::atoi(valor.c_str());
            if (n >= 1 && n <= 64)
                ui.nThreads = n;
        }
        else if (chave == "tema")
        {
            int tema = std::atoi(valor.c_str());
            if (tema >= 0 && tema < static_cast<int>(sizeof(NOMES_TEMA) / sizeof(NOMES_TEMA[0])))
                ui.temaInterface = tema;
        }
        else if (chave == "densidade")
        {
            ui.modoCompacto = (std::atoi(valor.c_str()) != 0);
        }
        else if (chave == "lista")
        {
            float fracao = static_cast<float>(std::atof(valor.c_str()));
            if (fracao > 0.30f && fracao < 0.75f)
                ui.fracaoLista = fracao;
        }
    }
}

static void gravarConfiguracao(const EstadoUI &ui)
{
    std::ofstream f(FICHEIRO_CFG);
    f << "modelo=" << ui.caminhoModelo << "\n";
    f << "dados=" << ui.caminhoDados << "\n";
    f << "threads=" << ui.nThreads << "\n";
    f << "tema=" << ui.temaInterface << "\n";
    f << "densidade=" << (ui.modoCompacto ? 1 : 0) << "\n";
    f << "lista=" << ui.fracaoLista << "\n";
}

void iniciarEstado(EstadoUI &ui)
{
    carregarTexturas(ui.texturas); // logótipo, ícones e fotografias (se existirem)

    unsigned int hw = std::thread::hardware_concurrency();
    if (hw > 0)
        ui.nThreads = static_cast<int>(std::max(1u, hw / 2)); // metade dos núcleos
    lerConfiguracao(ui);
    definirTemaInterface(ui.temaInterface);
    definirModoCompacto(ui.modoCompacto);

    std::string erro;
    if (!ui.gestor.carregar(ui.caminhoDados, erro))
    {
        ui.gestor.carregarDadosDemo(); // primeira execução: dados de demonstração
        ui.mensagemEstado = "Dados de demonstração carregados.";
    }
    else
    {
        ui.mensagemEstado = "Dados carregados de " + ui.caminhoDados;
    }
    ui.mensagemAte = 1e18; // fica até ao primeiro evento
}

void terminarEstado(EstadoUI &ui)
{
    std::string erro;
    ui.gestor.guardar(ui.caminhoDados, erro);
    gravarConfiguracao(ui);
    libertarTexturas(ui.texturas); // o OpenGL ainda está ativo nesta altura
}

void aplicarEstilo(float escala)
{
    escalaEstiloAtual = escala;
    ImGuiStyle &s = ImGui::GetStyle();
    s = ImGuiStyle();
    ImGui::StyleColorsDark();

    // Identidade visual da Neuria: azul profundo, azul elétrico e ciano
    // (as cores do logótipo). O objetivo é um aspeto sóbrio, tipo "consola
    // técnica", com painéis arredondados e bom contraste.
    const ImVec4 fundo(0.027f, 0.043f, 0.086f, 1.00f);      // #070B16
    const ImVec4 painel(0.055f, 0.082f, 0.145f, 1.00f);     // #0E1525
    const ImVec4 painelClaro(0.078f, 0.110f, 0.188f, 1.00f);
    const ImVec4 campo(0.086f, 0.125f, 0.208f, 1.00f);      // #162035
    const ImVec4 campoHover(0.110f, 0.157f, 0.255f, 1.00f);
    const ImVec4 campoAtivo(0.130f, 0.188f, 0.310f, 1.00f);
    PaletaTema paleta = paletaDoTema(temaAtual);
    ImVec4 azul = paleta.azul;
    ImVec4 azulHover = paleta.azulHover;
    ImVec4 azulAtivo = paleta.azulAtivo;
    ImVec4 ciano = paleta.ciano;
    COR_AZUL = azul;
    COR_CIANO = ciano;
    const ImVec4 texto(0.898f, 0.929f, 0.976f, 1.00f);
    const ImVec4 textoFraco(0.545f, 0.639f, 0.776f, 1.00f);
    const ImVec4 borda(0.129f, 0.192f, 0.318f, 1.00f);

    ImVec4 *c = s.Colors;
    c[ImGuiCol_Text] = texto;
    c[ImGuiCol_TextDisabled] = textoFraco;
    c[ImGuiCol_WindowBg] = fundo;
    c[ImGuiCol_ChildBg] = painel;
    c[ImGuiCol_PopupBg] = ImVec4(0.043f, 0.067f, 0.125f, 0.98f);
    c[ImGuiCol_Border] = borda;
    c[ImGuiCol_BorderShadow] = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_FrameBg] = campo;
    c[ImGuiCol_FrameBgHovered] = campoHover;
    c[ImGuiCol_FrameBgActive] = campoAtivo;
    c[ImGuiCol_TitleBg] = fundo;
    c[ImGuiCol_TitleBgActive] = painel;
    c[ImGuiCol_TitleBgCollapsed] = fundo;
    c[ImGuiCol_MenuBarBg] = ImVec4(0.031f, 0.051f, 0.102f, 1.00f);
    c[ImGuiCol_ScrollbarBg] = ImVec4(0.031f, 0.051f, 0.102f, 0.60f);
    c[ImGuiCol_ScrollbarGrab] = ImVec4(0.160f, 0.235f, 0.380f, 1.00f);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.215f, 0.310f, 0.490f, 1.00f);
    c[ImGuiCol_ScrollbarGrabActive] = azul;
    c[ImGuiCol_CheckMark] = ciano;
    c[ImGuiCol_SliderGrab] = azul;
    c[ImGuiCol_SliderGrabActive] = ciano;
    c[ImGuiCol_Button] = azul;
    c[ImGuiCol_ButtonHovered] = azulHover;
    c[ImGuiCol_ButtonActive] = azulAtivo;
    c[ImGuiCol_Header] = ImVec4(azul.x, azul.y, azul.z, 0.26f);
    c[ImGuiCol_HeaderHovered] = ImVec4(azul.x, azul.y, azul.z, 0.38f);
    c[ImGuiCol_HeaderActive] = ImVec4(azul.x, azul.y, azul.z, 0.50f);
    c[ImGuiCol_Separator] = borda;
    c[ImGuiCol_SeparatorHovered] = ImVec4(azul.x, azul.y, azul.z, 0.60f);
    c[ImGuiCol_SeparatorActive] = azul;
    c[ImGuiCol_ResizeGrip] = ImVec4(azul.x, azul.y, azul.z, 0.16f);
    c[ImGuiCol_ResizeGripHovered] = ImVec4(azul.x, azul.y, azul.z, 0.45f);
    c[ImGuiCol_ResizeGripActive] = azul;
    c[ImGuiCol_InputTextCursor] = ciano;
    c[ImGuiCol_Tab] = ImVec4(0.055f, 0.082f, 0.145f, 1.00f);
    c[ImGuiCol_TabHovered] = ImVec4(azul.x, azul.y, azul.z, 0.45f);
    c[ImGuiCol_TabSelected] = azul;
    c[ImGuiCol_TabSelectedOverline] = ciano;
    c[ImGuiCol_TabDimmed] = ImVec4(0.047f, 0.071f, 0.129f, 1.00f);
    c[ImGuiCol_TabDimmedSelected] = ImVec4(0.110f, 0.180f, 0.330f, 1.00f);
    c[ImGuiCol_TabDimmedSelectedOverline] = ImVec4(ciano.x, ciano.y, ciano.z, 0.45f);
    c[ImGuiCol_PlotLines] = ciano;
    c[ImGuiCol_PlotLinesHovered] = azulHover;
    c[ImGuiCol_PlotHistogram] = azul;
    c[ImGuiCol_PlotHistogramHovered] = ciano;
    c[ImGuiCol_TableHeaderBg] = ImVec4(0.047f, 0.071f, 0.129f, 1.00f);
    c[ImGuiCol_TableBorderStrong] = borda;
    c[ImGuiCol_TableBorderLight] = ImVec4(0.094f, 0.137f, 0.235f, 1.00f);
    c[ImGuiCol_TableRowBg] = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_TableRowBgAlt] = ImVec4(1.00f, 1.00f, 1.00f, 0.018f);
    c[ImGuiCol_TextLink] = ciano;
    c[ImGuiCol_TextSelectedBg] = ImVec4(azul.x, azul.y, azul.z, 0.40f);
    c[ImGuiCol_DragDropTarget] = ciano;
    c[ImGuiCol_NavCursor] = ciano;
    c[ImGuiCol_NavWindowingHighlight] = ImVec4(1, 1, 1, 0.70f);
    c[ImGuiCol_NavWindowingDimBg] = ImVec4(0, 0, 0, 0.35f);
    c[ImGuiCol_ModalWindowDimBg] = ImVec4(0.008f, 0.016f, 0.039f, 0.72f);

    s.WindowRounding = 0.0f;    // a janela principal ocupa o ecrã inteiro
    s.ChildRounding = 10.0f;
    s.FrameRounding = 7.0f;
    s.GrabRounding = 6.0f;
    s.TabRounding = 8.0f;
    s.PopupRounding = 12.0f;
    s.ScrollbarRounding = 8.0f;
    s.WindowBorderSize = 0.0f;
    s.ChildBorderSize = 1.0f;
    s.PopupBorderSize = 1.0f;
    s.FrameBorderSize = 0.0f;
    s.TabBorderSize = 0.0f;
    s.TabBarBorderSize = 1.0f;
    s.TabBarOverlineSize = 2.0f;
    s.WindowPadding = ImVec2(14, 12);
    s.FramePadding = ImVec2(10, 6);
    s.CellPadding = ImVec2(8, 5);
    s.ItemSpacing = ImVec2(10, 8);
    s.ItemInnerSpacing = ImVec2(7, 6);
    s.IndentSpacing = 18.0f;
    s.ScrollbarSize = 12.0f;
    s.GrabMinSize = 12.0f;
    s.SeparatorTextBorderSize = 1.0f;
    s.SeparatorTextPadding = ImVec2(18, 7);
    s.DisabledAlpha = 0.42f;
    if (modoCompactoAtual)
    {
        s.WindowPadding = ImVec2(12, 9);
        s.FramePadding = ImVec2(8, 4);
        s.CellPadding = ImVec2(6, 3);
        s.ItemSpacing = ImVec2(8, 5);
        s.ItemInnerSpacing = ImVec2(6, 4);
        s.ScrollbarSize = 10.0f;
    }
    s.ScaleAllSizes(escala);
}

void definirTemaInterface(int tema)
{
    temaAtual = std::clamp(tema, 0, static_cast<int>(sizeof(NOMES_TEMA) / sizeof(NOMES_TEMA[0])) - 1);
    aplicarEstilo(escalaEstiloAtual);
}

void definirModoCompacto(bool compacto)
{
    modoCompactoAtual = compacto;
    aplicarEstilo(escalaEstiloAtual);
}

// ====================================================================
//  Ações da aplicação (usadas pelo menu, pela paleta de comandos e pelos botões)
// ====================================================================

static void acaoGuardar(EstadoUI &ui)
{
    std::string erro;
    if (ui.gestor.guardar(ui.caminhoDados, erro))
        mostrarMensagem(ui, "Dados guardados em " + ui.caminhoDados, 1);
    else
        mostrarMensagem(ui, "Erro ao guardar: " + erro, 2);
}

static void acaoRecarregar(EstadoUI &ui)
{
    std::string erro;
    if (ui.gestor.carregar(ui.caminhoDados, erro))
    {
        ui.idSelecionado = -1;
        mostrarMensagem(ui, "Dados carregados de " + ui.caminhoDados, 1);
    }
    else
        mostrarMensagem(ui, "Erro ao carregar: " + erro, 2);
}

static void acaoDemo(EstadoUI &ui)
{
    ui.gestor.carregarDadosDemo();
    ui.idSelecionado = -1;
    mostrarMensagem(ui, "Dados de demonstração carregados (12 pedidos).", 1);
}

static std::string campoCSV(const std::string &valor)
{
    if (valor.find_first_of(";\"\r\n") == std::string::npos)
        return valor;
    std::string saida = "\"";
    for (char c : valor)
    {
        if (c == '"')
            saida += '"';
        saida += c;
    }
    saida += '"';
    return saida;
}

static std::string numeroCSV(float valor)
{
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%.2f", valor);
    for (char &c : buf)
        if (c == '.')
            c = ',';
    return buf;
}

static void acaoExportarCSV(EstadoUI &ui)
{
    const char *caminho = "assistencia_pedidos.csv";
    std::ofstream f(caminho, std::ios::binary);
    if (!f)
    {
        mostrarMensagem(ui, "Não foi possível criar assistencia_pedidos.csv.", 2);
        return;
    }

    // BOM para o Excel reconhecer os acentos; separador ';' (Portugal).
    f << "\xEF\xBB\xBF";
    f << "ID;Cliente;Contacto;Equipamento;Avaria;Diagnostico;Prioridade;Estado;"
         "Abertura;Fecho;Vendedor;Tecnico;Intervencoes;Custo\n";
    for (int i = 0; i < ui.gestor.quantidade(); i++)
    {
        const Pedido *p = ui.gestor.pedidoNaPosicao(i);
        if (p == nullptr)
            continue;
        f << p->id << ';'
          << campoCSV(p->cliente) << ';'
          << campoCSV(p->contacto) << ';'
          << campoCSV(p->equipamento) << ';'
          << campoCSV(p->avaria) << ';'
          << campoCSV(p->diagnostico) << ';'
          << campoCSV(nomePrioridade(p->prioridade)) << ';'
          << campoCSV(nomeEstado(p->estado)) << ';'
          << campoCSV(formatarData(p->dataAbertura)) << ';'
          << campoCSV(formatarData(p->dataFecho)) << ';'
          << campoCSV(p->vendedor) << ';'
          << campoCSV(p->tecnico) << ';'
          << p->nIntervencoes << ';'
          << numeroCSV(ui.gestor.custoPedido(*p)) << '\n';
    }
    f.flush();
    if (!f)
    {
        mostrarMensagem(ui, "Erro ao escrever assistencia_pedidos.csv.", 2);
        return;
    }
    mostrarMensagem(ui, "Ficheiro exportado: assistencia_pedidos.csv", 1);
}

static void acaoDuplicarPedido(EstadoUI &ui)
{
    Pedido *origem = ui.gestor.procurarPorId(ui.idSelecionado);
    if (origem == nullptr)
    {
        mostrarMensagem(ui, "Selecione primeiro um pedido para duplicar.", 3);
        return;
    }

    // Copiar os dados ANTES de adicionar: o array pode crescer e mudar de
    // endereço, pelo que o apontador "origem" deixa de ser válido.
    const int idOrigem = origem->id;
    const std::string cliente = origem->cliente;
    const std::string contacto = origem->contacto;
    const std::string equipamento = origem->equipamento;
    const std::string avaria = origem->avaria;
    const std::string diagnostico = origem->diagnostico;
    const std::string vendedor = origem->vendedor;
    const std::string tecnico = origem->tecnico;
    const Prioridade prioridade = origem->prioridade;
    std::vector<Intervencao> copiadas;
    if (origem->intervencoes != nullptr && origem->nIntervencoes > 0)
        copiadas.assign(origem->intervencoes, origem->intervencoes + origem->nIntervencoes);

    int novoId = ui.gestor.adicionarPedido(cliente, equipamento, avaria, prioridade,
                                           contacto, vendedor, tecnico);
    if (novoId <= 0)
    {
        mostrarMensagem(ui, "Não foi possível duplicar o pedido.", 2);
        return;
    }
    Pedido *novo = ui.gestor.procurarPorId(novoId);
    if (novo != nullptr)
    {
        novo->diagnostico = diagnostico;
        for (const Intervencao &it : copiadas)
            ui.gestor.adicionarIntervencao(novo, it.descricao, it.peca, it.custoPeca, it.horas);
    }
    ui.idSelecionado = novoId;
    mostrarMensagem(ui, "Pedido #" + std::to_string(novoId) + " criado a partir do #" +
                            std::to_string(idOrigem) + ".", 1);
}

static std::string resumoPedido(const GestorPedidos &gestor, const Pedido &p)
{
    std::string r;
    r += "PEDIDO #" + std::to_string(p.id) + " - " + p.cliente + "\n";
    r += "Equipamento: " + p.equipamento + "\n";
    if (!p.contacto.empty())
        r += "Contacto: " + p.contacto + "\n";
    r += "Avaria: " + p.avaria + "\n";
    r += "Estado: " + std::string(nomeEstado(p.estado)) + " | Prioridade: " +
         nomePrioridade(p.prioridade) + "\n";
    if (!p.diagnostico.empty())
        r += "Diagnostico: " + p.diagnostico + "\n";
    if (p.nIntervencoes > 0)
    {
        r += "Intervencoes (" + std::to_string(p.nIntervencoes) + "):\n";
        for (int i = 0; i < p.nIntervencoes; i++)
        {
            const Intervencao &it = p.intervencoes[i];
            r += " - " + it.descricao;
            if (!it.peca.empty())
                r += " [" + it.peca + "]";
            r += " | " + euros(it.custoPeca) + " | " + std::to_string(it.horas) + " h\n";
        }
    }
    r += "Custo total: " + euros(gestor.custoPedido(p)) + "\n";
    return r;
}

static void acaoCopiarResumo(EstadoUI &ui)
{
    Pedido *p = ui.gestor.procurarPorId(ui.idSelecionado);
    if (p == nullptr)
    {
        mostrarMensagem(ui, "Selecione primeiro um pedido.", 3);
        return;
    }
    ImGui::SetClipboardText(resumoPedido(ui.gestor, *p).c_str());
    mostrarMensagem(ui, "Resumo do pedido #" + std::to_string(p->id) + " copiado.", 1);
}

// ====================================================================
//  Lista de pedidos (painel da esquerda)
// ====================================================================

static GestorPedidos::Comparador comparadorEscolhido(int criterio)
{
    switch (criterio)
    {
    case 1:
        return compararPorPrioridade;
    case 2:
        return compararPorData;
    case 3:
        return compararPorCliente;
    case 4:
        return compararPorVendedor;
    default:
        return compararPorId;
    }
}

static void desenharLista(EstadoUI &ui)
{
    float fs = ImGui::GetFontSize();

    // Cabeçalho do painel: título, contagem e botão principal.
    pushFonteTitulo(1.22f);
    ImGui::TextUnformatted("Pedidos");
    ImGui::PopFont();
    ImGui::SameLine(0, fs * 0.5f);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + fs * 0.10f);
    char contagem[32];
    std::snprintf(contagem, sizeof(contagem), "%d", ui.gestor.quantidade());
    pilula(contagem, COR_CIANO);

    const char *rotuloNovo = "+ Novo pedido";
    ImGui::SameLine(ImGui::GetWindowWidth() - ImGui::GetStyle().WindowPadding.x - larguraBotao(rotuloNovo, true));
    pushCorBotao(COR_AZUL);
    if (botaoComIcone(ui.texturas, Icone::NovoPedido, rotuloNovo))
        ui.abrirNovoPedido = true;
    popCorBotao();

    // Pesquisa com a lupa dentro da caixa.
    float larguraIcone = TAM_ICONE + 8.0f;
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,
                        ImVec2(ImGui::GetStyle().FramePadding.x + larguraIcone, ImGui::GetStyle().FramePadding.y));
    ImGui::SetNextItemWidth(-1);
    if (ui.focarPesquisa)
    {
        ImGui::SetKeyboardFocusHere();
        ui.focarPesquisa = false;
    }
    ImGui::InputTextWithHint("##pesquisa", "Pesquisar por cliente, equipamento, vendedor ou nº...", &ui.filtroTexto);
    ImGui::PopStyleVar();
    if (texturaValida(icone(ui.texturas, Icone::Pesquisa)))
    {
        ImVec2 a = ImGui::GetItemRectMin();
        float h = ImGui::GetItemRectSize().y;
        float y = a.y + (h - TAM_ICONE) * 0.5f;
        ImGui::GetWindowDrawList()->AddImage(icone(ui.texturas, Icone::Pesquisa),
                                             ImVec2(a.x + 8.0f, y), ImVec2(a.x + 8.0f + TAM_ICONE, y + TAM_ICONE));
    }
    // Contorno ciano quando a pesquisa está focada (feedback visual imediato).
    if (ImGui::IsItemActive() || ImGui::IsItemFocused())
    {
        ImVec2 a = ImGui::GetItemRectMin(), b = ImGui::GetItemRectMax();
        float pulso = 0.45f + 0.20f * std::sin(static_cast<float>(ImGui::GetTime()) * 4.0f);
        ImGui::GetWindowDrawList()->AddRect(a - ImVec2(1, 1), b + ImVec2(1, 1),
                                            corComAlfa(COR_CIANO, pulso), ImGui::GetStyle().FrameRounding + 1.0f,
                                            0, 1.4f);
    }

    // Filtro de estado e critério de ordenação.
    float metade = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x) * 0.5f;
    ImGui::SetNextItemWidth(metade);
    if (ImGui::BeginCombo("##filtroEstado", ui.filtroEstado == 0 ? "Todos os estados" : nomeEstado(static_cast<Estado>(ui.filtroEstado - 1))))
    {
        if (ImGui::Selectable("Todos os estados", ui.filtroEstado == 0))
            ui.filtroEstado = 0;
        for (int i = 0; i < NUM_ESTADOS; i++)
        {
            if (ImGui::Selectable(nomeEstado(static_cast<Estado>(i)), ui.filtroEstado == i + 1))
                ui.filtroEstado = i + 1;
        }
        ImGui::EndCombo();
    }
    ImGui::SameLine();
    ImGui::SetNextItemWidth(-1);
    if (ImGui::BeginCombo("##ordem", NOMES_ORDEM[ui.criterioOrdem]))
    {
        for (int i = 0; i < N_ORDEMS; i++)
        {
            if (ImGui::Selectable(NOMES_ORDEM[i], i == ui.criterioOrdem))
            {
                ui.criterioOrdem = i;
                ui.gestor.ordenar(comparadorEscolhido(i)); // apontador para função
            }
        }
        ImGui::EndCombo();
    }

    std::vector<int> indices = ui.gestor.pesquisar(ui.filtroTexto, ui.filtroEstado - 1);

    ImGui::Spacing();
    ImGuiTableFlags flags = ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_Resizable |
                            ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_PadOuterX;
    if (ImGui::BeginTable("tabelaPedidos", 7, flags, ImVec2(0, 0)))
    {
        ImGui::TableSetupScrollFreeze(0, 1);
        // Larguras proporcionais: assim a tabela adapta-se à largura da janela
        // e dá mais espaço ao cliente e ao equipamento, que são os campos maiores.
        ImGui::TableSetupColumn("Nº", ImGuiTableColumnFlags_WidthStretch, 0.30f);
        ImGui::TableSetupColumn("Cliente", ImGuiTableColumnFlags_WidthStretch, 1.02f);
        ImGui::TableSetupColumn("Equipamento", ImGuiTableColumnFlags_WidthStretch, 1.48f);
        ImGui::TableSetupColumn("Vendedor", ImGuiTableColumnFlags_WidthStretch, 0.82f);
        ImGui::TableSetupColumn("Dias", ImGuiTableColumnFlags_WidthStretch, 0.36f);
        ImGui::TableSetupColumn("Prior.", ImGuiTableColumnFlags_WidthStretch, 0.62f);
        ImGui::TableSetupColumn("Estado", ImGuiTableColumnFlags_WidthStretch, 1.02f);
        ImGui::TableHeadersRow();

        for (int idx : indices)
        {
            const Pedido *p = ui.gestor.pedidoNaPosicao(idx);
            if (p == nullptr)
                continue; // nunca desreferenciar sem verificar
            ImGui::TableNextRow();
            if (p->prioridade == Prioridade::Urgente &&
                p->estado != Estado::Concluido && p->estado != Estado::Entregue)
                ImGui::TableSetBgColor(ImGuiTableBgTarget_RowBg0, corComAlfa(COR_VERMELHO, 0.055f));
            ImGui::TableNextColumn();
            char rotulo[32];
            std::snprintf(rotulo, sizeof(rotulo), "%d##linha%d", p->id, p->id);
            bool selecionado = (p->id == ui.idSelecionado);
            if (ImGui::Selectable(rotulo, selecionado, ImGuiSelectableFlags_SpanAllColumns))
            {
                ui.idSelecionado = p->id;
                ui.erroIntervencao.clear();
            }
            ImGui::TableNextColumn();
            ImGui::TextWrapped("%s", p->cliente.c_str());
            if (!p->contacto.empty() && ImGui::IsItemHovered())
                ImGui::SetTooltip("Contacto: %s", p->contacto.c_str());
            ImGui::TableNextColumn();
            ImGui::TextDisabled("%s", p->equipamento.c_str());
            ImGui::TableNextColumn();
            if (!p->vendedor.empty())
                ImGui::TextWrapped("%s", p->vendedor.c_str());
            else
                ImGui::TextDisabled("-");
            ImGui::TableNextColumn();
            {
                std::time_t fim = (p->dataFecho != 0) ? p->dataFecho : std::time(nullptr);
                int dias = diasEntre(p->dataAbertura, fim);
                bool fechado = (p->estado == Estado::Concluido || p->estado == Estado::Entregue);
                if (!fechado && dias > 14)
                    ImGui::TextColored(COR_AMBAR, "%d", dias);
                else
                    ImGui::TextDisabled("%d", dias);
                if (ImGui::IsItemHovered())
                    ImGui::SetTooltip(fechado ? "Resolvido em %d dia(s)." : "Em aberto há %d dia(s).", dias);
            }
            ImGui::TableNextColumn();
            pilulaPrioridade(p->prioridade);
            ImGui::TableNextColumn();
            pilulaEstado(p->estado);
        }
        if (indices.empty())
        {
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextDisabled("-");
            ImGui::TableNextColumn();
            ImGui::TextDisabled("Nenhum pedido encontrado.");
        }
        ImGui::EndTable();
    }
}

// ====================================================================
//  Detalhe do pedido
// ====================================================================

static void desenharDetalhe(EstadoUI &ui)
{
    Pedido *p = ui.gestor.procurarPorId(ui.idSelecionado);
    if (p == nullptr)
    {
        ImGui::Spacing();
        ImGui::Spacing();
        imagemCentrada(ui.texturas.semPedido, 440.0f, 620.0f / 1000.0f);
        ImGui::Spacing();
        ImGui::Spacing();
        textoCentrado("Nenhum pedido selecionado", ImGui::GetStyleColorVec4(ImGuiCol_Text), 1.25f, true);
        ImGui::Spacing();
        textoCentrado("Escolha um pedido na lista à esquerda para ver os detalhes.", ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), 0.92f);
        ImGui::Spacing();
        ImGui::Spacing();

        const char *rotuloNovo = "Criar novo pedido";
        float larguraNovo = larguraBotao(rotuloNovo, texturaValida(icone(ui.texturas, Icone::NovoPedido)));
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + (ImGui::GetContentRegionAvail().x - larguraNovo) * 0.5f);
        pushCorBotao(COR_AZUL);
        if (botaoComIcone(ui.texturas, Icone::NovoPedido, rotuloNovo))
            ui.abrirNovoPedido = true;
        popCorBotao();
        return;
    }

    float fs = ImGui::GetFontSize();
    ImVec2 posCartao = ImGui::GetCursorScreenPos();
    float larguraCartao = ImGui::GetContentRegionAvail().x;
    float alturaCartao = fs * 8.4f;
    ImGui::Dummy(ImVec2(larguraCartao, alturaCartao));

    // Cartão de identificação do pedido.
    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 canto = posCartao + ImVec2(larguraCartao, alturaCartao);
    fundoCartao(posCartao, ImVec2(larguraCartao, alturaCartao), ImGui::GetStyleColorVec4(ImGuiCol_Border), 12.0f);
    dl->AddRectFilled(posCartao + ImVec2(0, 12), posCartao + ImVec2(4, alturaCartao - 12),
                      ImGui::GetColorU32(corEstado(p->estado)), 2.0f);

    float margem = fs * 0.95f;
    float x = posCartao.x + margem;
    float y = posCartao.y + margem * 0.75f;

    char tituloPedido[64];
    std::snprintf(tituloPedido, sizeof(tituloPedido), "PEDIDO #%d", p->id);
    float tamPequeno = fs * 0.74f;
    textoDesenhado(dl, ImVec2(x, y), tamPequeno, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), tituloPedido, fonteDosTitulos());
    ImVec2 medidaPequeno = medidaTexto(tituloPedido, tamPequeno);

    float yCliente = y + medidaPequeno.y + fs * 0.5f;
    float tamCliente = fs * 1.32f;
    textoDesenhado(dl, ImVec2(x, yCliente), tamCliente, ImGui::GetStyleColorVec4(ImGuiCol_Text), p->cliente.c_str(), fonteDosTitulos());

    float yEquip = yCliente + tamCliente * 1.15f + fs * 0.2f;
    char linhaEquip[512];
    std::snprintf(linhaEquip, sizeof(linhaEquip), "%s%s%s", p->equipamento.c_str(),
                  p->contacto.empty() ? "" : "   •   ", p->contacto.c_str());
    textoDesenhado(dl, ImVec2(x, yEquip), fs * 0.90f,
                   ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), linhaEquip);

    // Pílulas de prioridade e estado, alinhadas à direita.
    auto desenharPilula = [&](const char *texto, const ImVec4 &cor, float xDireita) -> float
    {
        float tam = fs * 0.78f;
        ImVec2 medida = medidaTexto(texto, tam);
        ImVec2 tamanho(medida.x + 20.0f, medida.y + 8.0f);
        ImVec2 a(xDireita - tamanho.x, posCartao.y + margem * 0.7f);
        dl->AddRectFilled(a, a + tamanho, corComAlfa(cor, 0.16f), tamanho.y * 0.5f);
        dl->AddRect(a, a + tamanho, corComAlfa(cor, 0.45f), tamanho.y * 0.5f);
        textoDesenhado(dl, ImVec2(a.x + 10.0f, a.y + 4.0f - 1.0f), tam, cor, texto);
        return a.x;
    };
    float xPilula = posCartao.x + larguraCartao - margem;
    xPilula = desenharPilula(nomeEstado(p->estado), corEstado(p->estado), xPilula) - fs * 0.4f;
    desenharPilula(nomePrioridade(p->prioridade), corPrioridade(p->prioridade), xPilula);

    // Data de abertura / dias em aberto, acima do ciclo do pedido.
    std::time_t fim = (p->dataFecho != 0) ? p->dataFecho : std::time(nullptr);
    char linhaData[160];
    std::snprintf(linhaData, sizeof(linhaData), "Aberto em %s  •  %d dia(s) %s",
                  formatarData(p->dataAbertura).c_str(), diasEntre(p->dataAbertura, fim),
                  p->dataFecho != 0 ? "até ao fecho" : "em aberto");
    float tamData = fs * 0.76f;
    ImVec2 medidaData = medidaTexto(linhaData, tamData);
    textoDesenhado(dl, ImVec2(canto.x - margem - medidaData.x, canto.y - fs * 2.90f - medidaData.y),
                   tamData, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), linhaData);

    // "Ciclo do pedido": linha de estados com o estado atual em destaque.
    {
        float yLinha = canto.y - fs * 1.95f;
        float xInicio = x;
        float xFim = canto.x - margem;
        int atual = static_cast<int>(p->estado);

        float tamEtiqueta = fs * 0.66f;
        textoDesenhado(dl, ImVec2(xInicio, yLinha - fs * 1.02f), tamEtiqueta,
                       ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), "CICLO DO PEDIDO", fonteDosTitulos());

        // Linha de fundo e troços já percorridos.
        dl->AddLine(ImVec2(xInicio, yLinha), ImVec2(xFim, yLinha),
                    corComAlfa(ImGui::GetStyleColorVec4(ImGuiCol_Border), 1.0f), 2.0f);
        float passo = (xFim - xInicio) / static_cast<float>(NUM_ESTADOS - 1);
        if (atual > 0)
            dl->AddLine(ImVec2(xInicio, yLinha), ImVec2(xInicio + passo * atual, yLinha),
                        corComAlfa(COR_CIANO, 0.55f), 2.0f);

        for (int i = 0; i < NUM_ESTADOS; i++)
        {
            float px = xInicio + passo * i;
            bool passado = (i < atual);
            bool corrente = (i == atual);
            ImVec4 cor = corEstado(static_cast<Estado>(i));
            ImU32 corPonto = corrente ? ImGui::GetColorU32(cor)
                             : passado ? corComAlfa(cor, 0.75f)
                                       : corComAlfa(ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), 0.45f);
            float raio = corrente ? fs * 0.26f : fs * 0.17f;
            dl->AddCircleFilled(ImVec2(px, yLinha), raio + 2.5f,
                                ImGui::GetColorU32(ImGuiCol_ChildBg), 24);
            dl->AddCircleFilled(ImVec2(px, yLinha), raio, corPonto, 20);
            if (corrente)
            {
                float pulso = 0.35f + 0.25f * std::sin(static_cast<float>(ImGui::GetTime()) * 3.4f);
                dl->AddCircle(ImVec2(px, yLinha), raio + 4.0f, corComAlfa(cor, pulso), 24, 1.4f);
            }

            const char *nome = nomeEstado(static_cast<Estado>(i));
            ImVec2 medida = medidaTexto(nome, tamEtiqueta, corrente ? fonteDosTitulos() : nullptr);
            float tx = std::clamp(px - medida.x * 0.5f, posCartao.x + 6.0f, canto.x - 6.0f - medida.x);
            ImVec4 corTexto = corrente ? cor
                              : passado ? ImGui::GetStyleColorVec4(ImGuiCol_Text)
                                        : ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled);
            textoDesenhado(dl, ImVec2(tx, yLinha + fs * 0.46f), tamEtiqueta, corTexto, nome,
                           corrente ? fonteDosTitulos() : nullptr);
        }
    }

    inicioSeccao("Dados do pedido");
    if (ImGui::BeginTable("dadosPedido", 3, ImGuiTableFlags_SizingStretchProp))
    {
        ImGui::TableSetupColumn("contacto", ImGuiTableColumnFlags_WidthStretch, 1.0f);
        ImGui::TableSetupColumn("vendedor", ImGuiTableColumnFlags_WidthStretch, 1.0f);
        ImGui::TableSetupColumn("tecnico", ImGuiTableColumnFlags_WidthStretch, 1.25f);

        auto campo = [](const char *rotulo, const char *id, const char *dica, std::string *valor)
        {
            ImGui::TextDisabled("%s", rotulo);
            ImGui::SetNextItemWidth(-1);
            ImGui::InputTextWithHint(id, dica, valor);
        };

        ImGui::TableNextRow();
        ImGui::TableSetColumnIndex(0);
        campo("Contacto", "##contacto", "Telefone ou email", &p->contacto);
        ImGui::TableSetColumnIndex(1);
        campo("Vendedor", "##vendedor", "Nome do vendedor", &p->vendedor);
        ImGui::TableSetColumnIndex(2);
        campo("Técnico", "##tecnico", "Técnico responsável", &p->tecnico);

        ImGui::TableNextRow();
        ImGui::TableSetColumnIndex(0);
        ImGui::TextDisabled("Estado");
        int est = static_cast<int>(p->estado);
        ImGui::SetNextItemWidth(-1);
        if (comboNomes("##estado", est, NUM_ESTADOS, nomeEstadoInt))
        {
            ui.gestor.mudarEstado(p, static_cast<Estado>(est));
            mostrarMensagem(ui, "Estado atualizado.", 1);
        }
        ImGui::TableSetColumnIndex(1);
        ImGui::TextDisabled("Prioridade");
        int prio = static_cast<int>(p->prioridade);
        ImGui::SetNextItemWidth(-1);
        if (comboNomes("##prioridade", prio, NUM_PRIORIDADES, nomePrioridadeInt))
            p->prioridade = static_cast<Prioridade>(prio);
        ImGui::TableSetColumnIndex(2);
        ImGui::TextDisabled("Avaria reportada");
        ImGui::TextWrapped("%s", p->avaria.c_str());
        ImGui::EndTable();
    }

    inicioSeccao("Diagnóstico do técnico");
    ImGui::InputTextMultiline("##diag", &p->diagnostico, ImVec2(-1, ImGui::GetTextLineHeight() * 4.5f),
                              ImGuiInputTextFlags_WordWrap);

    char tituloInterv[64];
    std::snprintf(tituloInterv, sizeof(tituloInterv), "Intervenções (%d)", p->nIntervencoes);
    inicioSeccao(tituloInterv);

    int paraRemover = -1;
    if (p->nIntervencoes == 0)
    {
        ImGui::TextDisabled("Ainda não há intervenções registadas.");
    }
    else if (ImGui::BeginTable("tabInterv", 5, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_PadOuterX))
    {
        ImGui::TableSetupColumn("Descrição", ImGuiTableColumnFlags_WidthStretch, 2.0f);
        ImGui::TableSetupColumn("Peça", ImGuiTableColumnFlags_WidthStretch, 1.3f);
        ImGui::TableSetupColumn("Custo peça", ImGuiTableColumnFlags_WidthFixed, fs * 5.6f);
        ImGui::TableSetupColumn("Horas", ImGuiTableColumnFlags_WidthFixed, fs * 3.0f);
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, fs * 1.6f);
        ImGui::TableHeadersRow();
        for (int i = 0; i < p->nIntervencoes; i++)
        {
            const Intervencao &it = p->intervencoes[i];
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextWrapped("%s", it.descricao.c_str());
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(it.peca.empty() ? "-" : it.peca.c_str());
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(euros(it.custoPeca).c_str());
            ImGui::TableNextColumn();
            ImGui::Text("%.2f", it.horas);
            ImGui::TableNextColumn();
            ImGui::PushID(i);
            ImGui::PushStyleColor(ImGuiCol_Text, COR_VERMELHO);
            if (ImGui::SmallButton("remover"))
                paraRemover = i;
            ImGui::PopStyleColor();
            ImGui::PopID();
        }
        ImGui::EndTable();
    }
    if (paraRemover >= 0)
        ui.gestor.removerIntervencao(p, paraRemover);

    // Formulário de nova intervenção.
    ImGui::Spacing();
    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * 0.50f);
    ImGui::InputTextWithHint("##idesc", "Descrição da intervenção", &ui.intDescricao);
    ImGui::SameLine();
    ImGui::SetNextItemWidth(-1);
    ImGui::InputTextWithHint("##ipeca", "Peça (opcional)", &ui.intPeca);
    ImGui::SetNextItemWidth(fs * 6.5f);
    ImGui::InputFloat("Custo peça", &ui.intCusto, 0.0f, 0.0f, "%.2f");
    ImGui::SameLine();
    ImGui::SetNextItemWidth(fs * 5.0f);
    ImGui::InputFloat("Horas", &ui.intHoras, 0.0f, 0.0f, "%.2f");
    ImGui::SameLine();
    pushCorBotao(COR_AZUL);
    if (botaoComIcone(ui.texturas, Icone::Adicionar, "Adicionar intervenção"))
    {
        if (!ui.gestor.adicionarIntervencao(p, ui.intDescricao, ui.intPeca, ui.intCusto, ui.intHoras))
        {
            ui.erroIntervencao = "Dados inválidos: indique a descrição; custo >= 0 e horas entre 0 e 1000.";
        }
        else
        {
            ui.erroIntervencao.clear();
            ui.intDescricao.clear();
            ui.intPeca.clear();
            ui.intCusto = 0;
            ui.intHoras = 0;
            mostrarMensagem(ui, "Intervenção adicionada.", 1);
        }
    }
    popCorBotao();
    if (!ui.erroIntervencao.empty())
        ImGui::TextColored(COR_VERMELHO, "%s", ui.erroIntervencao.c_str());

    // Resumo de custos em cartão.
    inicioSeccao("Custos");
    float alturaCustos = fs * 5.0f;
    ImVec2 posCustos = ImGui::GetCursorScreenPos();
    float larguraCustos = ImGui::GetContentRegionAvail().x;
    ImGui::Dummy(ImVec2(larguraCustos, alturaCustos));
    fundoCartao(posCustos, ImVec2(larguraCustos, alturaCustos), ImGui::GetStyleColorVec4(ImGuiCol_Border), 10.0f);

    float m = fs * 0.9f;
    float tamRotulo = fs * 0.76f;
    textoDesenhado(dl, posCustos + ImVec2(m, m * 0.8f), tamRotulo,
                   ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), "CUSTO TOTAL");
    float tamTotal = fs * 1.65f;
    textoDesenhado(dl, posCustos + ImVec2(m, m * 0.8f + tamRotulo * 1.2f), tamTotal, COR_VERDE,
                   euros(ui.gestor.custoPedido(*p)).c_str(), fonteDosTitulos());

    char maoObra[160];
    std::snprintf(maoObra, sizeof(maoObra), "%.2f h × %s", ui.gestor.horasTotais(*p), euros(ui.gestor.taxaHoraria).c_str());
    float xDetalhes = posCustos.x + larguraCustos * 0.55f;
    textoDesenhado(dl, ImVec2(xDetalhes, posCustos.y + m * 0.8f), tamRotulo,
                   ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), "PEÇAS");
    textoDesenhado(dl, ImVec2(xDetalhes, posCustos.y + m * 0.8f + fs * 0.95f), fs * 0.92f,
                   ImGui::GetStyleColorVec4(ImGuiCol_Text), euros(ui.gestor.custoPecas(*p)).c_str());
    textoDesenhado(dl, ImVec2(xDetalhes, posCustos.y + m * 0.8f + fs * 2.15f), tamRotulo,
                   ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), "MÃO DE OBRA");
    textoDesenhado(dl, ImVec2(xDetalhes, posCustos.y + m * 0.8f + fs * 3.10f), fs * 0.86f,
                   ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), maoObra);

    ImGui::Spacing();
    pushCorBotao(COR_AZUL);
    if (botaoComIcone(ui.texturas, Icone::Adicionar, "Duplicar pedido"))
        acaoDuplicarPedido(ui);
    popCorBotao();
    ImGui::SameLine();
    if (botaoComIcone(ui.texturas, Icone::Copiar, "Copiar resumo"))
        acaoCopiarResumo(ui);
    ImGui::SameLine(ImGui::GetWindowWidth() - ImGui::GetStyle().WindowPadding.x -
                    larguraBotao("Remover pedido", true));
    pushCorBotao(ImVec4(0.545f, 0.157f, 0.208f, 1.0f));
    if (botaoComIcone(ui.texturas, Icone::Remover, "Remover pedido"))
        ImGui::OpenPopup("Confirmar remoção");
    popCorBotao();
    if (ImGui::BeginPopupModal("Confirmar remoção", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
    {
        ImGui::Text("Remover o pedido #%d de %s?\nEsta ação não pode ser desfeita.", p->id, p->cliente.c_str());
        ImGui::Spacing();
        pushCorBotao(ImVec4(0.545f, 0.157f, 0.208f, 1.0f));
        if (ImGui::Button("Sim, remover"))
        {
            int id = p->id;
            ui.gestor.removerPedido(id); // a partir daqui "p" já não é válido
            p = nullptr;
            ui.idSelecionado = -1;
            mostrarMensagem(ui, "Pedido removido.", 1);
            ImGui::CloseCurrentPopup();
        }
        popCorBotao();
        ImGui::SameLine();
        if (ImGui::Button("Cancelar"))
            ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

// ====================================================================
//  Estatísticas
// ====================================================================

static std::string eurosCompacto(float v)
{
    char buf[48];
    const char *moeda = fonteSuportaEuro ? "€" : "EUR";
    if (v >= 1000000.0f)
        std::snprintf(buf, sizeof(buf), "%.1f M%s", v / 1000000.0f, moeda);
    else if (v >= 10000.0f)
        std::snprintf(buf, sizeof(buf), "%.0f k%s", v / 1000.0f, moeda);
    else
        std::snprintf(buf, sizeof(buf), "%.0f %s", v, moeda);
    return buf;
}

// Barra horizontal desenhada à mão (rótulo, valor à direita e preenchimento).
static void barraCompacta(const char *nome, const char *valor, float fracao, const ImVec4 &cor)
{
    float fs = ImGui::GetFontSize();
    ImGui::PushID(nome);

    ImGui::TextUnformatted(nome);
    float larguraValor = ImGui::CalcTextSize(valor).x;
    float xDireita = ImGui::GetWindowWidth() - ImGui::GetStyle().WindowPadding.x - larguraValor;
    if (xDireita > ImGui::GetCursorPosX() + fs)
        ImGui::SameLine(xDireita);
    else
        ImGui::SameLine();
    ImGui::TextDisabled("%s", valor);

    float largura = ImGui::GetContentRegionAvail().x;
    float altura = fs * 0.58f;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##barra", ImVec2(largura, altura));
    ImDrawList *dl = ImGui::GetWindowDrawList();

    dl->AddRectFilled(pos, pos + ImVec2(largura, altura), ImGui::GetColorU32(ImGuiCol_FrameBg), altura * 0.5f);
    float preenchido = std::clamp(fracao, 0.0f, 1.0f) * largura;
    if (preenchido > 1.0f)
    {
        dl->AddRectFilled(pos, pos + ImVec2(preenchido, altura), corComAlfa(cor, 0.80f), altura * 0.5f);
        dl->AddRectFilled(pos, pos + ImVec2(std::min(preenchido, altura), altura),
                          corComAlfa(cor, 1.0f), altura * 0.5f);
        dl->AddCircleFilled(ImVec2(pos.x + preenchido - altura * 0.5f, pos.y + altura * 0.5f),
                            altura * 0.60f, corComAlfa(cor, 0.16f), 16);
    }
    dl->AddRect(pos, pos + ImVec2(largura, altura), corComAlfa(cor, 0.16f), altura * 0.5f);

    ImGui::PopID();
}

// Barra única com a composição das prioridades (largura proporcional).
static void barraComposicaoPrioridade(const Estatisticas &e)
{
    if (e.total <= 0)
        return;
    float fs = ImGui::GetFontSize();
    float largura = ImGui::GetContentRegionAvail().x;
    float altura = fs * 0.82f;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##composicaoPrioridade", ImVec2(largura, altura));
    ImDrawList *dl = ImGui::GetWindowDrawList();

    dl->AddRectFilled(pos, pos + ImVec2(largura, altura), ImGui::GetColorU32(ImGuiCol_FrameBg), altura * 0.5f);
    float x = pos.x + 2.0f;
    float disponivel = largura - 4.0f;
    for (int i = 0; i < NUM_PRIORIDADES; i++)
    {
        float fracao = static_cast<float>(e.porPrioridade[i]) / static_cast<float>(e.total);
        float w = disponivel * fracao;
        if (w < 1.0f)
            continue;
        dl->AddRectFilled(ImVec2(x, pos.y + 2.0f), ImVec2(x + w, pos.y + altura - 2.0f),
                          corComAlfa(corPrioridade(static_cast<Prioridade>(i)), 0.88f));
        x += w;
    }
    dl->AddRect(pos, pos + ImVec2(largura, altura), corComAlfa(COR_CIANO, 0.20f), altura * 0.5f);
}

static void desenharDonutEstados(const Estatisticas &e, float diametro)
{
    float fs = ImGui::GetFontSize();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##donutEstados", ImVec2(diametro, diametro));
    bool sobre = ImGui::IsItemHovered();

    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 centro = pos + ImVec2(diametro * 0.5f, diametro * 0.5f);
    float raio = diametro * 0.5f - fs * 0.22f;
    float raioInterior = raio * 0.64f;
    ImU32 fundo = ImGui::GetColorU32(ImGuiCol_ChildBg);

    int destacado = -1;
    if (sobre && e.total > 0)
    {
        ImVec2 d = ImGui::GetIO().MousePos - centro;
        float dist = std::sqrt(d.x * d.x + d.y * d.y);
        if (dist >= raioInterior && dist <= raio + 2.0f)
        {
            float angulo = std::atan2(d.y, d.x);
            if (angulo < -PI * 0.5f)
                angulo += 2.0f * PI;
            float acumulado = 0.0f;
            for (int i = 0; i < NUM_ESTADOS; i++)
            {
                float fatia = (e.total > 0) ? static_cast<float>(e.porEstado[i]) / e.total : 0.0f;
                if (angulo >= -PI * 0.5f + acumulado * 2.0f * PI &&
                    angulo < -PI * 0.5f + (acumulado + fatia) * 2.0f * PI)
                {
                    destacado = i;
                    break;
                }
                acumulado += fatia;
            }
        }
    }

    if (e.total <= 0)
    {
        dl->AddCircle(centro, (raio + raioInterior) * 0.5f, ImGui::GetColorU32(ImGuiCol_FrameBg),
                      64, raio - raioInterior);
    }
    else
    {
        float inicio = -PI * 0.5f;
        for (int i = 0; i < NUM_ESTADOS; i++)
        {
            float fatia = static_cast<float>(e.porEstado[i]) / static_cast<float>(e.total);
            float varrimento = fatia * 2.0f * PI;
            if (varrimento <= 0.0001f)
                continue;
            float r = (i == destacado) ? raio + 3.0f : raio;
            float margem = (varrimento > 0.05f) ? 0.012f : 0.0f;
            dl->PathClear();
            dl->PathLineTo(centro);
            dl->PathArcTo(centro, r, inicio + margem, inicio + varrimento - margem, 40);
            dl->PathFillConvex(corComAlfa(corEstado(static_cast<Estado>(i)), i == destacado ? 1.0f : 0.88f));
            inicio += varrimento;
        }
    }

    dl->AddCircleFilled(centro, raioInterior, fundo, 64);
    dl->AddCircle(centro, raioInterior, corComAlfa(ImGui::GetStyleColorVec4(ImGuiCol_Border), 0.9f), 64, 1.0f);
    dl->AddCircle(centro, raio, corComAlfa(COR_CIANO, 0.15f), 64, 1.0f);

    char totalTexto[32];
    std::snprintf(totalTexto, sizeof(totalTexto), "%d", e.total);
    float tamTotal = fs * 1.85f;
    ImVec2 medidaTotal = medidaTexto(totalTexto, tamTotal, fonteDosTitulos());
    textoDesenhado(dl, centro + ImVec2(-medidaTotal.x * 0.5f, -medidaTotal.y * 0.78f), tamTotal,
                   ImGui::GetStyleColorVec4(ImGuiCol_Text), totalTexto, fonteDosTitulos());
    const char *legenda = "pedidos";
    float tamLegenda = fs * 0.68f;
    ImVec2 medidaLegenda = medidaTexto(legenda, tamLegenda);
    textoDesenhado(dl, centro + ImVec2(-medidaLegenda.x * 0.5f, fs * 0.38f), tamLegenda,
                   ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), legenda);

    if (destacado >= 0)
    {
        Estado est = static_cast<Estado>(destacado);
        float pct = e.total > 0 ? 100.0f * e.porEstado[destacado] / e.total : 0.0f;
        ImGui::SetTooltip("%s: %d pedido(s) (%.0f%%)", nomeEstado(est),
                          e.porEstado[destacado], pct);
    }
}

static void legendaEstados(const Estatisticas &e)
{
    float fs = ImGui::GetFontSize();
    ImGuiTableFlags flags = ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_NoSavedSettings |
                            ImGuiTableFlags_PadOuterX;
    if (ImGui::BeginTable("legendaEstados", 3, flags))
    {
        ImGui::TableSetupColumn("cor", ImGuiTableColumnFlags_WidthFixed, fs * 1.15f);
        ImGui::TableSetupColumn("estado", ImGuiTableColumnFlags_WidthStretch, 1.0f);
        ImGui::TableSetupColumn("valor", ImGuiTableColumnFlags_WidthFixed, fs * 5.4f);
        for (int i = 0; i < NUM_ESTADOS; i++)
        {
            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            ImGui::PushID(i);
            ImGui::ColorButton("##cor", corEstado(static_cast<Estado>(i)),
                               ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoDragDrop |
                                   ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_NoBorder,
                               ImVec2(fs * 0.82f, fs * 0.82f));
            ImGui::PopID();
            ImGui::TableSetColumnIndex(1);
            ImGui::TextUnformatted(nomeEstado(static_cast<Estado>(i)));
            ImGui::TableSetColumnIndex(2);
            float pct = e.total > 0 ? 100.0f * e.porEstado[i] / e.total : 0.0f;
            char valor[48];
            std::snprintf(valor, sizeof(valor), "%d  ·  %.0f%%", e.porEstado[i], pct);
            ImGui::TextDisabled("%s", valor);
        }
        ImGui::EndTable();
    }
}

static void desenharGraficoEntradas(const EstadoUI &ui, float altura)
{
    const int DIAS = 14;
    float fs = ImGui::GetFontSize();
    float largura = ImGui::GetContentRegionAvail().x;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##graficoEntradas", ImVec2(largura, altura));
    bool sobre = ImGui::IsItemHovered();

    int valores[DIAS] = {};
    std::time_t agora = std::time(nullptr);
    std::tm tmDia{};
#ifdef _WIN32
    localtime_s(&tmDia, &agora);
#else
    localtime_r(&agora, &tmDia);
#endif
    tmDia.tm_hour = 0;
    tmDia.tm_min = 0;
    tmDia.tm_sec = 0;
    std::time_t hoje = std::mktime(&tmDia);
    std::time_t inicio = hoje - static_cast<std::time_t>(DIAS - 1) * 86400;
    int maximo = 1;
    for (int i = 0; i < ui.gestor.quantidade(); i++)
    {
        const Pedido *p = ui.gestor.pedidoNaPosicao(i);
        if (p == nullptr || p->dataAbertura < inicio)
            continue;
        int indice = static_cast<int>((p->dataAbertura - inicio) / 86400);
        if (indice >= 0 && indice < DIAS)
        {
            valores[indice]++;
            if (valores[indice] > maximo)
                maximo = valores[indice];
        }
    }

    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 canto = pos + ImVec2(largura, altura);
    dl->AddRectFilled(pos, canto, ImGui::GetColorU32(ImGuiCol_FrameBg), 10.0f);
    dl->AddRect(pos, canto, corComAlfa(ImGui::GetStyleColorVec4(ImGuiCol_Border), 0.85f), 10.0f);

    float esq = fs * 0.95f;
    float dir = fs * 0.95f;
    float topo = pos.y + fs * 0.85f;
    float base = canto.y - fs * 1.85f;

    for (int g = 0; g <= 2; g++)
    {
        float y = base - (base - topo) * g / 2.0f;
        dl->AddLine(ImVec2(pos.x + esq, y), ImVec2(canto.x - dir, y),
                    corComAlfa(ImGui::GetStyleColorVec4(ImGuiCol_Border), g == 0 ? 0.85f : 0.42f), 1.0f);
    }

    float passo = (largura - esq - dir) / static_cast<float>(DIAS - 1);
    std::vector<ImVec2> pontos;
    pontos.reserve(DIAS);
    for (int i = 0; i < DIAS; i++)
    {
        float x = pos.x + esq + passo * i;
        float y = base - (base - topo) * (static_cast<float>(valores[i]) / maximo);
        pontos.push_back(ImVec2(x, y));
    }

    std::vector<ImVec2> area = pontos;
    area.push_back(ImVec2(pos.x + esq + passo * (DIAS - 1), base));
    area.push_back(ImVec2(pos.x + esq, base));
    dl->AddConcavePolyFilled(area.data(), static_cast<int>(area.size()), corComAlfa(COR_AZUL, 0.22f));
    dl->AddPolyline(pontos.data(), static_cast<int>(pontos.size()), corComAlfa(COR_CIANO, 0.95f), 0, 2.0f);

    for (int i = 0; i < DIAS; i++)
    {
        dl->AddCircleFilled(pontos[i], fs * 0.13f, corComAlfa(COR_CIANO, 0.95f), 12);
        if (i % 2 == 0)
        {
            std::string dia = formatarData(inicio + static_cast<std::time_t>(i) * 86400).substr(0, 5);
            ImVec2 medida = medidaTexto(dia.c_str(), fs * 0.60f);
            textoDesenhado(dl, ImVec2(pontos[i].x - medida.x * 0.5f, base + fs * 0.30f), fs * 0.60f,
                           ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), dia.c_str());
        }
    }

    char maxTexto[24];
    std::snprintf(maxTexto, sizeof(maxTexto), "máx. %d", maximo);
    textoDesenhado(dl, ImVec2(canto.x - dir - medidaTexto(maxTexto, fs * 0.60f).x, pos.y + fs * 0.18f),
                   fs * 0.60f, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), maxTexto);

    if (sobre)
    {
        float ratoX = ImGui::GetIO().MousePos.x;
        int indice = static_cast<int>(std::lround((ratoX - (pos.x + esq)) / passo));
        indice = std::clamp(indice, 0, DIAS - 1);
        float x = pontos[indice].x;
        dl->AddLine(ImVec2(x, topo), ImVec2(x, base), corComAlfa(COR_CIANO, 0.35f), 1.0f);
        dl->AddCircleFilled(pontos[indice], fs * 0.24f, corComAlfa(COR_CIANO, 0.22f), 16);
        dl->AddCircleFilled(pontos[indice], fs * 0.13f, ImGui::GetColorU32(COR_CIANO), 12);
        std::string dia = formatarData(inicio + static_cast<std::time_t>(indice) * 86400);
        ImGui::SetTooltip("%s: %d pedido(s) abertos", dia.c_str(), valores[indice]);
    }
}

static void desenharBarrasVendedor(EstadoUI &ui, const Estatisticas &e)
{
    struct Linha
    {
        std::string nome;
        int pedidos = 0;
        float receita = 0.0f;
    };
    std::map<std::string, Linha> acumulado;
    for (int i = 0; i < ui.gestor.quantidade(); i++)
    {
        const Pedido *p = ui.gestor.pedidoNaPosicao(i);
        if (p == nullptr)
            continue;
        std::string chave = p->vendedor.empty() ? "(por definir)" : p->vendedor;
        Linha &linha = acumulado[chave];
        linha.nome = chave;
        linha.pedidos++;
        if (p->estado == Estado::Concluido || p->estado == Estado::Entregue)
            linha.receita += ui.gestor.custoPedido(*p);
    }

    std::vector<Linha> linhas;
    linhas.reserve(acumulado.size());
    for (const auto &par : acumulado)
        linhas.push_back(par.second);
    if (linhas.empty())
    {
        ImGui::TextDisabled("Sem pedidos.");
        return;
    }

    bool porReceita = (ui.metricaVendedor == 1);
    std::sort(linhas.begin(), linhas.end(), [porReceita](const Linha &a, const Linha &b)
              {
                  if (porReceita)
                      return a.receita > b.receita;
                  return a.pedidos > b.pedidos;
              });
    float maximo = 1.0f;
    for (const Linha &l : linhas)
        maximo = std::max(maximo, porReceita ? l.receita : static_cast<float>(l.pedidos));

    for (const Linha &l : linhas)
    {
        float valor = porReceita ? l.receita : static_cast<float>(l.pedidos);
        char texto[160];
        if (porReceita)
            std::snprintf(texto, sizeof(texto), "%s  ·  %d pedido(s)", euros(l.receita).c_str(), l.pedidos);
        else
            std::snprintf(texto, sizeof(texto), "%d pedido(s)  ·  %s", l.pedidos, euros(l.receita).c_str());
        barraCompacta(l.nome.c_str(), texto, valor / maximo,
                      porReceita ? COR_VERDE : COR_AZUL);
    }
}

static void desenharEstatisticas(EstadoUI &ui)
{
    Estatisticas e = ui.gestor.calcularEstatisticas();
    float fs = ImGui::GetFontSize();

    // Cartões de indicadores.
    float espaco = ImGui::GetStyle().ItemSpacing.x;
    float larguraCartao = (ImGui::GetContentRegionAvail().x - espaco * 3.0f) / 4.0f;
    char total[32], urgentes[32], tempo[32];
    std::snprintf(total, sizeof(total), "%d", e.total);
    std::snprintf(urgentes, sizeof(urgentes), "%d", e.urgentesPendentes);
    std::snprintf(tempo, sizeof(tempo), "%.1f d", e.tempoMedioDias);
    std::string faturacaoExacta = euros(e.faturacaoTotal);

    char notaUrgentes[40];
    std::snprintf(notaUrgentes, sizeof(notaUrgentes), "%.0f%% do total",
                  e.total > 0 ? 100.0f * e.urgentesPendentes / e.total : 0.0f);
    int concluidos = e.porEstado[static_cast<int>(Estado::Concluido)] +
                     e.porEstado[static_cast<int>(Estado::Entregue)];
    char notaFaturacao[40];
    std::snprintf(notaFaturacao, sizeof(notaFaturacao), "%d concluído(s)", concluidos);

    cartaoKPI(ui.texturas, Icone::Detalhe, total, "PEDIDOS", COR_CIANO, larguraCartao,
              "Número total de pedidos registados.");
    ImGui::SameLine();
    cartaoKPI(ui.texturas, Icone::Prioridade, urgentes, "URGENTES",
              e.urgentesPendentes > 0 ? COR_VERMELHO : COR_VERDE, larguraCartao,
              "Pedidos urgentes que ainda não foram entregues.", notaUrgentes);
    ImGui::SameLine();
    cartaoKPI(ui.texturas, Icone::Euro, eurosCompacto(e.faturacaoTotal).c_str(), "FATURAÇÃO", COR_VERDE,
              larguraCartao, faturacaoExacta.c_str(), notaFaturacao);
    ImGui::SameLine();
    cartaoKPI(ui.texturas, Icone::Data, tempo, "TEMPO MÉDIO", COR_AZUL, larguraCartao,
              "Média de dias entre a abertura e o fecho do pedido.");

    ImGui::Spacing();
    ImGui::TextDisabled("Custo médio por reparação: %s", euros(e.custoMedio).c_str());

    // Distribuição por estado: donut + legenda.
    inicioSeccao("Distribuição por estado");
    if (ImGui::BeginTable("distribuicaoEstado", 2, ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_NoSavedSettings))
    {
        ImGui::TableSetupColumn("grafico", ImGuiTableColumnFlags_WidthFixed, fs * 9.4f);
        ImGui::TableSetupColumn("legenda", ImGuiTableColumnFlags_WidthStretch, 1.0f);
        ImGui::TableNextRow();
        ImGui::TableNextColumn();
        desenharDonutEstados(e, fs * 8.2f);
        ImGui::TableNextColumn();
        legendaEstados(e);
        ImGui::EndTable();
    }

    // Entradas diárias (últimos 14 dias).
    inicioSeccao("Entradas nos últimos 14 dias");
    desenharGraficoEntradas(ui, fs * 7.2f);

    // Prioridade: composição + barras.
    inicioSeccao("Pedidos por prioridade");
    barraComposicaoPrioridade(e);
    ImGui::Spacing();
    for (int i = 0; i < NUM_PRIORIDADES; i++)
    {
        char valor[64];
        float pct = e.total > 0 ? 100.0f * e.porPrioridade[i] / e.total : 0.0f;
        std::snprintf(valor, sizeof(valor), "%d  ·  %.0f%%", e.porPrioridade[i], pct);
        barraCompacta(nomePrioridade(static_cast<Prioridade>(i)), valor,
                      e.total > 0 ? static_cast<float>(e.porPrioridade[i]) / e.total : 0.0f,
                      corPrioridade(static_cast<Prioridade>(i)));
    }

    // Vendedores: alternar entre número de pedidos e faturação.
    inicioSeccao("Desempenho por vendedor");
    ImGui::RadioButton("Pedidos", &ui.metricaVendedor, 0);
    ImGui::SameLine();
    ImGui::RadioButton("Faturação", &ui.metricaVendedor, 1);
    ImGui::Spacing();
    desenharBarrasVendedor(ui, e);

    inicioSeccao("Definições");
    ImGui::TextDisabled("Taxa horária usada no cálculo da mão de obra");
    ImGui::SetNextItemWidth(fs * 7.5f);
    ImGui::InputFloat("##taxa", &ui.gestor.taxaHoraria, 0.0f, 0.0f, "%.2f");
    ImGui::SameLine();
    ImGui::TextDisabled("%s / hora", fonteSuportaEuro ? "€" : "EUR");
    if (ui.gestor.taxaHoraria < 0.0f)
        ui.gestor.taxaHoraria = 0.0f; // validação
    if (ui.gestor.taxaHoraria > 500.0f)
        ui.gestor.taxaHoraria = 500.0f;
}

// ====================================================================
//  Personalização (tema, densidade e preferências visuais)
// ====================================================================

// Cartão clicável que mostra uma pré-visualização de um tema.
static bool cartaoTema(int indice, bool selecionado, float largura)
{
    float fs = ImGui::GetFontSize();
    float altura = fs * 6.2f;
    ImVec2 base = ImGui::GetCursorScreenPos();

    ImGui::PushID(indice);
    ImGui::InvisibleButton("##tema", ImVec2(largura, altura));
    bool sobre = ImGui::IsItemHovered();
    bool clicado = ImGui::IsItemClicked();
    ImGui::PopID();

    PaletaTema pal = paletaDoTema(indice);
    ImVec2 pos(base.x, base.y + ((sobre && !selecionado) ? -2.0f : 0.0f));
    ImVec2 canto = pos + ImVec2(largura, altura);
    ImDrawList *dl = ImGui::GetWindowDrawList();

    // Corpo e sombra.
    dl->AddRectFilled(pos + ImVec2(0, 4), canto + ImVec2(0, 4), IM_COL32(0, 0, 0, sobre ? 85 : 50), 11.0f);
    dl->AddRectFilled(pos, canto, ImGui::GetColorU32(COR_CARTAO), 11.0f);
    if (selecionado)
        dl->AddRectFilled(pos, canto, corComAlfa(pal.azul, 0.10f), 11.0f);

    // Pequena maquete da interface, com as cores do tema.
    float alturaPreview = altura * 0.48f;
    ImVec2 pa(pos.x + 1, pos.y + 1);
    ImVec2 pb(canto.x - 1, pos.y + alturaPreview);
    dl->PushClipRect(pa, pb, true);
    dl->AddRectFilledMultiColor(pa, pb, corComAlfa(pal.azul, 0.42f), corComAlfa(pal.ciano, 0.26f),
                                corComAlfa(pal.azul, 0.16f), corComAlfa(pal.azul, 0.28f));
    float margemMini = fs * 0.55f;
    float espacoMini = fs * 0.25f;
    float miniW = (largura - margemMini * 2.0f - espacoMini * 2.0f) / 3.0f;
    float miniH = alturaPreview - margemMini * 2.0f;
    for (int k = 0; k < 3; k++)
    {
        ImVec2 a(pa.x + margemMini + k * (miniW + espacoMini), pa.y + margemMini);
        ImVec2 b(a.x + miniW, a.y + miniH);
        dl->AddRectFilled(a, b, IM_COL32(7, 11, 22, 165), 4.0f);
        dl->AddRectFilled(a + ImVec2(3, 4), ImVec2(a.x + 4.5f, b.y - 4),
                          corComAlfa(k == 0 ? pal.ciano : pal.azul, 0.90f), 1.0f);
        dl->AddRectFilled(ImVec2(a.x + fs * 0.35f, a.y + fs * 0.38f),
                          ImVec2(b.x - fs * 0.30f, a.y + fs * 0.58f), IM_COL32(255, 255, 255, 80), 1.5f);
        dl->AddRectFilled(ImVec2(a.x + fs * 0.35f, a.y + fs * 0.90f),
                          ImVec2(b.x - fs * 0.60f, a.y + fs * 1.04f), IM_COL32(255, 255, 255, 45), 1.5f);
    }
    dl->PopClipRect();

    dl->AddRect(pos, canto,
                corComAlfa(selecionado ? pal.ciano : ImGui::GetStyleColorVec4(ImGuiCol_Border),
                           selecionado ? 0.95f : 0.55f),
                11.0f, 0, selecionado ? 2.0f : 1.0f);

    // Nome do tema.
    textoDesenhado(dl, ImVec2(pos.x + fs * 0.80f, pos.y + alturaPreview + fs * 0.55f), fs * 0.95f,
                   ImGui::GetStyleColorVec4(ImGuiCol_Text), NOMES_TEMA[indice], fonteDosTitulos());

    // Amostras de cor + estado.
    float yAmostra = canto.y - fs * 1.10f;
    dl->AddCircleFilled(ImVec2(pos.x + fs * 0.95f, yAmostra), fs * 0.20f,
                        ImGui::GetColorU32(pal.azul), 16);
    dl->AddCircleFilled(ImVec2(pos.x + fs * 1.42f, yAmostra), fs * 0.20f,
                        ImGui::GetColorU32(pal.ciano), 16);
    textoDesenhado(dl, ImVec2(pos.x + fs * 1.85f, yAmostra - fs * 0.32f), fs * 0.66f,
                   ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled),
                   selecionado ? "Tema ativo" : "Clique para aplicar");

    // Etiqueta "ATIVO".
    if (selecionado)
    {
        const char *marca = "ATIVO";
        float tamMarca = fs * 0.56f;
        ImVec2 medida = medidaTexto(marca, tamMarca);
        ImVec2 a(canto.x - medida.x - fs * 0.95f, pos.y + fs * 0.55f);
        ImVec2 b(a.x + medida.x + fs * 0.60f, a.y + medida.y + fs * 0.24f);
        dl->AddRectFilled(a, b, IM_COL32(7, 11, 22, 195), (b.y - a.y) * 0.5f);
        dl->AddRect(a, b, corComAlfa(pal.ciano, 0.80f), (b.y - a.y) * 0.5f);
        textoDesenhado(dl, ImVec2(a.x + fs * 0.30f, a.y + fs * 0.10f), tamMarca, pal.ciano, marca);
    }

    if (sobre)
        ImGui::SetTooltip("Aplicar o tema %s", NOMES_TEMA[indice]);
    return clicado;
}

// Cartão clicável para escolher a densidade da interface.
static bool cartaoDensidade(const char *titulo, const char *descricao, bool selecionado, float largura)
{
    float fs = ImGui::GetFontSize();
    float altura = fs * 3.7f;
    ImVec2 base = ImGui::GetCursorScreenPos();

    ImGui::PushID(titulo);
    ImGui::InvisibleButton("##densidade", ImVec2(largura, altura));
    bool sobre = ImGui::IsItemHovered();
    bool clicado = ImGui::IsItemClicked();
    ImGui::PopID();

    ImVec2 pos(base.x, base.y + ((sobre && !selecionado) ? -2.0f : 0.0f));
    ImVec2 canto = pos + ImVec2(largura, altura);
    ImDrawList *dl = ImGui::GetWindowDrawList();

    dl->AddRectFilled(pos + ImVec2(0, 4), canto + ImVec2(0, 4), IM_COL32(0, 0, 0, sobre ? 80 : 46), 11.0f);
    dl->AddRectFilled(pos, canto, ImGui::GetColorU32(COR_CARTAO), 11.0f);
    if (selecionado)
        dl->AddRectFilled(pos, canto, corComAlfa(COR_CIANO, 0.08f), 11.0f);
    dl->AddRect(pos, canto,
                corComAlfa(selecionado ? COR_CIANO : ImGui::GetStyleColorVec4(ImGuiCol_Border),
                           selecionado ? 0.90f : 0.50f),
                11.0f, 0, selecionado ? 2.0f : 1.0f);

    textoDesenhado(dl, ImVec2(pos.x + fs * 0.90f, pos.y + fs * 0.70f), fs * 1.02f,
                   ImGui::GetStyleColorVec4(ImGuiCol_Text), titulo, fonteDosTitulos());
    textoDesenhado(dl, ImVec2(pos.x + fs * 0.90f, pos.y + fs * 1.80f), fs * 0.70f,
                   ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), descricao);

    ImVec2 centro(canto.x - fs * 1.35f, pos.y + altura * 0.5f);
    dl->AddCircle(centro, fs * 0.42f, corComAlfa(selecionado ? COR_CIANO : ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled),
                                                  selecionado ? 1.0f : 0.70f),
                  24, 1.6f);
    if (selecionado)
        dl->AddCircleFilled(centro, fs * 0.21f, ImGui::GetColorU32(COR_CIANO), 20);

    return clicado;
}

static void desenharPersonalizacao(EstadoUI &ui)
{
    float fs = ImGui::GetFontSize();

    // Faixa de apresentação.
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float largura = ImGui::GetContentRegionAvail().x;
    float altura = fs * 3.9f;
    ImGui::Dummy(ImVec2(largura, altura));
    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 canto = pos + ImVec2(largura, altura);
    dl->AddRectFilled(pos, canto, ImGui::GetColorU32(ImVec4(0.055f, 0.102f, 0.200f, 1.0f)), 12.0f);
    dl->AddRect(pos, canto, corComAlfa(COR_CIANO, 0.35f), 12.0f);
    dl->AddRectFilled(pos + ImVec2(0, 12), pos + ImVec2(4, altura - 12), corComAlfa(COR_CIANO, 0.9f), 2.0f);

    float margem = fs * 0.75f;
    float ladoIcone = altura - margem * 2.0f;
    ImVec2 pIcone = pos + ImVec2(margem, margem);
    dl->AddRectFilled(pIcone, pIcone + ImVec2(ladoIcone, ladoIcone), corComAlfa(COR_AZUL, 0.14f), 9.0f);
    dl->AddRect(pIcone, pIcone + ImVec2(ladoIcone, ladoIcone), corComAlfa(COR_AZUL, 0.35f), 9.0f);
    ImTextureID idIcone = icone(ui.texturas, Icone::Configuracoes);
    if (texturaValida(idIcone))
    {
        float dentro = ladoIcone * 0.23f;
        dl->AddImage(idIcone, pIcone + ImVec2(dentro, dentro),
                     pIcone + ImVec2(ladoIcone - dentro, ladoIcone - dentro));
    }

    float x = pIcone.x + ladoIcone + fs * 0.85f;
    textoDesenhado(dl, ImVec2(x, pos.y + margem * 0.55f), fs * 1.42f,
                   ImGui::GetStyleColorVec4(ImGuiCol_Text), "Personalização", fonteDosTitulos());
    textoDesenhado(dl, ImVec2(x, pos.y + margem * 0.55f + fs * 1.68f), fs * 0.80f,
                   ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled),
                   "Tema, densidade e preferências da aplicação.");

    inicioSeccao("Tema da aplicação");
    ImGui::TextDisabled("A paleta é aplicada a toda a interface e fica guardada para a próxima sessão.");
    float espaco = ImGui::GetStyle().ItemSpacing.x;
    float larguraCartao = (ImGui::GetContentRegionAvail().x - espaco) * 0.5f;
    for (int i = 0; i < static_cast<int>(sizeof(NOMES_TEMA) / sizeof(NOMES_TEMA[0])); i++)
    {
        if (i % 2 == 1)
            ImGui::SameLine();
        if (cartaoTema(i, ui.temaInterface == i, larguraCartao))
        {
            ui.temaInterface = i;
            definirTemaInterface(i);
            mostrarMensagem(ui, std::string("Tema aplicado: ") + NOMES_TEMA[i], 1);
        }
    }

    inicioSeccao("Densidade da interface");
    ImGui::TextDisabled("Mais espaço entre elementos ou mais pedidos visíveis de uma vez.");
    if (cartaoDensidade("Confortável", "Mais espaço e legibilidade", !ui.modoCompacto, larguraCartao) && ui.modoCompacto)
    {
        ui.modoCompacto = false;
        definirModoCompacto(false);
        mostrarMensagem(ui, "Modo confortável ativado.", 1);
    }
    ImGui::SameLine();
    if (cartaoDensidade("Compacta", "Mais pedidos visíveis de uma vez", ui.modoCompacto, larguraCartao) && !ui.modoCompacto)
    {
        ui.modoCompacto = true;
        definirModoCompacto(true);
        mostrarMensagem(ui, "Modo compacto ativado.", 1);
    }

    inicioSeccao("Atalhos e preferências");
    ImGui::TextDisabled("A paleta de comandos (Ctrl+K) dá acesso rápido a todas as ações.");
    ImGui::Spacing();
    if (botaoComIcone(ui.texturas, Icone::Ajuda, "Ver atalhos de teclado"))
        ui.abrirAtalhos = true;
    ImGui::SameLine();
    if (botaoComIcone(ui.texturas, Icone::Recarregar, "Repor predefinições"))
    {
        ui.temaInterface = 0;
        definirTemaInterface(0);
        ui.modoCompacto = false;
        definirModoCompacto(false);
        ui.metricaVendedor = 0;
        ui.fracaoLista = 0.55f;
        mostrarMensagem(ui, "Preferências visuais repostas.", 1);
    }
    ImGui::Spacing();
    ImGui::TextDisabled("As preferências são guardadas em assistencia.cfg.");
}


// ====================================================================
//  Assistente de IA (modelo GGUF local)
// ====================================================================

static void desenharAssistenteIA(EstadoUI &ui)
{
    float fs = ImGui::GetFontSize();

    // Faixa de apresentação do assistente.
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float largura = ImGui::GetContentRegionAvail().x;
    float altura = fs * 3.9f;
    ImGui::Dummy(ImVec2(largura, altura));
    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 canto = pos + ImVec2(largura, altura);
    dl->AddRectFilled(pos, canto, ImGui::GetColorU32(ImVec4(0.055f, 0.102f, 0.200f, 1.0f)), 12.0f);
    dl->AddRect(pos, canto, corComAlfa(COR_CIANO, 0.35f), 12.0f);
    dl->AddRectFilled(pos + ImVec2(0, 12), pos + ImVec2(4, altura - 12), corComAlfa(COR_CIANO, 0.9f), 2.0f);

    float margem = fs * 0.75f;
    float lado = altura - margem * 2;
    ImVec2 pLogo = pos + ImVec2(margem, margem);
    if (texturaValida(ui.texturas.logo))
        dl->AddImage(ui.texturas.logo, pLogo, pLogo + ImVec2(lado, lado));

    float x = pLogo.x + lado + fs * 0.85f;
    float tamTitulo = fs * 1.42f;
    textoDesenhado(dl, ImVec2(x, pos.y + margem * 0.55f), tamTitulo,
                   ImGui::GetStyleColorVec4(ImGuiCol_Text), "Assistente IA", fonteDosTitulos());
    textoDesenhado(dl, ImVec2(x, pos.y + margem * 0.55f + tamTitulo * 1.18f), fs * 0.80f,
                   ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled),
                   "Diagnósticos e mensagens com um modelo local.");

    EstadoIA estado = ui.ia.estado();

    inicioSeccao("Modelo GGUF");
    if (!AssistenteIA::compiladoComSuporte())
    {
        ImGui::TextColored(COR_AMBAR, "Esta compilação não inclui o llama.cpp (USE_LLAMA=OFF).");
        return;
    }
    ImGui::TextWrapped("Indique o caminho de um ficheiro .gguf (por exemplo, um modelo \"instruct\" pequeno quantizado em Q4_K_M). Corre localmente, sem Internet.");
    ImGui::SetNextItemWidth(-1);
    ImGui::InputTextWithHint("##modelo", "C:\\modelos\\qwen2.5-1.5b-instruct-q4_k_m.gguf", &ui.caminhoModelo);

    ImGui::SetNextItemWidth(fs * 6.7f);
    ImGui::SliderInt("Threads", &ui.nThreads, 1, std::max(1u, std::thread::hardware_concurrency()));
    ImGui::SameLine();
    ImGui::SetNextItemWidth(fs * 6.1f);
    if (ImGui::BeginCombo("Contexto", std::to_string(TAMANHOS_CONTEXTO[ui.indiceContexto]).c_str()))
    {
        for (int i = 0; i < 3; i++)
            if (ImGui::Selectable(std::to_string(TAMANHOS_CONTEXTO[i]).c_str(), i == ui.indiceContexto))
                ui.indiceContexto = i;
        ImGui::EndCombo();
    }

    bool ocupado = (estado == EstadoIA::ACarregar || estado == EstadoIA::AGerar);
    ImGui::BeginDisabled(ocupado);
    pushCorBotao(COR_AZUL);
    if (botaoComIcone(ui.texturas, Icone::Pasta, "Carregar modelo"))
        ui.ia.carregarModelo(ui.caminhoModelo, ui.nThreads, TAMANHOS_CONTEXTO[ui.indiceContexto]);
    popCorBotao();
    ImGui::SameLine();
    if (botaoComIcone(ui.texturas, Icone::Remover, "Descarregar modelo"))
        ui.ia.descarregarModelo();
    ImGui::EndDisabled();

    ImVec4 corMsg = (estado == EstadoIA::Erro)     ? COR_VERMELHO
                    : (estado == EstadoIA::Pronto) ? COR_VERDE
                                                   : COR_AMBAR;
    ImGui::TextColored(corMsg, "%s", ui.ia.mensagem().c_str());

    inicioSeccao("Pedir sugestão");
    ImGui::TextDisabled("A IA apenas sugere. O técnico valida sempre o resultado.");
    const Pedido *p = ui.gestor.procurarPorId(ui.idSelecionado);
    if (p == nullptr)
    {
        ImGui::TextDisabled("Selecione um pedido na lista para usar o assistente.");
        return;
    }
    ImGui::Text("Pedido #%d  •  %s", p->id, p->equipamento.c_str());
    ImGui::RadioButton("Diagnóstico sugerido", &ui.tipoIA, 0);
    ImGui::SameLine();
    ImGui::RadioButton("Mensagem para o cliente", &ui.tipoIA, 1);
    ImGui::SetNextItemWidth(fs * 8.5f);
    ImGui::SliderInt("Máx. tokens", &ui.maxTokens, 64, 800);

    ImGui::BeginDisabled(estado != EstadoIA::Pronto);
    pushCorBotao(COR_AZUL);
    if (botaoComIcone(ui.texturas, Icone::Gerar, "Gerar"))
    {
        TipoPedidoIA tipo = (ui.tipoIA == 0) ? TipoPedidoIA::DiagnosticoSugerido : TipoPedidoIA::MensagemParaCliente;
        ui.idPedidoIA = p->id;
        ui.ia.gerar(instrucaoSistema(tipo), montarPergunta(tipo, *p, ui.gestor.custoPedido(*p)), ui.maxTokens);
    }
    popCorBotao();
    ImGui::EndDisabled();
    ImGui::SameLine();
    ImGui::BeginDisabled(estado != EstadoIA::AGerar);
    pushCorBotao(ImVec4(0.545f, 0.157f, 0.208f, 1.0f));
    if (botaoComIcone(ui.texturas, Icone::Fechar, "Parar"))
        ui.ia.parar();
    popCorBotao();
    ImGui::EndDisabled();

    std::string texto = ui.ia.textoGerado();
    ImGui::Spacing();
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.039f, 0.059f, 0.110f, 1.0f));
    ImGui::BeginChild("saidaIA", ImVec2(0, ImGui::GetContentRegionAvail().y - ImGui::GetFrameHeightWithSpacing() * 2.2f), ImGuiChildFlags_Borders);
    if (texto.empty())
        ImGui::TextDisabled("A resposta do modelo aparece aqui.");
    else
        ImGui::TextWrapped("%s", texto.c_str());
    if (estado == EstadoIA::AGerar)
        ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();
    ImGui::PopStyleColor();

    ImGui::BeginDisabled(texto.empty() || estado == EstadoIA::AGerar || ui.idPedidoIA != p->id);
    if (ui.tipoIA == 0)
    {
        pushCorBotao(ImVec4(0.145f, 0.451f, 0.318f, 1.0f));
        if (botaoComIcone(ui.texturas, Icone::Verificar, "Usar como diagnóstico"))
        {
            Pedido *edit = ui.gestor.procurarPorId(ui.idSelecionado);
            if (edit != nullptr)
            {
                if (!edit->diagnostico.empty())
                    edit->diagnostico += "\n";
                edit->diagnostico += texto;
                mostrarMensagem(ui, "Sugestão da IA copiada para o diagnóstico (reveja antes de guardar).", 1);
            }
        }
        popCorBotao();
        ImGui::SameLine();
    }
    if (botaoComIcone(ui.texturas, Icone::Copiar, "Copiar texto"))
        ImGui::SetClipboardText(texto.c_str());
    ImGui::EndDisabled();
}

// ====================================================================
//  Paleta de comandos (Ctrl+K) e atalhos de teclado
// ====================================================================

enum ComandoID
{
    CMD_NOVO = 0,
    CMD_GUARDAR,
    CMD_EXPORTAR,
    CMD_RECARREGAR,
    CMD_DEMO,
    CMD_DETALHE,
    CMD_ESTATISTICAS,
    CMD_IA,
    CMD_PERSONALIZACAO,
    CMD_DUPLICAR,
    CMD_COPIAR,
    CMD_FILTROS,
    CMD_TEMA,
    CMD_DENSIDADE,
    CMD_ATALHOS,
    CMD_SAIR,
    CMD_TOTAL
};

struct Comando
{
    const char *nome;
    const char *chave;       // versão sem acentos, usada na pesquisa
    const char *descricao;
    const char *atalho;
    Icone icone;
};

static const Comando COMANDOS[] = {
    {"Novo pedido", "novo pedido criar", "Abrir o formulário de um novo pedido", "Ctrl+N", Icone::NovoPedido},
    {"Guardar dados", "guardar dados ficheiro", "Gravar os pedidos no ficheiro local", "Ctrl+S", Icone::Guardar},
    {"Exportar CSV", "exportar csv folha calculo", "Gerar assistencia_pedidos.csv para Excel", "Ctrl+E", Icone::Gerar},
    {"Recarregar dados", "recarregar dados ficheiro", "Voltar a ler o ficheiro de dados", "F5", Icone::Recarregar},
    {"Dados de demonstração", "demo demonstracao exemplo", "Substituir pelos 12 pedidos de exemplo", "", Icone::Pasta},
    {"Ir para o detalhe", "detalhe pedido separador", "Mostrar o separador do pedido selecionado", "", Icone::Detalhe},
    {"Ir para as estatísticas", "estatisticas painel graficos", "Mostrar os indicadores e gráficos", "", Icone::Estatisticas},
    {"Ir para o assistente IA", "ia assistente inteligencia artificial", "Abrir o assistente de IA local", "", Icone::IA},
    {"Personalização", "personalizacao tema aspeto aparencia densidade", "Escolher o tema, a densidade e as preferências visuais", "", Icone::Configuracoes},
    {"Duplicar pedido", "duplicar copiar pedido", "Criar uma cópia do pedido selecionado", "Ctrl+D", Icone::Adicionar},
    {"Copiar resumo", "copiar resumo pedido", "Copiar os dados do pedido para a área de transferência", "Ctrl+Shift+C", Icone::Copiar},
    {"Limpar filtros", "limpar filtros pesquisa", "Mostrar novamente todos os pedidos", "Esc", Icone::Pesquisa},
    {"Mudar de tema", "tema cores paleta", "Percorrer as paletas de cores disponíveis", "", Icone::Configuracoes},
    {"Modo compacto", "compacto densidade espacamento", "Alternar entre vista confortável e compacta", "", Icone::Configuracoes},
    {"Atalhos de teclado", "atalhos teclado ajuda", "Ver a lista completa de atalhos", "F1", Icone::Ajuda},
    {"Sair", "sair fechar encerrar", "Fechar a aplicação", "", Icone::Sair},
};

static std::string minusculasUI(const std::string &s)
{
    std::string r = s;
    for (char &c : r)
        if (c >= 'A' && c <= 'Z')
            c = static_cast<char>(c - 'A' + 'a');
    return r;
}

static void executarComando(EstadoUI &ui, int id)
{
    switch (id)
    {
    case CMD_NOVO:
        ui.abrirNovoPedido = true;
        break;
    case CMD_GUARDAR:
        acaoGuardar(ui);
        break;
    case CMD_EXPORTAR:
        acaoExportarCSV(ui);
        break;
    case CMD_RECARREGAR:
        acaoRecarregar(ui);
        break;
    case CMD_DEMO:
        acaoDemo(ui);
        break;
    case CMD_DETALHE:
        ui.forcarSeparador = 0;
        break;
    case CMD_ESTATISTICAS:
        ui.forcarSeparador = 1;
        break;
    case CMD_IA:
        ui.forcarSeparador = 2;
        break;
    case CMD_PERSONALIZACAO:
        ui.forcarSeparador = 3;
        break;
    case CMD_DUPLICAR:
        acaoDuplicarPedido(ui);
        break;
    case CMD_COPIAR:
        acaoCopiarResumo(ui);
        break;
    case CMD_FILTROS:
        ui.filtroTexto.clear();
        ui.filtroEstado = 0;
        ui.focarPesquisa = true;
        break;
    case CMD_TEMA:
        ui.temaInterface = (ui.temaInterface + 1) %
                           static_cast<int>(sizeof(NOMES_TEMA) / sizeof(NOMES_TEMA[0]));
        definirTemaInterface(ui.temaInterface);
        mostrarMensagem(ui, std::string("Tema: ") + NOMES_TEMA[ui.temaInterface]);
        break;
    case CMD_DENSIDADE:
        ui.modoCompacto = !ui.modoCompacto;
        definirModoCompacto(ui.modoCompacto);
        mostrarMensagem(ui, ui.modoCompacto ? "Modo compacto ativado." : "Modo confortável ativado.");
        break;
    case CMD_ATALHOS:
        ui.abrirAtalhos = true;
        break;
    case CMD_SAIR:
        ui.sair = true;
        break;
    default:
        break;
    }
}

static void desenharPaletaComandos(EstadoUI &ui)
{
    float fs = ImGui::GetFontSize();
    const ImGuiViewport *vp = ImGui::GetMainViewport();

    if (ui.paletaAberta)
    {
        ImGui::OpenPopup("##paletaComandos");
        ui.paletaAberta = false;
        ui.paletaFocar = true;
        ui.paletaIndice = 0;
    }

    ImGui::SetNextWindowPos(vp->WorkPos + ImVec2(vp->WorkSize.x * 0.5f, vp->WorkSize.y * 0.13f),
                            ImGuiCond_Always, ImVec2(0.5f, 0.0f));
    ImGui::SetNextWindowSize(ImVec2(fs * 34.0f, 0.0f), ImGuiCond_Always);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(fs * 0.9f, fs * 0.9f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 14.0f);

    if (ImGui::BeginPopupModal("##paletaComandos", nullptr,
                               ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                                   ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings))
    {
        // Cabeçalho.
        ImGui::TextUnformatted("Paleta de comandos");
        ImGui::SameLine();
        ImGui::TextDisabled("  Ctrl+K");
        ImGui::Spacing();

        if (ui.paletaFocar)
        {
            ImGui::SetKeyboardFocusHere();
            ui.paletaFocar = false;
        }
        ImGui::SetNextItemWidth(-1);
        bool mudou = ImGui::InputTextWithHint("##buscaComando", "O que quer fazer?",
                                              &ui.paletaTexto, ImGuiInputTextFlags_AutoSelectAll);
        if (mudou)
            ui.paletaIndice = 0;

        std::vector<int> visiveis;
        std::string alvo = minusculasUI(ui.paletaTexto);
        for (int i = 0; i < CMD_TOTAL; i++)
        {
            std::string chave = minusculasUI(std::string(COMANDOS[i].chave) + " " +
                                             COMANDOS[i].nome + " " + COMANDOS[i].descricao);
            if (alvo.empty() || chave.find(alvo) != std::string::npos)
                visiveis.push_back(i);
        }

        int n = static_cast<int>(visiveis.size());
        if (n > 0)
        {
            if (ImGui::IsKeyPressed(ImGuiKey_DownArrow, true))
                ui.paletaIndice = (ui.paletaIndice + 1) % n;
            if (ImGui::IsKeyPressed(ImGuiKey_UpArrow, true))
                ui.paletaIndice = (ui.paletaIndice + n - 1) % n;
            if (ui.paletaIndice < 0 || ui.paletaIndice >= n)
                ui.paletaIndice = 0;
        }
        else
            ui.paletaIndice = 0;

        ImGui::Spacing();
        int executarId = -1;
        if (n == 0)
        {
            ImGui::TextDisabled("Nenhum comando encontrado.");
        }
        else
        {
            ImGui::PushStyleColor(ImGuiCol_Header, ImVec4(COR_AZUL.x, COR_AZUL.y, COR_AZUL.z, 0.28f));
            ImGui::PushStyleColor(ImGuiCol_HeaderHovered, ImVec4(COR_AZUL.x, COR_AZUL.y, COR_AZUL.z, 0.38f));
            ImGui::PushStyleColor(ImGuiCol_HeaderActive, ImVec4(COR_AZUL.x, COR_AZUL.y, COR_AZUL.z, 0.50f));
            float alturaLista = std::min(fs * 22.0f, n * fs * 2.15f + fs * 0.4f);
            ImGui::BeginChild("##listaComandos", ImVec2(0, alturaLista), ImGuiChildFlags_None);
            for (int k = 0; k < n; k++)
            {
                const Comando &c = COMANDOS[visiveis[k]];
                ImGui::PushID(k);
                bool selecionado = (k == ui.paletaIndice);
                if (ImGui::Selectable("##linhaComando", selecionado, ImGuiSelectableFlags_None,
                                      ImVec2(ImGui::GetContentRegionAvail().x, fs * 2.10f)))
                    executarId = visiveis[k];
                if (ImGui::IsItemHovered())
                    ui.paletaIndice = k;

                ImVec2 a = ImGui::GetItemRectMin();
                ImVec2 b = ImGui::GetItemRectMax();
                ImDrawList *dl = ImGui::GetWindowDrawList();
                float lado = fs * 1.45f;
                ImVec2 pIcone(a.x + fs * 0.45f, a.y + (fs * 2.10f - lado) * 0.5f);
                dl->AddRectFilled(pIcone, pIcone + ImVec2(lado, lado),
                                  corComAlfa(selecionado ? COR_CIANO : COR_AZUL, 0.14f), 7.0f);
                ImTextureID id = icone(ui.texturas, c.icone);
                if (texturaValida(id))
                {
                    float dentro = lado * 0.25f;
                    dl->AddImage(id, pIcone + ImVec2(dentro, dentro),
                                 pIcone + ImVec2(lado - dentro, lado - dentro));
                }

                float xTexto = pIcone.x + lado + fs * 0.65f;
                textoDesenhado(dl, ImVec2(xTexto, a.y + fs * 0.28f), fs * 0.90f,
                               ImGui::GetStyleColorVec4(ImGuiCol_Text), c.nome,
                               selecionado ? fonteDosTitulos() : nullptr);
                textoDesenhado(dl, ImVec2(xTexto, a.y + fs * 1.20f), fs * 0.70f,
                               ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), c.descricao);
                if (c.atalho[0] != '\0')
                {
                    ImVec2 medida = medidaTexto(c.atalho, fs * 0.68f);
                    textoDesenhado(dl, ImVec2(b.x - fs * 0.55f - medida.x, a.y + fs * 0.72f),
                                   fs * 0.68f, ImVec4(COR_CIANO.x, COR_CIANO.y, COR_CIANO.z, 0.85f), c.atalho);
                }
                ImGui::PopID();
            }
            ImGui::EndChild();
            ImGui::PopStyleColor(3);
        }

        ImGui::Spacing();
        ImGui::TextDisabled("↑ ↓ navegar   ·   Enter executar   ·   Esc fechar");

        bool enter = ImGui::IsKeyPressed(ImGuiKey_Enter) || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter);
        if (executarId < 0 && enter && n > 0)
            executarId = visiveis[ui.paletaIndice];
        if (ImGui::IsKeyPressed(ImGuiKey_Escape))
            ImGui::CloseCurrentPopup();

        if (executarId >= 0)
        {
            ImGui::CloseCurrentPopup();
            executarComando(ui, executarId);
        }
        ImGui::EndPopup();
    }
    ImGui::PopStyleVar(2);
}

static void desenharAtalhos(EstadoUI &ui)
{
    if (ui.abrirAtalhos)
    {
        ImGui::OpenPopup("Atalhos de teclado");
        ui.abrirAtalhos = false;
    }

    ImVec2 centro = ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(centro, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (ImGui::BeginPopupModal("Atalhos de teclado", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
    {
        ImGui::TextDisabled("A interface também pode ser controlada pelo teclado.");
        ImGui::Spacing();
        if (ImGui::BeginTable("tabelaAtalhos", 2, ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_RowBg))
        {
            ImGui::TableSetupColumn("Atalho", ImGuiTableColumnFlags_WidthFixed, ImGui::GetFontSize() * 8.0f);
            ImGui::TableSetupColumn("Ação", ImGuiTableColumnFlags_WidthStretch);
            ImGui::TableHeadersRow();
            for (const Comando &c : COMANDOS)
            {
                if (c.atalho[0] == '\0')
                    continue;
                ImGui::TableNextRow();
                ImGui::TableNextColumn();
                ImGui::TextColored(COR_CIANO, "%s", c.atalho);
                ImGui::TableNextColumn();
                ImGui::TextUnformatted(c.nome);
            }
            ImGui::EndTable();
        }
        ImGui::Spacing();
        if (ImGui::Button("Fechar"))
            ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

static void tratarAtalhos(EstadoUI &ui)
{
    // Com um popup aberto, os atalhos globais ficam suspensos.
    if (ImGui::IsPopupOpen("", ImGuiPopupFlags_AnyPopup))
        return;

    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_K))
    {
        ui.paletaTexto.clear();
        ui.paletaIndice = 0;
        ui.paletaAberta = true;
        ui.paletaFocar = true;
        return;
    }
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_S))
        acaoGuardar(ui);
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_N))
        ui.abrirNovoPedido = true;
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_E))
        acaoExportarCSV(ui);
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_D))
        acaoDuplicarPedido(ui);
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiMod_Shift | ImGuiKey_C))
        acaoCopiarResumo(ui);
    if (ImGui::IsKeyPressed(ImGuiKey_F5))
        acaoRecarregar(ui);
    if (ImGui::IsKeyPressed(ImGuiKey_F1))
        ui.abrirAtalhos = true;
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_F))
    {
        ui.forcarSeparador = 0;
        ui.focarPesquisa = true;
    }
    if (ImGui::IsKeyPressed(ImGuiKey_Escape))
    {
        ui.filtroTexto.clear();
        ui.filtroEstado = 0;
    }
}

// ====================================================================
//  Janela "Novo pedido"
// ====================================================================

static void desenharNovoPedido(EstadoUI &ui)
{
    if (ui.abrirNovoPedido)
    {
        ImGui::OpenPopup("Novo pedido");
        ui.abrirNovoPedido = false;
        ui.erroNovoPedido.clear();
    }
    float fs = ImGui::GetFontSize();
    ImVec2 centro = ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(centro, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(fs * 32.0f, 0), ImGuiCond_Appearing);
    if (ImGui::BeginPopupModal("Novo pedido", nullptr, ImGuiWindowFlags_NoResize))
    {
        // Cabeçalho do diálogo.
        if (texturaValida(icone(ui.texturas, Icone::NovoPedido)))
        {
            ImGui::Image(icone(ui.texturas, Icone::NovoPedido), ImVec2(fs * 1.6f, fs * 1.6f));
            ImGui::SameLine();
        }
        ImGui::BeginGroup();
        pushFonteTitulo(1.35f);
        ImGui::TextUnformatted("Novo pedido");
        ImGui::PopFont();
        ImGui::TextDisabled("Registe um novo pedido de assistência técnica.");
        ImGui::EndGroup();
        ImGui::Separator();
        ImGui::Spacing();

        auto campo = [](const char *rotulo, const char *id, const char *dica, std::string *valor)
        {
            ImGui::TextDisabled("%s", rotulo);
            ImGui::SetNextItemWidth(-1);
            ImGui::InputTextWithHint(id, dica, valor);
        };

        if (ImGui::BeginTable("novoPedidoCampos", 3, ImGuiTableFlags_SizingStretchProp))
        {
            ImGui::TableSetupColumn("a", ImGuiTableColumnFlags_WidthStretch, 1.6f);
            ImGui::TableSetupColumn("b", ImGuiTableColumnFlags_WidthStretch, 1.2f);
            ImGui::TableSetupColumn("c", ImGuiTableColumnFlags_WidthStretch, 1.2f);

            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            campo("Cliente", "##nc", "Nome do cliente (fictício)", &ui.novoCliente);
            ImGui::TableSetColumnIndex(1);
            campo("Contacto", "##nct", "Telefone ou email", &ui.novoContacto);
            ImGui::TableSetColumnIndex(2);
            campo("Vendedor", "##nve", "Quem recebeu o pedido", &ui.novoVendedor);

            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            campo("Equipamento", "##ne", "Ex.: Portátil Acer Aspire 5", &ui.novoEquipamento);
            ImGui::TableSetColumnIndex(1);
            campo("Técnico", "##nte", "Técnico responsável", &ui.novoTecnico);
            ImGui::TableSetColumnIndex(2);
            ImGui::TextDisabled("Prioridade");
            ImGui::SetNextItemWidth(-1);
            comboNomes("##nprioridade", ui.novaPrioridade, NUM_PRIORIDADES, nomePrioridadeInt);
            ImGui::EndTable();
        }

        ImGui::Spacing();
        ImGui::TextDisabled("Avaria reportada");
        ImGui::InputTextMultiline("##na", &ui.novaAvaria, ImVec2(-1, ImGui::GetTextLineHeight() * 3.5f), ImGuiInputTextFlags_WordWrap);

        if (!ui.erroNovoPedido.empty())
        {
            ImGui::Spacing();
            ImGui::TextColored(COR_VERMELHO, "%s", ui.erroNovoPedido.c_str());
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        float larguraCancelar = ImGui::CalcTextSize("Cancelar").x + ImGui::GetStyle().FramePadding.x * 2;
        float larguraCriar = larguraBotao("Criar pedido", true);
        ImGui::SameLine(ImGui::GetWindowWidth() - ImGui::GetStyle().WindowPadding.x - larguraCriar - larguraCancelar - ImGui::GetStyle().ItemSpacing.x);
        if (ImGui::Button("Cancelar", ImVec2(larguraCancelar, 0)))
            ImGui::CloseCurrentPopup();
        ImGui::SameLine();
        pushCorBotao(COR_AZUL);
        if (botaoComIcone(ui.texturas, Icone::Adicionar, "Criar pedido"))
        {
            ui.erroNovoPedido = GestorPedidos::erroNovoPedido(ui.novoCliente, ui.novoEquipamento, ui.novaAvaria);
            if (ui.erroNovoPedido.empty() &&
                (ui.novoContacto.size() > 60 || ui.novoVendedor.size() > 60 || ui.novoTecnico.size() > 60))
            {
                ui.erroNovoPedido = "Contacto, vendedor e técnico: máximo 60 caracteres cada.";
            }
            if (ui.erroNovoPedido.empty())
            {
                int id = ui.gestor.adicionarPedido(ui.novoCliente, ui.novoEquipamento, ui.novaAvaria,
                                                   static_cast<Prioridade>(ui.novaPrioridade),
                                                   ui.novoContacto, ui.novoVendedor, ui.novoTecnico);
                if (id > 0)
                {
                    ui.idSelecionado = id;
                    mostrarMensagem(ui, "Pedido #" + std::to_string(id) + " criado.", 1);
                    ui.novoCliente.clear();
                    ui.novoContacto.clear();
                    ui.novoEquipamento.clear();
                    ui.novaAvaria.clear();
                    ui.novoVendedor.clear();
                    ui.novoTecnico.clear();
                    ui.novaPrioridade = 1;
                    ImGui::CloseCurrentPopup();
                }
            }
        }
        popCorBotao();
        ImGui::EndPopup();
    }
}

// ====================================================================
//  Janela principal
// ====================================================================

void desenharInterface(EstadoUI &ui)
{
    const ImGuiViewport *vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(vp->WorkPos);
    ImGui::SetNextWindowSize(vp->WorkSize);
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
                             ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_MenuBar |
                             ImGuiWindowFlags_NoBringToFrontOnFocus;
    ImGui::Begin("Janela principal", nullptr, flags);

    // Fundo decorativo (gradiente, orbes e grelha de pontos).
    desenharFundoDecorativo();
    tratarAtalhos(ui);

    if (ImGui::BeginMenuBar())
    {
        if (ImGui::BeginMenu("Ficheiro"))
        {
            if (menuItemComIcone(ui.texturas, Icone::Guardar, "Guardar dados"))
                acaoGuardar(ui);
            if (menuItemComIcone(ui.texturas, Icone::Recarregar, "Recarregar dados do ficheiro"))
                acaoRecarregar(ui);
            if (menuItemComIcone(ui.texturas, Icone::Pasta, "Carregar dados de demonstração"))
                acaoDemo(ui);
            ImGui::Separator();
            if (menuItemComIcone(ui.texturas, Icone::Gerar, "Exportar CSV"))
                acaoExportarCSV(ui);
            ImGui::Separator();
            if (menuItemComIcone(ui.texturas, Icone::Sair, "Sair"))
                ui.sair = true;
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Ajuda"))
        {
            if (menuItemComIcone(ui.texturas, Icone::Ajuda, "Atalhos de teclado"))
                ui.abrirAtalhos = true;
            if (menuItemComIcone(ui.texturas, Icone::Sobre, "Sobre"))
                ImGui::OpenPopup("Sobre");
            ImGui::EndMenu();
        }

        const char *estado = "Dados locais  •  Sem Internet";
        ImGui::SameLine(ImGui::GetWindowWidth() - ImGui::CalcTextSize(estado).x - ImGui::GetStyle().WindowPadding.x);
        ImGui::TextDisabled("%s", estado);
        ImGui::EndMenuBar();
    }

    // Faixa de identidade da Neuria (logótipo, nome e totais).
    desenharCabecalho(ui);
    ImGui::Spacing();

    // O OpenPopup dentro do menu tem de ser aberto ao nível da janela:
    if (ImGui::BeginPopupModal("Sobre", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
    {
        if (texturaValida(ui.texturas.logo))
        {
            ImGui::Image(ui.texturas.logo, ImVec2(72, 72));
            ImGui::SameLine();
        }
        ImGui::BeginGroup();
        pushFonteTitulo(1.45f);
        ImGui::TextUnformatted("Neuria");
        ImGui::PopFont();
        ImGui::TextUnformatted("Sistema de Assistência Técnica");
        ImGui::TextDisabled("UFCD 0810 - Programação em C/C++ - Avançada");
        ImGui::EndGroup();
        ImGui::Spacing();
        ImGui::TextDisabled("Dados fictícios. Assistente de IA local (llama.cpp / GGUF).");
        if (texturaValida(ui.texturas.banner))
        {
            ImGui::Spacing();
            ImGui::Image(ui.texturas.banner, ImVec2(480, 150)); // 1024x320 -> 3,2:1
        }
        ImGui::Spacing();
        ImGui::TextWrapped("Ícones: Material Design Icons (Google, Apache 2.0). "
                           "Fotografias: RestartProject e One Laptop per Child (CC BY 2.0). "
                           "Ver recursos/CREDITOS.txt.");
        ImGui::Spacing();
        ImGui::TextDisabled("Sugestão: Ctrl+K abre a paleta de comandos.");
        ImGui::Spacing();
        if (ImGui::Button("Fechar"))
            ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }

    float fs = ImGui::GetFontSize();
    float alturaRodape = fs * 2.20f + ImGui::GetStyle().ItemSpacing.y;
    float alturaPainel = ImGui::GetContentRegionAvail().y - alturaRodape;
    float larguraTotal = ImGui::GetContentRegionAvail().x;
    float larguraEsq = std::clamp(larguraTotal * ui.fracaoLista, fs * 23.0f, larguraTotal - fs * 26.0f);

    ImGui::BeginChild("painelEsq", ImVec2(larguraEsq, alturaPainel), ImGuiChildFlags_Borders);
    desenharLista(ui);
    ImGui::EndChild();

    // Divisor arrastável entre a lista e o detalhe.
    ImGui::SameLine(0, 0);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0, 0, 0, 0));
    ImGui::InvisibleButton("##divisor", ImVec2(7.0f, alturaPainel));
    bool divisorAtivo = ImGui::IsItemActive();
    bool divisorSobre = ImGui::IsItemHovered();
    if (divisorAtivo)
    {
        ImGuiIO &io = ImGui::GetIO();
        float nova = (larguraEsq + io.MouseDelta.x) / std::max(larguraTotal, 1.0f);
        ui.fracaoLista = std::clamp(nova, 0.32f, 0.72f);
    }
    if (divisorSobre || divisorAtivo)
        ImGui::SetMouseCursor(ImGuiMouseCursor_ResizeEW);
    {
        ImVec2 a = ImGui::GetItemRectMin();
        ImVec2 b = ImGui::GetItemRectMax();
        ImDrawList *dl = ImGui::GetWindowDrawList();
        ImU32 corLinha = corComAlfa((divisorSobre || divisorAtivo) ? COR_CIANO : ImGui::GetStyleColorVec4(ImGuiCol_Border),
                                    (divisorSobre || divisorAtivo) ? 0.85f : 0.45f);
        dl->AddRectFilled(ImVec2(a.x + 3, a.y + 2), ImVec2(a.x + 4, b.y - 2), corLinha, 1.0f);
        if (divisorSobre || divisorAtivo)
        {
            for (int k = -1; k <= 1; ++k)
                dl->AddCircleFilled(ImVec2(a.x + 3.5f, (a.y + b.y) * 0.5f + k * fs * 0.42f),
                                    fs * 0.11f, corComAlfa(COR_CIANO, 0.9f), 10);
        }
    }
    ImGui::PopStyleColor(3);

    ImGui::SameLine(0, 0);
    ImGui::BeginChild("painelDir", ImVec2(0, alturaPainel), ImGuiChildFlags_Borders);
    if (ImGui::BeginTabBar("separadores"))
    {
        const char *titulos[4] = {"Detalhe", "Estatísticas", "Assistente IA", "Personalização"};
        const char *conteudos[4] = {"##conteudoDetalhe", "##conteudoEstatisticas",
                                    "##conteudoAssistente", "##conteudoPersonalizacao"};
        for (int i = 0; i < 4; i++)
        {
            ImGuiTabItemFlags tf = (ui.forcarSeparador == i) ? ImGuiTabItemFlags_SetSelected : 0;
            if (ImGui::BeginTabItem(titulos[i], nullptr, tf))
            {
                // Cada separador tem o seu próprio scroll: a barra de separadores
                // fica sempre fixa no topo do painel.
                ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
                ImGui::BeginChild(conteudos[i], ImVec2(0, 0), ImGuiChildFlags_None,
                                  ImGuiWindowFlags_NoBackground);
                ImGui::PopStyleVar();

                if (i == 0)
                    desenharDetalhe(ui);
                else if (i == 1)
                    desenharEstatisticas(ui);
                else if (i == 2)
                    desenharAssistenteIA(ui);
                else
                    desenharPersonalizacao(ui);

                ImGui::EndChild();
                ImGui::EndTabItem();
            }
        }
        ui.forcarSeparador = -1;
        ImGui::EndTabBar();
    }
    ImGui::EndChild();

    // Barra de estado desenhada à mão e avisos flutuantes.
    ImGui::Spacing();
    desenharBarraEstado(ui);

    desenharNovoPedido(ui);
    desenharAtalhos(ui);
    desenharPaletaComandos(ui);
    desenharAvisos(ui);
    ImGui::End();
}