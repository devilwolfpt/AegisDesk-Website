// gestor.h
// GestorPedidos: guarda a coleção de pedidos num array dinâmico e oferece
// as operações pedidas na ficha (adicionar, listar, pesquisar, alterar, remover)
// mais cálculos e ficheiros.
#pragma once

#include <string>
#include <vector>

#include "modelos.h"

// Resumo com os indicadores calculados (devolvido por valor — é pequeno).
struct Estatisticas {
    int total = 0;
    int porEstado[NUM_ESTADOS] = {0};
    int porPrioridade[NUM_PRIORIDADES] = {0};
    int urgentesPendentes = 0;      // urgentes ainda não concluídos
    float faturacaoTotal = 0.0f;    // soma dos pedidos concluídos/entregues
    float tempoMedioDias = 0.0f;    // média de dias entre abertura e fecho
    float custoMedio = 0.0f;        // custo médio dos pedidos concluídos
};

class GestorPedidos {
public:
    GestorPedidos();
    ~GestorPedidos();                       // liberta toda a memória dinâmica

    // Como o gestor é dono de memória dinâmica, copiar seria perigoso
    // (duas cópias a libertarem o mesmo array). Por isso proíbo a cópia.
    GestorPedidos(const GestorPedidos&) = delete;
    GestorPedidos& operator=(const GestorPedidos&) = delete;

    // --- Pedidos ---
    // Valida os textos de um pedido novo. Devolve "" se estiver tudo bem,
    // ou uma mensagem em português a explicar o problema.
    static std::string erroNovoPedido(const std::string& cliente,
                                      const std::string& equipamento,
                                      const std::string& avaria);

    // Devolve o id do novo pedido, ou -1 se os dados forem inválidos.
    int adicionarPedido(const std::string& cliente, const std::string& equipamento,
                        const std::string& avaria, Prioridade prioridade,
                        std::time_t quando = 0);

    // Idem, mas também regista o contacto do cliente, o vendedor e o técnico.
    // (Sem valores por omissão para não criar ambiguidade com a versão acima.)
    int adicionarPedido(const std::string& cliente, const std::string& equipamento,
                        const std::string& avaria, Prioridade prioridade,
                        const std::string& contacto, const std::string& vendedor,
                        const std::string& tecnico, std::time_t quando = 0);
    bool removerPedido(int id);

    // Devolve apontador para o pedido ou nullptr se não existir.
    // (o chamador TEM de verificar nullptr antes de usar)
    Pedido* procurarPorId(int id);
    const Pedido* procurarPorId(int id) const;

    // --- Intervenções ---
    bool adicionarIntervencao(Pedido* p, const std::string& descricao,
                              const std::string& peca, float custoPeca, float horas);
    bool removerIntervencao(Pedido* p, int indice);

    // --- Estados ---
    // Muda o estado; se passar a Concluido regista a data de fecho.
    bool mudarEstado(Pedido* p, Estado novo, std::time_t quando = 0);

    // --- Consultas ---
    int quantidade() const { return nPedidos; }
    const Pedido* pedidoNaPosicao(int indice) const;   // nullptr se fora dos limites
    Pedido* pedidoNaPosicao(int indice);

    // Pesquisa por texto (cliente, contacto, equipamento, avaria, vendedor,
    // técnico ou nº) e/ou por estado.
    // Devolve os índices dos pedidos que cumprem os filtros.
    std::vector<int> pesquisar(const std::string& texto, int estadoFiltro /* -1 = todos */) const;

    // Ordena os pedidos usando um comparador escolhido pelo chamador
    // (apontador para função).
    typedef bool (*Comparador)(const Pedido&, const Pedido&);
    void ordenar(Comparador cmp);

    // --- Cálculos ---
    float custoPedido(const Pedido& p) const;      // peças + horas * taxa
    float custoPecas(const Pedido& p) const;
    float horasTotais(const Pedido& p) const;
    Estatisticas calcularEstatisticas() const;

    float taxaHoraria = 25.0f;   // €/hora (editável na interface)

    // --- Ficheiros ---
    bool guardar(const std::string& caminho, std::string& erro) const;
    bool carregar(const std::string& caminho, std::string& erro);
    void carregarDadosDemo();
    void limparTudo();

private:
    Pedido* pedidos = nullptr;   // array dinâmico de pedidos
    int nPedidos = 0;
    int capPedidos = 0;
    int proximoId = 1;

    void garantirCapacidade();   // duplica o array quando está cheio
    void trocar(GestorPedidos& outro);   // troca o conteúdo (usado ao carregar)
    static void libertarPedido(Pedido& p);   // faz delete[] às intervenções
};

// Comparadores prontos a usar com GestorPedidos::ordenar
bool compararPorId(const Pedido& a, const Pedido& b);
bool compararPorPrioridade(const Pedido& a, const Pedido& b);   // urgente primeiro
bool compararPorData(const Pedido& a, const Pedido& b);         // mais antigo primeiro
bool compararPorCliente(const Pedido& a, const Pedido& b);
bool compararPorVendedor(const Pedido& a, const Pedido& b);

// Utilitários de texto/data usados também pela interface
std::string formatarData(std::time_t t);
int diasEntre(std::time_t inicio, std::time_t fim);
